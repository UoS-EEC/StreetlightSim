#!/bin/sh
rm -f results/probabilisticBcast*
./WSNRouting -u Cmdenv -c probabilisticBcast 
