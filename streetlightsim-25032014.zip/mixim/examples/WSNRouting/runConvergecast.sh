#!/bin/sh
rm -f results/convergecast-*
./WSNRouting -u Cmdenv -c convergecast

