#!/bin/sh
rm -f results/flooding-*
./WSNRouting -u Cmdenv -c flooding

