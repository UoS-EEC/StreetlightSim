#/bin/sh

#file		sumo_files_gen.sh
#author  	seiping.lau@gmail.com
#date	    2014-02-05

echo -e "\\nBatch script to generate numbers of trips files by utilise <SUMO Home>/tools/trips/randomTrips.py \\n"

if [ $# -eq 0 ]; then
	echo -e "Error when executing the script ! \\n"
	echo "Usage $0 [options base file name <*.net.xml>] [options <number of trips>] [options <number of vehicle>]"
	exit 1		
fi

if [ $# -lt 2 ]; then
	echo -e "Error when executing the script ! More parameters is required\\n"
	echo "Usage $0 [options <*.net.xml> base file name] [options <number of trips>]"
	exit 1		
fi

if [ $# -gt 2 ]; then
	echo -e "Error when executing the script !  Too many paramenters \\n"
	echo "Usage $0 [options <*.net.xml> base file name] [options <number of trips>]"
	exit 1		
fi

if [ -f $1.net.xml ]; then
	#for ((i=1; i<= $; i++)); do
	./randomTrips.py -n $1.net.xml -o $1-$2.trips.xml -e $2
	echo "./randomTrips.py -n $1.net.xml -o $1.$2.trips.xml -e $2 --[done]"
	./duaIterate.py -n $1.net.xml -t $1-$2.trips.xml -R 1 -V $2
	echo "./duaIterate.py -n $1.net.xml -t $1.$2.trips.xml --[done]"
	baseFileXML="$1-$2"

cat > $1-$2.sumo.cfg << EOF
<configuration>
    <input>
        <net-file value="$1.net.xml"/> 
		<route-files value="$baseFileXML.RP.rou.xml"/>
        <additional-files value="$1.poly.xml"/>
    </input>
	<time>      
        <step-length value="0.1"/>
	</time>
 </configuration>
EOF

			echo -e "\\nCreate SUMO configuration file: $1.$2.sumo.cfg --[done]"

cat > sumo-launchd-$1.$2.launch.xml << EOF
<?xml version="1.0"?>
<!-- debug config -->
<launch>
	<copy file="$1.net.xml" />
	<copy file="$baseFileXML.RP.rou.xml" />
	<copy file="$1.poly.xml" />		
	<copy file="$baseFileXML.sumo.cfg" type="config" />
	<basedir path = "Streetlight_and_Road_Network/$1" />
</launch>
EOF

			echo -e "\\nCreate OMNET++ launch file: sumo-launchd-$1.$2.launch.xml --[done]"
	#done
	
cls
streetlightSimRouteGen.exe $baseFileXML.0.rou.xml $baseFileXML.RP.rou.xml $1"-"$2.trips.xml $1.osm

newDir="$1$time_stamp""_""$(date +%Y-%m-%d-%H-%M-%S)"
mkdir "$newDir"

mv $baseFileXML.sumo.cfg $newDir
mv sumo-launchd-$1.$2.launch.xml $newDir 
cp $1.net.xml $newDir
mv $baseFileXML.0.rou.xml $newDir
cp $1.poly.xml $newDir
cp $1.osm $newDir
mv $1"-"$2.trips.xml $newDir
mv $baseFileXML.RP.rou.xml  $newDir

echo ""
echo "The necessary files for StreetlightSim are located in $newDir"

else
	echo "SUMO network file not found.  Input file : $1.net.xml"
	exit 1
fi

