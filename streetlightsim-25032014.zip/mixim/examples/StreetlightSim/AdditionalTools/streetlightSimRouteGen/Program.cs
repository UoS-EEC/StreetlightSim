﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;

namespace streetlightSimRouteGen
{
    class streetlightSimRouteGen
    {
        private static string checkEdgeType(string edge, XmlNodeList list)
        {
            string pathType = "highway";

            for (int i = 0; i < list.Count; i++)
            {
                string strFromEdge = list[i].Attributes["from"].InnerText.Trim();

                if (strFromEdge.CompareTo(edge.Trim()) == 0)
                {
                    //Console.WriteLine("checkEdgeType : edge {0} : list {1} : {2} : pathType : {3}", edge, i, list[i].Attributes["from"].InnerText, list[i].Attributes["pathType"].InnerText);
                    if (list[i].Attributes["pathType"].InnerText == "pedestrian")
                    {
                        pathType = "pedestrian";
                        break;
                    }
                }
            }

            return pathType;

        }
        private static string checkEdgeName(string[] edgeList, XmlNodeList list)
        {

            string edgeName = "";

            for (int iEdge = 0; iEdge < edgeList.Length; iEdge++)
            {
                if (edgeList[iEdge].Substring(edgeList[iEdge].Length - 2, 1) == "#")
                {
                    edgeList[iEdge] = edgeList[iEdge].Substring(0, edgeList[iEdge].Length - 2);
                }
                
                int count = 2;
                while (count > 0)
                {
                    //Console.WriteLine("edge 2: {0}", edgeList[iEdge]);
                    for (int i = 0; i < list.Count; i++)
                    {
                        string strHighwayType = "";
                        string strHighwayName = "";

                        if (list[i].HasChildNodes && list[i].Attributes["action"] != null && list[i].Attributes["action"].InnerText != "delete"
                            && list[i].Attributes["id"].InnerText == edgeList[iEdge])
                        {
                            XmlNodeList wayNodeListChild = list[i].ChildNodes;
                            for (int j = 0; j < wayNodeListChild.Count; j++)
                            {

                                if (wayNodeListChild[j].Name == "tag")
                                {
                                    //Console.WriteLine("{0}", wayNodeListChild[j].OuterXml);
                                    if (wayNodeListChild[j].Attributes["k"] != null)
                                    {
                                        if (wayNodeListChild[j].Attributes["k"].InnerText == "name")
                                        {
                                            strHighwayName = wayNodeListChild[j].Attributes["v"].InnerText;
                                        }
                                        else if (wayNodeListChild[j].Attributes["k"].InnerText == "highway")
                                        {
                                            strHighwayType = wayNodeListChild[j].Attributes["v"].InnerText;
                                        }
                                    }
                                }
                            }
                            if (strHighwayType != "")
                            {

                                //Console.WriteLine(" edgeList[iEdge] : {0}", edgeList[iEdge]);
                                //Console.WriteLine(" strHighwayType : {0}, name :{1}", strHighwayType, strHighwayName);
                                if (edgeName == "")
                                    edgeName = strHighwayName + "|";
                                else
                                    edgeName = edgeName + strHighwayName + "|";
                            }
                        }
                    }
                    count--;
                    edgeList[iEdge] = edgeList[iEdge].Substring(1, edgeList[iEdge].Length - 1);
                }


            }
            return edgeName;
        }
        private static void drawTextProgressBar(int progress, int total)
        {
            //draw empty progress bar

            Console.CursorLeft = 0;
            Console.Write("|"); //start
            Console.CursorLeft = 51;
            Console.Write("|"); //end
            Console.CursorLeft = 1;
            float onechunk = 50.0f / total;

            //draw filled part
            int position = 1;
            for (int i = 0; i < onechunk * progress; i++)
            {
                Console.BackgroundColor = ConsoleColor.Green;
                Console.CursorLeft = position++;
                Console.Write(" ");
            }

            //draw unfilled part
            for (int i = position; i <= 50; i++)
            {
                Console.BackgroundColor = ConsoleColor.Black;
                Console.CursorLeft = position++;
                Console.Write(" ");
            }

            //draw totals
            Console.CursorLeft = 55;
            Console.BackgroundColor = ConsoleColor.Black;
            Console.Write(progress.ToString() + " of " + total.ToString() + "    "); //blanks at the end remove any excess
        }

        static void Main(string[] args)
        {
            try
            {
                
                XmlDocument xmlTripFile = new XmlDocument();
                //xmlTripFile.Load(options.tripFile);
                xmlTripFile.Load(args[2]);
                XmlNodeList tripNodeList = xmlTripFile.GetElementsByTagName("trip");


                XmlDocument xmlRouteFile = new XmlDocument();
                //xmlRouteFile.Load(options.InputFile);
                xmlRouteFile.Load(args[0]);
                XmlNodeList routeNodeList = xmlRouteFile.GetElementsByTagName("route");

                XmlDocument xmlOsmFIle = new XmlDocument();
                //xmlOsmFIle.Load(options.OsmFile);
                xmlOsmFIle.Load(args[3]);
                XmlNodeList wayNodeList = xmlOsmFIle.GetElementsByTagName("way");

                XmlWriterSettings mySettings = new XmlWriterSettings();
                mySettings.Indent = true;
                mySettings.IndentChars = "\t";

                //using (XmlWriter writer = XmlWriter.Create(options.OutputFile, mySettings))
                using (XmlWriter writer = XmlWriter.Create(args[1], mySettings))
                {

                    writer.WriteStartDocument();
                    writer.WriteComment("original route file: map_0.rou.xml ");

                    writer.WriteStartElement("routes");
                    /*
                     * for generate different vehicle type
                     * <vType id="0" accel="3" decel="9.81" sigma="0.5" length="2.5" minGap="0.5" maxSpeed="70"/> 
                     * <vType id="1" accel="3" decel="9.81" sigma="0.5" length="2.5" minGap="0.5" maxSpeed="90"/> 
                     */
                    writer.WriteStartElement("vType");
                    writer.WriteAttributeString("id", "pedestrian");
                    writer.WriteAttributeString("length", ".25");
                    writer.WriteAttributeString("minGap", "0");
                    /*
                    writer.WriteAttributeString("maxSpeed", "1.389");                    
                     * */
                    // mean = 1.34 std deviation = 0.37, 95th percentile = 1.34 + 1.645*0.37
                    writer.WriteAttributeString("maxSpeed", "1.9");
                    writer.WriteAttributeString("guiShape", "pedestrian");
                    writer.WriteAttributeString("guiWidth", "0.25");
                    writer.WriteEndElement();


                    writer.WriteStartElement("vType");
                    writer.WriteAttributeString("id", "cyclist");
                    writer.WriteAttributeString("length", "1.5");
                    writer.WriteAttributeString("minGap", ".5");
                    writer.WriteAttributeString("maxSpeed", "6.944");
                    writer.WriteAttributeString("guiShape", "bicycle");
                    writer.WriteAttributeString("guiWidth", "0.25");
                    writer.WriteEndElement();

                    writer.WriteStartElement("vType");
                    writer.WriteAttributeString("id", "motorist");
                    writer.WriteAttributeString("accel", "3");
                    writer.WriteAttributeString("decel", "9.81");
                    writer.WriteAttributeString("sigma", "0.5");
                    writer.WriteAttributeString("length", "5");
                    writer.WriteAttributeString("minGap", "2.5");
                    writer.WriteAttributeString("maxSpeed", "70");
                    writer.WriteAttributeString("guiShape", "passenger");
                    writer.WriteEndElement();

                    Console.WriteLine("\nStreetlightSimRouteGen -> processing ...\n");
                    /*
                      for (int i = 0; i < tripNodeList.Count; i++)
                      {
                          Console.WriteLine("trip info : {0}", tripNodeList[i].Attributes["from"].InnerText);
                      }
                   
                      */


                    int routeCount = 0;
                    for (int i = 0; i < routeNodeList.Count; i++)
                    {
                        //Console.WriteLine("route info count : {0}", routeNodeList.Count);

                        drawTextProgressBar(i + 1, routeNodeList.Count);

                        string[] edges = routeNodeList[i].Attributes["edges"].InnerText.Split(' ');
                        if (edges.Length >= 1)
                        {
                            writer.WriteStartElement("route");
                            writer.WriteAttributeString("id", routeCount.ToString());
                            writer.WriteAttributeString("edges", routeNodeList[i].Attributes["edges"].InnerText);
                            writer.WriteAttributeString("pathType", checkEdgeType(edges[0], tripNodeList));

                            writer.WriteAttributeString("streetName", checkEdgeName(edges, wayNodeList));
                            writer.WriteEndElement();
                            routeCount++;
                        }

                    }
                    writer.WriteEndElement();
                    writer.WriteEndDocument();

                }

            }
            catch (FileNotFoundException ex)
            {
                Console.WriteLine("\nError : File not found");
                Environment.Exit(1);
            }

            Console.WriteLine("\n\nFinished ...");
        }
    }
}
