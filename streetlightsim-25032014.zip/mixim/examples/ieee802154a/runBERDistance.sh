#! /bin/sh
./ieee802154a -u Cmdenv -c BERDistance $*


