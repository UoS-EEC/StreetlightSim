/*
 * SimpleNetwLayer.cc
 *
 *  Created on: 29.08.2008
 *      Author: Karl Wessel
 */

#include "SimpleNetwLayer.h"

Define_Module(SimpleNetwLayer);
