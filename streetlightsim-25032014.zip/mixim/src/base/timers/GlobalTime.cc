#include "GlobalTime.h"

//Define_Module_Like(GlobalTime,Trivial);

