/* -*- mode:c++ -*- *******************************************************
 * file:        NetwControlInfo.h
 *
 * author:      Daniel Willkomm
 *
 * copyright:   (C) 2005 Telecommunication Networks Group (TKN) at
 *              Technische Universitaet Berlin, Germany.
 *
 *              This program is free software; you can redistribute it
 *              and/or modify it under the terms of the GNU General Public
 *              License as published by the Free Software Foundation; either
 *              version 2 of the License, or (at your option) any later
 *              version.
 *              For further information see file COPYING
 *              in the top level directory
 **************************************************************************
 * part of:     framework implementation developed by tkn
 * description: - control info to pass the netw addresses between the
 *                network and application layer
 **************************************************************************/

#ifndef APPLCONTROLINFO_H
#define APPLCONTROLINFO_H

#include <omnetpp.h>

#include "MiXiMDefs.h"
#include "SimpleAddress.h"

/**
 * @brief Control info netw messages
 *
 * Control Info to pass interface information from the network to the
 * application layer and vice versa. The application layer passes the
 * destination netw address to the network layer, whereas the network
 * layer uses the control info to pass the source netw address to the
 * application layer
 *
 * @ingroup utils
 * @ingroup baseUtils
 * @ingroup netwLayer
 * @ingroup applLayer
 * @author Daniel Willkomm
 **/
class MIXIM_API NetwControlInfo : public cObject
{
  protected:
    /** @brief netw address of the sending or receiving node*/
    LAddress::L3Type netwAddr;
    /*
     * 07/09/2013 LSP
     * Add previous network address
     */
    LAddress::L3Type preNetwAddr;
    LAddress::L3Type AckForNetwAddr;
    /*
     * for counting the hop
     */
    int hops;
    bool isForwardData;
    bool isDataBroadcasted;

  public:
    /** @brief Default constructor*/
    NetwControlInfo(const LAddress::L3Type& addr)
    {
        netwAddr = addr;
    };
    NetwControlInfo(const LAddress::L3Type& addr, const LAddress::L3Type& preAddr)
    {
        netwAddr = addr;
        preNetwAddr = preAddr;

    };
    NetwControlInfo(const LAddress::L3Type& addr, const int hopCount)
    {
        netwAddr = addr;
        hops = hopCount;

    };
    NetwControlInfo(const LAddress::L3Type& addr, const bool forwardData, const LAddress::L3Type& preAddr)
        {
            netwAddr = addr;
            isForwardData = forwardData;
            preNetwAddr = preAddr;

        };
    NetwControlInfo(const LAddress::L3Type& addr, const LAddress::L3Type& preAddr, const LAddress::L3Type& AckForWhichAddr)
    {
            netwAddr = addr;
            preNetwAddr = preAddr;
            AckForNetwAddr= AckForWhichAddr;
    };
    NetwControlInfo(const LAddress::L3Type& addr, const LAddress::L3Type& preAddr, const LAddress::L3Type& AckForWhichAddr, const bool isSendDown, const bool isBroadcasted)
        {
                netwAddr = addr;
                preNetwAddr = preAddr;
                AckForNetwAddr= AckForWhichAddr;
                isForwardData = isSendDown;
                isDataBroadcasted = isBroadcasted;
        };

    /** @brief Destructor*/
    virtual ~NetwControlInfo(){};

    /** @brief Getter method*/
    virtual const LAddress::L3Type& getNetwAddr(){
        return netwAddr;
    };

    /** @brief Setter method*/
    virtual void setNetwAddr(const LAddress::L3Type& addr){
        netwAddr = addr;
    };

    virtual const LAddress::L3Type& getPreviousNetwAddr(){
        return preNetwAddr;
    };

    virtual const int getNetwHopCount()
    {
        return hops;
    }
    virtual void setNetwHopCount(const int hopCount)
    {
        hops = hopCount;
    }
    /** @brief Setter method*/
    virtual void setPreviousNetwAddr(const LAddress::L3Type& addr){
        preNetwAddr = addr;
    };
    virtual const LAddress::L3Type& getAckForWhichAddr(){
            return AckForNetwAddr;
        };

    virtual const bool isSensorDataForwarded(){
            return isForwardData;
        };
    virtual const bool isSensorDataBroadcastedBefore() {
        return isDataBroadcasted;
    }

    /** @brief Setter method*/
    virtual void setAckForWhichAddr(const LAddress::L3Type& addr){
        AckForNetwAddr = addr;
    };

    /**
     * @brief Attaches a "control info" structure (object) to the message pMsg.
     *
     * This is most useful when passing packets between protocol layers
     * of a protocol stack, the control info will contain the destination MAC address.
     *
     * The "control info" object will be deleted when the message is deleted.
     * Only one "control info" structure can be attached (the second
     * setL3ToL2ControlInfo() call throws an error).
     *
     * @param pMsg  The message where the "control info" shall be attached.
     * @param pAddr The network address of to save.
     */
    static cObject *const setControlInfo(cMessage *const pMsg, const LAddress::L3Type& pAddr) {
        NetwControlInfo *const cCtrlInfo = new NetwControlInfo(pAddr);
        pMsg->setControlInfo(cCtrlInfo);

        return cCtrlInfo;
    }

    static cObject *const setControlInfo(cMessage *const pMsg, const LAddress::L3Type& pAddr, const int hops) {
            NetwControlInfo *const cCtrlInfo = new NetwControlInfo(pAddr, hops);
            pMsg->setControlInfo(cCtrlInfo);

            return cCtrlInfo;
        }
    static cObject *const setControlInfo(cMessage *const pMsg, const LAddress::L3Type& pAddr, const LAddress::L3Type& previousAddr) {
                NetwControlInfo *const cCtrlInfo = new NetwControlInfo(pAddr, previousAddr);
                pMsg->setControlInfo(cCtrlInfo);

                return cCtrlInfo;
            }


    static cObject *const setControlInfo(cMessage *const pMsg, const LAddress::L3Type& pAddr, const LAddress::L3Type& previousAddr, const LAddress::L3Type& dataOrigin) {
               NetwControlInfo *const cCtrlInfo = new NetwControlInfo(pAddr, previousAddr,dataOrigin);
               pMsg->setControlInfo(cCtrlInfo);

               return cCtrlInfo;
           }
//    static cObject *const setControlACKInfo(cMessage *const pMsg, const LAddress::L3Type& pAddr, const LAddress::L3Type& previousAddr, const LAddress::L3Type& ACKForWhichAddr) {
//            NetwControlInfo *const cCtrlInfo = new NetwControlInfo(pAddr, previousAddr, ACKForWhichAddr);
//            pMsg->setControlInfo(cCtrlInfo);
//
//            return cCtrlInfo;
//        }
    static cObject *const setControlInfo(cMessage *const pMsg, const LAddress::L3Type& pAddr, const LAddress::L3Type& previousAddr, const LAddress::L3Type& dataOrigin, const bool isSendDown, const bool isBroadcasted){
        NetwControlInfo *const cCtrlInfo = new NetwControlInfo(pAddr, previousAddr,dataOrigin, isSendDown, isBroadcasted);
                      pMsg->setControlInfo(cCtrlInfo);

                      return cCtrlInfo;

    }
    /**
     * @brief extracts the address from "control info".
     */
    static const LAddress::L3Type& getAddressFromControlInfo(cObject *const pCtrlInfo) {
        NetwControlInfo *const cCtrlInfo = dynamic_cast<NetwControlInfo *const>(pCtrlInfo);

        if (cCtrlInfo)
            return cCtrlInfo->getNetwAddr();
        return LAddress::L3NULL;
    }

    static const LAddress::L3Type& getPreviousAddressFromControlInfo(cObject *const pCtrlInfo) {
        NetwControlInfo *const cCtrlInfo = dynamic_cast<NetwControlInfo *const>(pCtrlInfo);

        if (cCtrlInfo)
            return cCtrlInfo->getPreviousNetwAddr();
        return LAddress::L3NULL;
    }

    static const int getNetwHopCount(cObject *const pCtrlInfo) {
        NetwControlInfo *const cCtrlInfo = dynamic_cast<NetwControlInfo *const>(pCtrlInfo);

        if (cCtrlInfo)
            return cCtrlInfo->getNetwHopCount();
        return -1;
    }
    static const LAddress::L3Type& getAckForWhichAddr(cObject *const pCtrlInfo) {
        NetwControlInfo *const cCtrlInfo = dynamic_cast<NetwControlInfo *const>(pCtrlInfo);

        if (cCtrlInfo)
            return cCtrlInfo->getAckForWhichAddr();
        return LAddress::L3NULL;
    }
    static const bool isStillForwarding(cObject *const pCtrlInfo) {
            NetwControlInfo *const cCtrlInfo = dynamic_cast<NetwControlInfo *const>(pCtrlInfo);

            if (cCtrlInfo)
                return cCtrlInfo->isSensorDataForwarded();
            return false;
        }
    static const bool isBroadcastedBefore(cObject *const pCtrlInfo) {
        NetwControlInfo *const cCtrlInfo = dynamic_cast<NetwControlInfo *const>(pCtrlInfo);
        if(cCtrlInfo)
            return cCtrlInfo->isSensorDataBroadcastedBefore();
        return false;
    }
};


#endif
