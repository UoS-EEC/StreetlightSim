/*
 * StreetLightUtility.cc
 *
 *  Created on: 28 Feb 2013
 *      Author: spl1g11
 */

#include "StreetLightUtility.h"

StreetLightUtility::StreetLightUtility() {
    // TODO Auto-generated constructor stub

}

StreetLightUtility::~StreetLightUtility() {
    // TODO Auto-generated destructor stub
}

double StreetLightUtility::stoppingSightDistanceByFriction(double speed, double friction, double roadGradient)
{
    /*
     * RoadGradient is always zero is assumed.  It means the road is always flat.
     */
    roadGradient = 0;
    return ((speed * dblDriverReactionTime) + ((speed * speed)/ (2* dblGravitationalForce * (friction + roadGradient))));
}

double StreetLightUtility::stoppingSightDistanceByDeceleration(double speed, double deceleration, double roadGradient)
{
    /*
     * RoadGradient is always zero is assumed.  It means the road is always flat.
     */
    roadGradient = 0;
    return ((speed * dblDriverReactionTime) + ((speed * speed)/(2*(deceleration + roadGradient))));
}

double StreetLightUtility::utilityDriverOnSSD(double weight, double VL_Distance, double stopDistance)
{
    return weight*(VL_Distance/stopDistance);
}
double StreetLightUtility::utilityDriverOnVisibilityLevel(double weight, double totalCollectedVL, double VL_Distance, double VL_Design)
{
    return weight*(totalCollectedVL/(VL_Distance*VL_Design));
}

double utilityPedestrianOnProspect(double weight, double distanceBtwPole, double totalCollectedVL, double VL_Design)
{
    return weight/(distanceBtwPole*5*VL_Design)*totalCollectedVL;
}

double utilityPedestrianOnAvoid(double weight, double distanceBtwPole, double totalCollectedVL, double VL_Design )
{
    return weight/(distanceBtwPole*5*VL_Design)*totalCollectedVL ;
}

