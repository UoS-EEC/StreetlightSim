/*
 * StreetLightUtility.h
 *
 *  Created on: 28 Feb 2013
 *      Author: spl1g11
 */

#ifndef STREETLIGHTUTILITY_H_
#define STREETLIGHTUTILITY_H_

class StreetLightUtility {
public:

    static const double dblDriverReactionTime = 2.5;
    static const double dblGravitationalForce = 9.81;

    StreetLightUtility();
    virtual ~StreetLightUtility();

    double stoppingSightDistanceByFriction(double speed, double friction, double roadGradient);
    double stoppingSightDistanceByDeceleration(double speed, double deceleration, double roadGradient);
    double utilityDriverOnSSD(double weight, double VL_Distance, double stopDistance);
    double utilityDriverOnVisibilityLevel(double weight, double totalCollectedVL, double VL_Distance, double VL_Design);
    double utilityPedestrianOnProspect(double weight, double distanceBtwPole, double totalCollectedVL, double VL_Design);
    double utilityPedestrianOnAvoid(double weight, double distanceBtwPole, double totalCollectedVL, double VL_Design );
};

#endif /* STREETLIGHTUTILITY_H_ */
