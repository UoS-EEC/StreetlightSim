//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#ifndef __MIXIM_POWERUSAGE_H_
#define __MIXIM_POWERUSAGE_H_

#include <omnetpp.h>
#include <algorithm>
/**
 * TODO - Generated class
 */
class PowerUsage : public cSimpleModule, public cListener
{
  protected:
    virtual void initialize();
    virtual void handleMessage(cMessage *msg);
    //virtual void receiveSignal(cComponent* src, simsignal_t id, double d);
    virtual void finish();
    double updatePowerUsageByDistance(bool isWithinTheVisualRange, double distance);

    double powerUsed, powerUsed2;

    //simsignal_t poleStateChangedSignal;
    simsignal_t polePowerUsageSignal;
    double deviceWattage;
    bool isDimmable;

    int intPreCurTrafficProfileTimeStep;
    cXMLElement* dimmer_profile; /**< dimming profile */
    bool isUseStandaloneDimmerProfile;
    int intDimmerProfileCurrentStep;
    simtime_t intDimmerProfileStartTime ;
//    char colorCode[7] ;
    const char* strColourCode;
//    int HSB_Hue;
//    int HSB_Sat;
//    int HSB_Bright;

    bool debugPower;

  public:

    double updatePowerUsageByDimmerProfile();

    double updatePowerUsage(bool isWithinTheVisualRange, double distance);

    //to handle the power profile from XML
    int getPowerProfilesStepSize();
    double getPowerProfileStepPeriod(int stepNumber);
    double getPowerProfileStepDimValue(int stepNumber, const char** colour);
    double getPowerProfileStepDimValueByDistance(double dinstance, const char** colour);
    double getPowerProfileStepOverallMaxDistanceValue();
    char* getPowerUsageDimmerProfileStepColour(int stepNumber);
    double getPowerProfileDefaultDimValue(const char** colour);




};

#endif
