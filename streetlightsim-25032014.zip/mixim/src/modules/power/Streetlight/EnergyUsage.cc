//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#include "EnergyUsage.h"
#include <algorithm>

Define_Module(EnergyUsage);

#define HOURTIME 3600

void EnergyUsage::initialize()
{
    // TODO - Generated method body

    powerUsed = 0.0;
    powerUsed2 = 0;
    totalEnergyUsed = 0.0;

    deviceWattage = par("deviceWattage").doubleValue()/3600; //assuming it is W-s

    //isUseStandaloneDimmerProfile = par("isUseStandaloneDimmerProfile").boolValue();
    //ev<<"EnergyUsage::initialize:: deviceWattage in second :: " <<deviceWattage <<endl;

    poleEnergyUsageSignal = registerSignal("polePowerUsage");
    ev<<"PowerUsage::initialize:: polePowerUsageSignal ID : " <<poleEnergyUsageSignal <<endl;

    strColourCode = "red";
    dimmer_profile = par("dimmer_profile").xmlValue();

    debugPower = par("debug_Power").boolValue();

    dimPercentage = 0.0;
    dblZoningGPRSDelay_RoadUserDistance = 0.0;
    dblZoningGPRSDelayDuration = 0.0;
    dblCurZoningGPRSDelayDuration = 0.0;

    if(dimmer_profile != NULL)
    {
        intDimmerProfileCurrentStep = 0;
        simtime_t intDimmerProfileStartTime = simTime();
        ev<<"EnergyUsage::initialize()::load dimmer_profile : size :"<<getPowerProfilesStepSize()<<endl;
    }
    else
    {
        error("EnergyUsage::initialize()::Missing dimmer_profile");
    }

    /*
     * LSP - 18/04/2013
     * to determine whether to collect energy data by hour or by second.
     */

    intCollectEnergyByTimeStep = par("collectEnergyByTimeStep");
    intComputeEnergyUsageByTimeStep = 1; //compute the energy usage every one second;
    msgComputeEnergyUsage_timer = new cMessage("msgComputeEnergyUsage_timer");
    msgEmitAndRecordEnergyUsage_timer = new cMessage("msgEmitAndRecordEnergyUsage_timer");
    msgZoningOperationDelay_timer = new cMessage("msgZoningOperationDelay_timer");

    scheduleAt(simTime(),msgComputeEnergyUsage_timer);
    scheduleAt(simTime(),msgEmitAndRecordEnergyUsage_timer);

//    if (getPowerProfileStepOverallMaxDistanceValue () < 0 && !isUseStandaloneDimmerProfile)
//    {
//        error("EnergyUsage::initialize()::Missing dimmer_profile: Max Distance");
//
//    }


    /* 14/05/2012 LSP set the maxVisualDistance of myPoleMobility remotely by EnergyUsage Module**/
    intPreCurTrafficProfileTimeStep = 0;




}
EnergyUsage::~EnergyUsage()
{
    cancelAndDelete(msgComputeEnergyUsage_timer);
    cancelAndDelete(msgEmitAndRecordEnergyUsage_timer);
    cancelAndDelete(msgZoningOperationDelay_timer);
}
void EnergyUsage::finish()
{
    recordScalar("totalEnergyUsed",totalEnergyUsed);
    if(msgComputeEnergyUsage_timer->isScheduled())
    {
        cancelEvent(msgComputeEnergyUsage_timer);
        delete(msgComputeEnergyUsage_timer);
        msgComputeEnergyUsage_timer = 0;
    }
    if(msgEmitAndRecordEnergyUsage_timer->isScheduled())
    {
        cancelEvent(msgEmitAndRecordEnergyUsage_timer);
        delete(msgEmitAndRecordEnergyUsage_timer);
        msgEmitAndRecordEnergyUsage_timer = 0;
    }
    if(msgZoningOperationDelay_timer->isScheduled())
    {
        cancelEvent(msgZoningOperationDelay_timer);
        delete(msgZoningOperationDelay_timer);
        msgZoningOperationDelay_timer = 0;
    }
}
void EnergyUsage::handleSelfMsg(cMessage *msg)
{

    if(msg == msgComputeEnergyUsage_timer)
    {
        /*
         * 03/09/2013 - LSP
         * To record the total energy used at the end of the simulation
         */
        totalEnergyUsed += (deviceWattage * dimPercentage);

        powerUsed += (deviceWattage * dimPercentage);

        scheduleAt(simTime().dbl() + intComputeEnergyUsageByTimeStep, msg);
    }
    else if (msg == msgEmitAndRecordEnergyUsage_timer)
    {

        emit(poleEnergyUsageSignal,powerUsed);
        powerUsed = 0;
        scheduleAt(simTime().dbl() + intCollectEnergyByTimeStep, msg);
    }
    else if(msg == msgZoningOperationDelay_timer)
    {
        updateEnergyUsageZoningWithGPRSDelayOperation();
    }
}
void EnergyUsage::handleMessage(cMessage *msg)
{

    // TODO - Generated method body
    if(msg->isSelfMessage())
    {
        handleSelfMsg(msg);
    }

}
int  EnergyUsage::getPowerProfilesStepSize()
{
    return dimmer_profile->getChildren().size();
}

double EnergyUsage::getPowerProfileDefaultDimValue(const char** colour)
{
    double default_dim = 0.0;

    if (dimmer_profile->getAttribute("default_dim") == NULL || dimmer_profile->getAttribute("colour") == NULL)
    {
        //error("EnergyUsage::getPowerProfileDefaultDimValue:: Incomplete dimmer profile!");
        *colour = "black";
    }
    else
    {
        default_dim = atof( dimmer_profile->getAttribute("default_dim"));
        *colour = dimmer_profile->getAttribute("colour");
    }
    return default_dim;
}

double  EnergyUsage::getPowerProfileStepPeriod(int stepNumber)
{
    cXMLElementList dimmerProfileChildList= dimmer_profile->getChildren();
    for(cXMLElementList::iterator step = dimmerProfileChildList.begin(); step != dimmerProfileChildList.end(); step++)
    {
        if(atoi((*step)->getAttribute("num")) == stepNumber)
        {
            return atof((*step)->getAttribute("period"));
        }
    }
    return -1;
}

double  EnergyUsage::getPowerProfileStepDimValue(int stepNumber, const char** colour)
{
    cXMLElementList dimmerProfileChildList= dimmer_profile->getChildren();
    for(cXMLElementList::iterator step = dimmerProfileChildList.begin(); step != dimmerProfileChildList.end(); step++)
       {
           if(atoi((*step)->getAttribute("num")) == stepNumber)
           {
               *colour = (*step)->getAttribute("colour");
               return atof((*step)->getAttribute("dim"));

           }
       }
    return -1;
}

double EnergyUsage::getPowerProfileByHourAndMonth(int timeStep, int whichMonth, const char** colour)
{
    cXMLElementList dimmerProfileChildList= dimmer_profile->getChildren();
    //ev<<"EnergyUsage::getPowerProfileByHourAndMonth: month : "<<whichMonth <<", time : "<< timeStep<<endl;

    long lngOppPeriodFromXML = 0;
    int intOppDimValueFromXML = 0;
    std::string strOppColourFromXML = "";


    for(cXMLElementList::iterator step = dimmerProfileChildList.begin(); step != dimmerProfileChildList.end(); step++)
    {

        if(atoi((*step)->getAttribute("id")) == whichMonth && (*step)->hasChildren())
        {
            cXMLElementList dimmerProfileHour = (*step)->getChildren();
            lngOppPeriodFromXML = 0;
            intOppDimValueFromXML = 0;
            strOppColourFromXML = "";
            for(cXMLElementList::iterator itHour = dimmerProfileHour.begin(); itHour != dimmerProfileHour.end(); itHour++)
            {
                lngOppPeriodFromXML += atoi((*itHour)->getAttribute("period"));
                intOppDimValueFromXML = atoi((*itHour)->getAttribute("dim"));
                strOppColourFromXML = (*itHour)->getAttribute("colour");
                //ev<<"EnergyUsage::getPowerProfileByHourAndMonth: Period : "<<lngOppPeriodFromXML<<", dim value : "<< intOppDimValueFromXML<<", Colour : "<< strOppColourFromXML <<endl;
                if(timeStep <= lngOppPeriodFromXML)
                {
                    //ev<<"EnergyUsage::getPowerProfileByHourAndMonth: Month :"<<(*step)->getAttribute("id")<<" Period : "<<lngOppPeriodFromXML<<", dim value : "<< intOppDimValueFromXML<<", Colour : "<< strOppColourFromXML <<endl;
                    break;
                }
            }
        }
    }

    *colour = strOppColourFromXML.c_str();
    return intOppDimValueFromXML;

}

double  EnergyUsage::getPowerProfileStepDimValue(int stepNumber)
{
    cXMLElementList dimmerProfileChildList= dimmer_profile->getChildren();
    for(cXMLElementList::iterator step = dimmerProfileChildList.begin(); step != dimmerProfileChildList.end(); step++)
       {
           if(atoi((*step)->getAttribute("num")) == stepNumber)
           {
               return atof((*step)->getAttribute("dim"));
           }
       }
    return -1;
}

double EnergyUsage::getPowerProfileStepDimValueByDistance(double distance)
{
   double dimValue = -1;
   cXMLElementList dimmerProfileChildList= dimmer_profile->getChildren();
   //ev<<"EnergyUsage::getPowerProfileStepDimValueByDistance : distance :"<<distance <<endl;

   for(cXMLElementList::iterator step = dimmerProfileChildList.begin(); step != dimmerProfileChildList.end(); step++)
   {
       if ((*step)->getAttribute("minDistance") == NULL || (*step)->getAttribute("minDistance") == NULL)
       {
           error("EnergyUsage::getPowerProfileStepDimValueByDistance:: Incomplete dimmer profile!");
       }
       if(distance > atof((*step)->getAttribute("minDistance")) && distance <= atof((*step)->getAttribute("maxDistance")))
       {
           dimValue = atof((*step)->getAttribute("dim"));
       }
   }

   //ev<<"EnergyUsage::getPowerProfileStepDimValueByDistance::dimValue:"<<dimValue<< " colour : " << colour<<endl;
   return dimValue;
}

double EnergyUsage::getPowerProfileStepDimValueByDistance(double distance, const char** colour)
{
   double dimValue = -1;
   cXMLElementList dimmerProfileChildList= dimmer_profile->getChildren();
   //ev<<"EnergyUsage::getPowerProfileStepDimValueByDistance : distance :"<<distance <<endl;

   for(cXMLElementList::iterator step = dimmerProfileChildList.begin(); step != dimmerProfileChildList.end(); step++)
   {
       if ((*step)->getAttribute("minDistance") == NULL || (*step)->getAttribute("minDistance") == NULL)
       {
           error("EnergyUsage::getPowerProfileStepDimValueByDistance:: Incomplete dimmer profile!");
       }
       if(distance > atof((*step)->getAttribute("minDistance")) && distance <= atof((*step)->getAttribute("maxDistance")))
       {

           dimValue = atof((*step)->getAttribute("dim"));
           *colour = (*step)->getAttribute("colour");

       }
   }

   //ev<<"EnergyUsage::getPowerProfileStepDimValueByDistance::dimValue:"<<dimValue<< " colour : " << colour<<endl;
   return dimValue;
}
double EnergyUsage::updateEnergyUsageBySensorData(SensorData* data)
{


    ev<<"EnergyUsage::updateEnergyUsageBySensorData : The Sensor data has : "<<endl;
    ev<<"    isPedestrianInRange : "<<data->isPedestrianInRange << " ("<< data->dblDistPedestrian
             <<") : isCyclistInRange : " << data->isCyclistInRange << " ("<<data->dblDistCyclist
             <<") : isMotoristInRange : "<<data->isMotoristInRange <<" ("<<data->dblDistMotorist<<")"<<endl;
    ev<<"The msg originated from Lamp["<<data->dataOriginateFrom <<"] : GeoAddr : (" <<data->geoAddrLamppost.x<<","<<data->geoAddrLamppost.y<<")"<<endl;

       //update the energy usage if there is object approaching



    return 0.0;
}

//double EnergyUsage::getBrightnessLevelBasedOnDistance(double distance)
//{
//    if(isUseStandaloneDimmerProfile)
//      return getEnergyUsageByDimmerProfile();
//   else
//      return getEnergyUsageByDistance(distance);
//}
double EnergyUsage::updateEnergyUsageMultiSensor(double distance)
{
    Enter_Method_Silent();

    double tempDimValue = 0.0;

    if (distance > 0 && distance <=10)
    {
        tempDimValue = 0.0; //100% brightness
        strColourCode = "white";
    }
    else if (distance > 10 && distance <=20)
    {
        tempDimValue = 0.3; // at 70% brightness
        strColourCode = "yellow";
    }
    else //meaning the light is always at 40 % brightness
    {
        tempDimValue = 0.6;
        strColourCode = "green";
    }

    dimPercentage = 1 - tempDimValue;

    getParentModule()->getDisplayString().setTagArg("b",3,strColourCode);

    if(debugPower)
    {
        ev<<"EnergyUsage::updateEnergyUsageZoning : Pole ID : " << getParentModule()->getIndex() <<" :: deviceWattage : " <<deviceWattage << " :: dimPercentange : " <<dimPercentage << " :: Power Used : " << powerUsed << " Distance::"<<distance <<endl;
    }
    return dimPercentage;
}
double EnergyUsage::updateEnergyUsageZoning(double distance)
{
    Enter_Method_Silent();

    double tempDimValue = 0.0;

    if (distance > 0)
    {
        tempDimValue = 0.0;
        strColourCode = "white";
    }
    else //meaning the light is turn off
    {
        tempDimValue = 1.0;
        strColourCode = "black";
    }

    dimPercentage = 1 - tempDimValue;

    getParentModule()->getDisplayString().setTagArg("b",3,strColourCode);


    if(debugPower)
    {
        ev<<"EnergyUsage::updateEnergyUsageZoning : Pole ID : " << getParentModule()->getIndex() <<" :: deviceWattage : " <<deviceWattage << " :: dimPercentange : " <<dimPercentage << " :: Power Used : " << powerUsed << " Distance::"<<distance <<endl;
    }
    return dimPercentage;

}
/* this function is invoked by handleSelfMsg function */
void EnergyUsage::updateEnergyUsageZoningWithGPRSDelayOperation()
{
    Enter_Method_Silent();

    double tempDimValue = 0.0;

    if (dblZoningGPRSDelay_RoadUserDistance > 0)
    {
        tempDimValue = 0.0;
        strColourCode = "white";
    }
    else //meaning the light is turn off
    {
        tempDimValue = 1.0;
        strColourCode = "black";
    }

    dimPercentage = 1 - tempDimValue;

    getParentModule()->getDisplayString().setTagArg("b",3,strColourCode);


    if(debugPower)
    {
        ev<<"EnergyUsage::updateEnergyUsageZoning : Pole ID : " << getParentModule()->getIndex() <<" :: deviceWattage : " <<deviceWattage << " :: dimPercentange : " <<dimPercentage << " :: Power Used : " << powerUsed << " Distance::"<<dblZoningGPRSDelay_RoadUserDistance <<endl;
    }

}
double EnergyUsage::updateEnergyUsageZoningWithGPRSDelay(double distance, double delay)
{
    Enter_Method_Silent();

    double tempDimValue = 0.0;


    dblCurZoningGPRSDelayDuration =  delay + simTime().dbl() ;

    /*
     * check if the current delay is shorter than the scheduled.
     * If YES, cancel the scheduled timer and reschedule a new one
     */
    if(dblZoningGPRSDelayDuration > 0.0 && dblCurZoningGPRSDelayDuration < dblZoningGPRSDelayDuration)
    {
        if(msgZoningOperationDelay_timer->isScheduled())
        {
            cancelEvent(msgZoningOperationDelay_timer);
        }
        scheduleAt(dblCurZoningGPRSDelayDuration, msgZoningOperationDelay_timer);
        dblZoningGPRSDelay_RoadUserDistance = distance;
    }
    else if(!(msgZoningOperationDelay_timer->isScheduled()))
    {
        dblZoningGPRSDelayDuration = dblCurZoningGPRSDelayDuration;
        scheduleAt(dblCurZoningGPRSDelayDuration, msgZoningOperationDelay_timer);
        dblZoningGPRSDelay_RoadUserDistance = distance;
    }
    /*
    if (distance > 0)
    {
        tempDimValue = 0.0;
        strColourCode = "white";
    }
    else //meaning the light is turn off
    {
        tempDimValue = 1.0;
        strColourCode = "black";
    }

    dimPercentage = 1 - tempDimValue;

    getParentModule()->getDisplayString().setTagArg("b",3,strColourCode);


    if(debugPower)
    {
        ev<<"EnergyUsage::updateEnergyUsageZoning : Pole ID : " << getParentModule()->getIndex() <<" :: deviceWattage : " <<deviceWattage << " :: dimPercentange : " <<dimPercentage << " :: Power Used : " << powerUsed << " Distance::"<<distance <<endl;
    }
    */
    return dimPercentage;

}
//double EnergyUsage::updateEnergyUsage(bool isWithinTheVisualRange, double distance)
//{
//    Enter_Method_Silent();
//    /*need to have different function to handle different lighting strategies**/
//
//    /*Update the power usage based on the distance between lamp and car**/
//    if(isUseStandaloneDimmerProfile)
//       return updateEnergyUsageByDimmerProfile();
//    else
//        return updateEnergyUsageByDistance(isWithinTheVisualRange,distance);
//}

double EnergyUsage::getEnergyUsageByDimmerProfile()
{
    Enter_Method_Silent();

    double dimPercentage = 0.0;

    dimPercentage = 1- (getPowerProfileStepDimValue(intDimmerProfileCurrentStep)/100);

   return dimPercentage;

}
double EnergyUsage::updateEnergyUsageByDimmerProfileBasedOnHour(int whichHour, int whichMonth)
{
    int timeStep = whichHour*3600 + simTime().dbl() - 15;
    dimPercentage = 1- (getPowerProfileByHourAndMonth(timeStep, whichMonth, &strColourCode)/100);
    getParentModule()->getDisplayString().setTagArg("b",3,"white");
    return dimPercentage ;
}

//double EnergyUsage::updateEnergyUsageByDimmerProfile()
//{
//    Enter_Method_Silent();
//    simtime_t currentDPTotalTime =  simTime() - intDimmerProfileStartTime;
//    dimPercentage = 1- (getPowerProfileStepDimValue(intDimmerProfileCurrentStep, &strColourCode)/100);
//
//    //if(!isCollectEnergyByHour && (round(simTime().dbl()))>0)
//    //{
//        /*
//         * Previously was based on second.  Now collect the data hourly then emit the result.
//         *
//         * */
//    //    powerUsed = (deviceWattage * dimPercentage)/3600;
//    //    emit(poleEnergyUsageSignal,powerUsed);
//    //}
//    //else
//    //{
//        /*
//         * Collect the power usage hourly
//         */
//        if((round(simTime().dbl()))>0)
//        {
//            powerUsed += (deviceWattage * dimPercentage);
//        }
//
//        if(debugPower) ev<<"EnergyUsage::updateEnergyUsageByDimmerProfile():: Total power consumption: " << powerUsed <<endl;
//
//        /*
//         * Using modula (%) function based on HOURTIME (3600 second) to trigger the next
//         * profile step
//         */
//        //int intCurTrafficProfileTimeStep = (int)round((simTime().dbl()))%HOURTIME;
//
//        /*
//         * Change the traffic profile hourly
//         *
//        if(intCurTrafficProfileTimeStep == 0)
//            intPreCurTrafficProfileTimeStep = intCurTrafficProfileTimeStep;
//        */
//
//        /*
//         *Change the traffic profile hourly and
//         *emit the power usage hourly
//         */
//        //if(intCurTrafficProfileTimeStep == 0)
////        if((int)round((simTime().dbl())) % intCollectEnergyByTimeStep == 0)
////        {
////            if(debugPower) ev<<"EnergyUsage::updateEnergyUsageByDimmerProfile()::emit power used: " << powerUsed <<endl;
////             /*
////              *   emit(poleEnergyUsageSignal,powerUsed/HOURTIME) is to convert the value into Wh which can be post processed
////              *   The idea is to determine wheather it is turned ON and the brightness level
////              */
////            //emit(poleEnergyUsageSignal,powerUsed/HOURTIME);
////            emit(poleEnergyUsageSignal,powerUsed);
////            powerUsed = 0;
////            //intPreCurTrafficProfileTimeStep = intCurTrafficProfileTimeStep;
////        }
//   // }
//
//
//
//
////    getParentModule()->getDisplayString().setTagArg("r",1,strColourCode);
////    getParentModule()->getDisplayString().setTagArg("r",2,strColourCode);
//
//    getParentModule()->getDisplayString().setTagArg("b",3,strColourCode);
//
////    ev<<"EnergyUsage::updateEnergyUsageByDimmerProfile():: currentDPTotalTime : " << currentDPTotalTime.dbl() <<endl;
////    ev<<"EnergyUsage::updateEnergyUsageByDimmerProfile():: intDimmerProfileCurrentStep : " << intDimmerProfileCurrentStep <<endl;
//
//    /*
//     * Select the correct dimmer profile based on
//     *
//     */
//    if (currentDPTotalTime.dbl() >= getPowerProfileStepPeriod(intDimmerProfileCurrentStep))
//    {
//
//        if(intDimmerProfileCurrentStep < getPowerProfilesStepSize())
//            intDimmerProfileCurrentStep += 1;
//        else
//            intDimmerProfileCurrentStep = 1;
//
//        currentDPTotalTime = 0;
//        intDimmerProfileStartTime = simTime();
//    }
//    return dimPercentage;
//
//}
double EnergyUsage::getPowerProfileStepOverallMaxDistanceValue()
{
    double maxDistance = -1;

    cXMLElementList dimmerProfileChildList= dimmer_profile->getChildren();

    for(cXMLElementList::iterator step = dimmerProfileChildList.begin(); step != dimmerProfileChildList.end(); step++)
    {

        if((*step)->getAttribute("maxDistance") != NULL)
            maxDistance = std::max(maxDistance,atof((*step)->getAttribute("maxDistance")));
    }

    return maxDistance;
}

double EnergyUsage::getEnergyUsageByDistance(double distance)
{
        Enter_Method_Silent();

        double dimPercentage = -1;

        if(distance <= getPowerProfileStepOverallMaxDistanceValue())
        {
            dimPercentage = 1- (getPowerProfileStepDimValueByDistance(distance)/100);
        }
        return dimPercentage;
}

double EnergyUsage::updateEnergyUsageByDistancePedestrian(bool isWithinTheVisualRange, double distance)
{
        // double distanceBetweenCar = distance;
        //strColourCode = "black";
        /*based on the streetlight control analysis **/
        Enter_Method_Silent();

        //double dimPercentage = 1 - (getPowerProfileDefaultDimValue(&strColourCode)/100);
        if(distance < 0 )
            opp_error("EnergyUsage::updateEnergyUsageByDistancePedestrian: distance is less than 0");

        int brightnessIndex = 0;
        double distRatio = floor(distance/30.0);

        if(distRatio == 0)
            brightnessIndex = 0;
        else if ( distRatio > 0 && distRatio <= 5)
            brightnessIndex =(distRatio -1);
        else if (distRatio > 5)
            brightnessIndex = 5;

        //double dimPercentage = 1 - (getPowerProfileDefaultDimValue(&strColourCode)/100);
        dimPercentage = 1 - 0.2*brightnessIndex;

//        if(isWithinTheVisualRange)
//        {
//            if(distance <= getPowerProfileStepOverallMaxDistanceValue())
//            {
//                dimPercentage = 1- (getPowerProfileStepDimValueByDistance(distance, &strColourCode)/100);
//            }
//        }
    //    getParentModule()->getDisplayString().setTagArg("r",1,strColourCode);
    //    getParentModule()->getDisplayString().setTagArg("r",2,strColourCode);
/*
 *  <step num= "1" period = "0" dim = "80" maxDistance = "150" minDistance = "120" colour="#15317E" />
    <step num= "2" period = "0" dim = "60" maxDistance = "120" minDistance = "90" colour="blue" />
    <step num= "3" period = "0" dim = "40" maxDistance = "90" minDistance = "60" colour="green" />
    <step num= "4" period = "0" dim = "20" maxDistance = "60" minDistance = "30" colour="yellow" />
    <step num= "5" period = "0" dim = "0" maxDistance = "30" minDistance = "0" colour="white" />
 */

        switch(brightnessIndex)
        {
            case 0:
                strColourCode = "white";
                break;
            case 1:
                strColourCode = "yellow";
                break;
            case 2:
                strColourCode = "green";
                break;
            case 3:
                strColourCode = "blue";
                break;
            case 4:
                 strColourCode = "#15317E";
                 break;
            case 5:
                 strColourCode = "black";
                 break;

        }
        getParentModule()->getDisplayString().setTagArg("b",3,strColourCode);

        //if(!isCollectEnergyByHour)
        //{
            /*
             * Previously was based on second or can be based on hour
             * */
        //    powerUsed = (deviceWattage * dimPercentage)/3600;
        //    emit(poleEnergyUsageSignal,powerUsed);
        //}
        //else
        //{
            /*
             * Collect the power usage then check for current simtime
             * if rearch 1 hour then emit the power usage data
             */
//            powerUsed += (deviceWattage * dimPercentage);
//            //int intCurTrafficProfileTimeStep = (int)(simTime().dbl())/ HOURTIME;
//            int intCurTrafficProfileTimeStep = (int)(simTime().dbl())/intCollectEnergyByTimeStep;
//
//            if(intCurTrafficProfileTimeStep > intPreCurTrafficProfileTimeStep)
//            {
//                /*
//                 *   emit(poleEnergyUsageSignal,powerUsed/HOURTIME) is to convert the value into Wh which can be post processed
//                 *   The idea is to determine wheather it is turned ON and the brightness level
//                 */
//                emit(poleEnergyUsageSignal,powerUsed);
//                intPreCurTrafficProfileTimeStep = intCurTrafficProfileTimeStep;
//                powerUsed = 0;
//        //    }
//        }
        if(debugPower)
        {
            ev<<"EnergyUsage::updateEnergyUsageByDistanc : Pole ID : " << getParentModule()->getIndex() <<" :: deviceWattage : " <<deviceWattage << " :: dimPercentange : " <<dimPercentage << " :: Power Used : " << powerUsed << " Distance::"<<distance <<endl;
        }
        return dimPercentage;
}
double EnergyUsage::updateEnergyUsageByDefault(double dblDefaultDimPercentage)
{
    int brightnessIndex = (1 - dblDefaultDimPercentage)/0.2;
    dimPercentage = dblDefaultDimPercentage;
    //opp_warning("EnergyUsage::updateEnergyUsageByDefault:dimPercentage:%4.2f, brigtnessIndex:%d",dblDefaultDimPercentage,brightnessIndex);
    switch(brightnessIndex)
    {
        case 0:
            strColourCode = "white";
            break;
        case 1:
            strColourCode = "yellow";
            break;
        case 2:
            strColourCode = "green";
            break;
        case 3:
            strColourCode = "blue";
            break;
        case 4:
             strColourCode = "#15317E";
             break;
        case 5:
             strColourCode = "black";
             break;

    }
    getParentModule()->getDisplayString().setTagArg("b",3,strColourCode);

    return dblDefaultDimPercentage;
}
double EnergyUsage::updateEnergyUsageByDistanceMotorist(bool isWithinTheVisualRange, double distance)
{
        // double distanceBetweenCar = distance;
        //strColourCode = "black";
        /*based on the streetlight control analysis **/
        Enter_Method_Silent();

        //double dimPercentage = 1 - (getPowerProfileDefaultDimValue(&strColourCode)/100);
        if(distance < 0 )
            opp_error("EnergyUsage::updateEnergyUsageByDistancePedestrian: distance is less than 0");

        int brightnessIndex = 0;
        double distRatio = floor(distance/30.0);

        if(distRatio <= 4)
            brightnessIndex = 0;
        else if ( distRatio > 4)
            brightnessIndex = 1;


        //double dimPercentage = 1 - (getPowerProfileDefaultDimValue(&strColourCode)/100);
        dimPercentage = 1 - brightnessIndex;

//        if(isWithinTheVisualRange)
//        {
//            if(distance <= getPowerProfileStepOverallMaxDistanceValue())
//            {
//                dimPercentage = 1- (getPowerProfileStepDimValueByDistance(distance, &strColourCode)/100);
//            }
//        }
    //    getParentModule()->getDisplayString().setTagArg("r",1,strColourCode);
    //    getParentModule()->getDisplayString().setTagArg("r",2,strColourCode);
/*
 *  <step num= "1" period = "0" dim = "80" maxDistance = "150" minDistance = "120" colour="#15317E" />
    <step num= "2" period = "0" dim = "60" maxDistance = "120" minDistance = "90" colour="blue" />
    <step num= "3" period = "0" dim = "40" maxDistance = "90" minDistance = "60" colour="green" />
    <step num= "4" period = "0" dim = "20" maxDistance = "60" minDistance = "30" colour="yellow" />
    <step num= "5" period = "0" dim = "0" maxDistance = "30" minDistance = "0" colour="white" />
 */

        switch(brightnessIndex)
        {
            case 0:
                strColourCode = "white";
                break;
            case 1:
                 strColourCode = "black";
                 break;

        }
        getParentModule()->getDisplayString().setTagArg("b",3,strColourCode);

        //if(!isCollectEnergyByHour)
        //{
            /*
             * Previously was based on second or can be based on hour
             * */
        //    powerUsed = (deviceWattage * dimPercentage)/3600;
        //    emit(poleEnergyUsageSignal,powerUsed);
        //}
        //else
        //{
            /*
             * Collect the power usage then check for current simtime
             * if rearch 1 hour then emit the power usage data
             */
//            powerUsed += (deviceWattage * dimPercentage);
//            //int intCurTrafficProfileTimeStep = (int)(simTime().dbl())/ HOURTIME;
//            int intCurTrafficProfileTimeStep = (int)(simTime().dbl())/intCollectEnergyByTimeStep;
//
//            if(intCurTrafficProfileTimeStep > intPreCurTrafficProfileTimeStep)
//            {
//                /*
//                 *   emit(poleEnergyUsageSignal,powerUsed/HOURTIME) is to convert the value into Wh which can be post processed
//                 *   The idea is to determine wheather it is turned ON and the brightness level
//                 */
//                emit(poleEnergyUsageSignal,powerUsed);
//                intPreCurTrafficProfileTimeStep = intCurTrafficProfileTimeStep;
//                powerUsed = 0;
//        //    }
//        }
        if(debugPower)
        {
            ev<<"EnergyUsage::updateEnergyUsageByDistanc : Pole ID : " << getParentModule()->getIndex() <<" :: deviceWattage : " <<deviceWattage << " :: dimPercentange : " <<dimPercentage << " :: Power Used : " << powerUsed << " Distance::"<<distance <<endl;
        }
        return dimPercentage;
}


double EnergyUsage::updateEnergyUsageByDistanceMixTraffic(bool isWithinTheVisualRange, double distPedestrian, double distMotorist)
{
        // double distanceBetweenCar = distance;
        //strColourCode = "black";
        /*based on the streetlight control analysis **/
        Enter_Method_Silent();
        dimPercentage = std::max(updateEnergyUsageByDistancePedestrian(isWithinTheVisualRange, distPedestrian),updateEnergyUsageByDistanceMotorist(isWithinTheVisualRange,distMotorist));
        return dimPercentage;

}
double EnergyUsage::updateEnergyUsageByDistanceTurnOff()
{
    Enter_Method_Silent();
    getParentModule()->getDisplayString().setTagArg("b",3,"black");
    //int intCurTrafficProfileTimeStep = (int)(simTime().dbl())/intCollectEnergyByTimeStep;

    dimPercentage = 0.0;

    if(debugPower)
    {
        ev<<"EnergyUsage::updateEnergyUsageByDistanc : Pole ID : " << getParentModule()->getIndex() <<" :: deviceWattage : " <<deviceWattage << " :: dimPercentange : 0 "<< " :: Power Used : " << powerUsed << " Distance : 0" <<endl;
    }
    return 0;
}

double EnergyUsage::updateEnergyUsageByDistance(bool isWithinTheVisualRange, double distance)
{
   // double distanceBetweenCar = distance;
    //strColourCode = "black";
    /*if dimPercentage = 1, lamp is 100% brightness, 0 means lamp is completely switched off **/
    Enter_Method_Silent();

    dimPercentage = 1 - (getPowerProfileDefaultDimValue(&strColourCode)/100);

    if(isWithinTheVisualRange)
    {
        if(distance <= getPowerProfileStepOverallMaxDistanceValue())
        {
            dimPercentage = 1- (getPowerProfileStepDimValueByDistance(distance, &strColourCode)/100);
        }
    }
//    getParentModule()->getDisplayString().setTagArg("r",1,strColourCode);
//    getParentModule()->getDisplayString().setTagArg("r",2,strColourCode);

    getParentModule()->getDisplayString().setTagArg("b",3,strColourCode);


    if(debugPower)
    {
        ev<<"EnergyUsage::updateEnergyUsageByDistanc : Pole ID : " << getParentModule()->getIndex() <<" :: deviceWattage : " <<deviceWattage << " :: dimPercentange : " <<dimPercentage << " :: Power Used : " << powerUsed << " Distance::"<<distance <<endl;
    }
    return dimPercentage;
}

