//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#ifndef __MIXIM_ENERGYUSAGE_H_
#define __MIXIM_ENERGYUSAGE_H_

#include <omnetpp.h>
#include <algorithm>

#include "SensorData.h"

/**
 * TODO - Generated class
 */
class EnergyUsage : public cSimpleModule, public cListener
{
  protected:
    enum roadUserType { MOTORIST = 0, CYCLIST = 1, PEDESTRIAN = 2 };

    virtual void initialize();
    virtual void handleMessage(cMessage *msg);
    virtual void handleSelfMsg(cMessage *msg);
    //virtual void receiveSignal(cComponent* src, simsignal_t id, double d);
    virtual void finish();

    cMessage* msgComputeEnergyUsage_timer;
    cMessage* msgEmitAndRecordEnergyUsage_timer;
    cMessage* msgZoningOperationDelay_timer;
    double powerUsed, powerUsed2;
    double totalEnergyUsed;

    //simsignal_t poleStateChangedSignal;
    simsignal_t poleEnergyUsageSignal;
    double deviceWattage;
    bool isDimmable;
    /*
     * LSP 18/04/2013
     * to determine whether to collect energy data by hour or by second.
     */
    //bool isCollectEnergyByHour;
    int intCollectEnergyByTimeStep;
    int intComputeEnergyUsageByTimeStep;
    double dimPercentage;
    double dblZoningGPRSDelay_RoadUserDistance;
    double dblZoningGPRSDelayDuration;
    double dblCurZoningGPRSDelayDuration;

    int intPreCurTrafficProfileTimeStep;
    cXMLElement* dimmer_profile; /**< dimming profile */
    //bool isUseStandaloneDimmerProfile;
    int intDimmerProfileCurrentStep;
    simtime_t intDimmerProfileStartTime ;
//    char colorCode[7] ;
    const char* strColourCode;
//    int HSB_Hue;
//    int HSB_Sat;
//    int HSB_Bright;

    bool debugPower;

  public:
    ~EnergyUsage();
    //double updateEnergyUsageByDimmerProfile();
    double updateEnergyUsageByDimmerProfileBasedOnHour(int whichHour, int whichMonth);
    double getEnergyUsageByDimmerProfile();

    //double updateEnergyUsage(bool isWithinTheVisualRange, double distance);
    double updateEnergyUsageZoning(double distance);
    double updateEnergyUsageZoningWithGPRSDelay(double distance, double delay);
    void updateEnergyUsageZoningWithGPRSDelayOperation();
    double updateEnergyUsageMultiSensor(double distance);
    //double getBrightnessLevelBasedOnDistance(double distance);
    double updateEnergyUsageBySensorData(SensorData* data);

    //to handle the power profile from XML
    int getPowerProfilesStepSize();
    double getPowerProfileStepPeriod(int stepNumber);
    double getPowerProfileStepDimValue(int stepNumber, const char** colour);
    double getPowerProfileStepDimValue(int stepNumber);
    double getPowerProfileByHourAndMonth(int timeStep, int whihcMonth, const char** colour);
    double getPowerProfileStepDimValueByDistance(double dinstance, const char** colour);
    double getPowerProfileStepDimValueByDistance(double dinstances);
    double getPowerProfileStepOverallMaxDistanceValue();
    char* getEnergyUsageDimmerProfileStepColour(int stepNumber);
    double getPowerProfileDefaultDimValue(const char** colour);
    double updateEnergyUsageByDistance(bool isWithinTheVisualRange, double distance);
    double updateEnergyUsageByDistancePedestrian(bool isWithinTheVisualRange, double distance);
    double updateEnergyUsageByDistanceMotorist(bool isWithinTheVisualRange, double distance);
    double updateEnergyUsageByDistanceMixTraffic(bool isWithinTheVisualRange, double distPedestrian, double distMotorist);
    double updateEnergyUsageByDistanceTurnOff();
    double getEnergyUsageByDistance(double distance);
/*
 * Used for analysing the streetlight utility case study.
 */
    double updateEnergyUsageByDefault(double dblDefaultDimPercentage);


};

#endif
