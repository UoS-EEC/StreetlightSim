//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#include "PowerUsage.h"

Define_Module(PowerUsage);

#define HOURTIME 3600

void PowerUsage::initialize()
{
    // TODO - Generated method body
    powerUsed = 0.0;
    powerUsed2 = 0;
    deviceWattage = par("deviceWattage").doubleValue();

    isUseStandaloneDimmerProfile = par("isUseStandaloneDimmerProfile").boolValue();
    //ev<<"PowerUsage::initialize:: deviceWattage in second :: " <<deviceWattage <<endl;

    polePowerUsageSignal = registerSignal("polePowerUsage");
    ev<<"PowerUsage::initialize:: polePowerUsageSignal ID : " <<polePowerUsageSignal <<endl;

    strColourCode = "red";
    dimmer_profile = par("dimmer_profile").xmlValue();

    debugPower = par("debug_Power").boolValue();

    if(dimmer_profile != NULL)
    {
        intDimmerProfileCurrentStep = 0;
        simtime_t intDimmerProfileStartTime = simTime();
        ev<<"PowerUsage::initialize()::load dimmer_profile : size :"<<getPowerProfilesStepSize()<<endl;
    }
    else
        error("PowerUsage::initialize()::Missing dimmer_profile");
    if (getPowerProfileStepOverallMaxDistanceValue () < 0)
        error("PowerUsage::initialize()::Missing dimmer_profile: Max Distance");

    /* 14/05/2012 LSP set the maxVisualDistance of myPoleMobility remotely by PowerUsage Module**/
    intPreCurTrafficProfileTimeStep = 0;


}
void PowerUsage::finish()
{

}
void PowerUsage::handleMessage(cMessage *msg)
{
    // TODO - Generated method body
}
int  PowerUsage::getPowerProfilesStepSize()
{
    return dimmer_profile->getChildren().size();
}

double PowerUsage::getPowerProfileDefaultDimValue(const char** colour)
{
    double default_dim = 0.0;

    if (dimmer_profile->getAttribute("default_dim") == NULL || dimmer_profile->getAttribute("colour") == NULL)
    {
        //error("PowerUsage::getPowerProfileDefaultDimValue:: Incomplete dimmer profile!");
        *colour = "black";
    }
    else
    {
        default_dim = atof( dimmer_profile->getAttribute("default_dim"));
        *colour = dimmer_profile->getAttribute("colour");
    }
    return default_dim;
}

double  PowerUsage::getPowerProfileStepPeriod(int stepNumber)
{
    cXMLElementList dimmerProfileChildList= dimmer_profile->getChildren();
    for(cXMLElementList::iterator step = dimmerProfileChildList.begin(); step != dimmerProfileChildList.end(); step++)
    {
        if(atoi((*step)->getAttribute("num")) == stepNumber)
        {
            return atof((*step)->getAttribute("period"));
        }
    }
    return -1;
}
double  PowerUsage::getPowerProfileStepDimValue(int stepNumber, const char** colour)
{
    cXMLElementList dimmerProfileChildList= dimmer_profile->getChildren();
    for(cXMLElementList::iterator step = dimmerProfileChildList.begin(); step != dimmerProfileChildList.end(); step++)
       {
           if(atoi((*step)->getAttribute("num")) == stepNumber)
           {
               *colour = (*step)->getAttribute("colour");
               return atof((*step)->getAttribute("dim"));

           }
       }
    return -1;
}

double PowerUsage::getPowerProfileStepDimValueByDistance(double distance, const char** colour)
{
   double dimValue = -1;
   cXMLElementList dimmerProfileChildList= dimmer_profile->getChildren();
   //ev<<"PowerUsage::getPowerProfileStepDimValueByDistance : distance :"<<distance <<endl;

   for(cXMLElementList::iterator step = dimmerProfileChildList.begin(); step != dimmerProfileChildList.end(); step++)
   {
       if ((*step)->getAttribute("minDistance") == NULL || (*step)->getAttribute("minDistance") == NULL)
       {
           error("PowerUsage::getPowerProfileStepDimValueByDistance:: Incomplete dimmer profile!");
       }
       if(distance > atof((*step)->getAttribute("minDistance")) && distance <= atof((*step)->getAttribute("maxDistance")))
       {

           dimValue = atof((*step)->getAttribute("dim"));
           *colour = (*step)->getAttribute("colour");

       }
   }

   //ev<<"PowerUsage::getPowerProfileStepDimValueByDistance::dimValue:"<<dimValue<< " colour : " << colour<<endl;
   return dimValue;
}

double PowerUsage::updatePowerUsage(bool isWithinTheVisualRange, double distance)
{
    Enter_Method_Silent();
    /*need to have different function to handle different lighting strategies**/

    /*Update the power usage based on the distance between lamp and car**/
    if(isUseStandaloneDimmerProfile)
       return updatePowerUsageByDimmerProfile();
    else
        return updatePowerUsageByDistance(isWithinTheVisualRange,distance);
}
double PowerUsage::updatePowerUsageByDimmerProfile()
{
    Enter_Method_Silent();
    simtime_t currentDPTotalTime =  simTime() - intDimmerProfileStartTime;
    double dimPercentage = 0.0;

    //ev<<"PowerUsage::updatePowerUsageByDimmerProfile() :: longCurrentDPTotalTime : " << currentDPTotalTime <<endl;
    dimPercentage = 1- (getPowerProfileStepDimValue(intDimmerProfileCurrentStep, &strColourCode)/100);

    /*
     * Previously was based on second.  Now collect the data hourly then emit the result.
     *
     * */
    powerUsed = (deviceWattage * dimPercentage);
    emit(polePowerUsageSignal,powerUsed);

    /*
     * Collect the power usage hourly
     */

    /*if((round(simTime().dbl()))>0)
    {
        powerUsed += (deviceWattage * dimPercentage);
    }
    */
    if(debugPower) ev<<"PowerUsage::updatePowerUsageByDimmerProfile():: Total power consumption: " << powerUsed <<endl;

    /*
     * Using modula (%) function based on HOURTIME (3600 second) to trigger the next
     * profile step
     */
    int intCurTrafficProfileTimeStep = (int)round((simTime().dbl()))%HOURTIME;

    /*
     * Change the traffic profile hourly
     *
    if(intCurTrafficProfileTimeStep == 0)
        intPreCurTrafficProfileTimeStep = intCurTrafficProfileTimeStep;
    */

    /*
     *Change the traffic profile hourly and
     *emit the power usage hourly
     */

    if(intCurTrafficProfileTimeStep == 0)
    {
        if(debugPower) ev<<"PowerUsage::updatePowerUsageByDimmerProfile()::emit power used: " << powerUsed <<endl;
        //emit(polePowerUsageSignal,powerUsed);
        //powerUsed = 0;
        intPreCurTrafficProfileTimeStep = intCurTrafficProfileTimeStep;

    }


    getParentModule()->getDisplayString().setTagArg("r",1,strColourCode);
    getParentModule()->getDisplayString().setTagArg("r",2,strColourCode);

//    ev<<"PowerUsage::updatePowerUsageByDimmerProfile():: currentDPTotalTime : " << currentDPTotalTime.dbl() <<endl;
//    ev<<"PowerUsage::updatePowerUsageByDimmerProfile():: intDimmerProfileCurrentStep : " << intDimmerProfileCurrentStep <<endl;

    /*
     * Select the correct dimmer profile based on
     *
     */
    if (currentDPTotalTime.dbl() >= getPowerProfileStepPeriod(intDimmerProfileCurrentStep))
    {

        if(intDimmerProfileCurrentStep < getPowerProfilesStepSize())
            intDimmerProfileCurrentStep += 1;
        else
            intDimmerProfileCurrentStep = 1;

        currentDPTotalTime = 0;
        intDimmerProfileStartTime = simTime();
    }
    return dimPercentage;

}
double PowerUsage::getPowerProfileStepOverallMaxDistanceValue()
{
    double maxDistance = -1;
    cXMLElementList dimmerProfileChildList= dimmer_profile->getChildren();
    for(cXMLElementList::iterator step = dimmerProfileChildList.begin(); step != dimmerProfileChildList.end(); step++)
    {
        maxDistance = std::max(maxDistance,atof((*step)->getAttribute("maxDistance")));
    }
    return maxDistance;
}



double PowerUsage::updatePowerUsageByDistance(bool isWithinTheVisualRange, double distance)
{
   // double distanceBetweenCar = distance;
    //strColourCode = "black";
    /*if dimPercentage = 1, lamp is 100% brightness, 0 means lamp is completely switched off **/
    Enter_Method_Silent();

    double dimPercentage = 1 - (getPowerProfileDefaultDimValue(&strColourCode)/100);

    if(isWithinTheVisualRange)
    {
        if(distance <= getPowerProfileStepOverallMaxDistanceValue())
        {
            dimPercentage = 1- (getPowerProfileStepDimValueByDistance(distance, &strColourCode)/100);
        }
    }
    getParentModule()->getDisplayString().setTagArg("r",1,strColourCode);
    getParentModule()->getDisplayString().setTagArg("r",2,strColourCode);


    /*
     * Previously was based on second or can be based on hour
     * */
    powerUsed = (deviceWattage * dimPercentage);
    emit(polePowerUsageSignal,powerUsed);

    if(debugPower)
    {
        ev<<"PowerUsage::updatePowerUsageByDistanc : Pole ID : " << getParentModule()->getIndex() <<" :: deviceWattage : " <<deviceWattage << " :: dimPercentange : " <<dimPercentage << " :: Power Used : " << powerUsed << " Distance::"<<distance <<endl;
    }
    /*
     * Collect the power usage then check for current simtime
     * if rearch 1 hour then emit the power usage data
     */
/*
    powerUsed += (deviceWattage * dimPercentage);
    int intCurTrafficProfileTimeStep = (int)(simTime().dbl())/ HOURTIME;

    if(intCurTrafficProfileTimeStep > intPreCurTrafficProfileTimeStep)
    {
        emit(polePowerUsageSignal,powerUsed);
        intPreCurTrafficProfileTimeStep = intCurTrafficProfileTimeStep;
        powerUsed = 0;
    }

*/

    return dimPercentage;
}

