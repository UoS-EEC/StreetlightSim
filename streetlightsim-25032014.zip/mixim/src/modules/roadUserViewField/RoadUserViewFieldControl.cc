//
// ObstacleControl - models obstacles that block radio transmissions
// Copyright (C) 2010 Christoph Sommer <christoph.sommer@informatik.uni-erlangen.de>
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//

#include <sstream>
#include <map>
#include <set>

#include "roadUserViewField/RoadUserViewFieldControl.h"


Define_Module(RoadUserViewFieldControl);

RoadUserViewFieldControl::~RoadUserViewFieldControl() {

}

void RoadUserViewFieldControl::initialize(int stage) {
	if (stage == 1)	{
		debug = par("debug");
		annotations = AnnotationManagerAccess().getIfExists();
		if (annotations) annotationGroup = annotations->createGroup("inividualViewField");

	}
}

void RoadUserViewFieldControl::finish() {

}

void RoadUserViewFieldControl::handleMessage(cMessage *msg) {
	if (msg->isSelfMessage()) {
		handleSelfMsg(msg);
		return;
	}
	error("RoadUserViewFieldControl doesn't handle messages from other modules");
}

void RoadUserViewFieldControl::handleSelfMsg(cMessage *msg) {
	error("RoadUserViewFieldControl doesn't handle self-messages");
}

void RoadUserViewFieldControl::add(RoadUserViewField viewField) {
    RoadUserViewField* v = new RoadUserViewField(viewField);
    if (annotations) v->viewFieldRepresentation = annotations->drawPolygon(v->getShape(), "red", annotationGroup);
}

void RoadUserViewFieldControl::erase(const RoadUserViewField* viewField) {

}

