//
// ObstacleControl - models obstacles that block radio transmissions
// Copyright (C) 2006 Christoph Sommer <christoph.sommer@informatik.uni-erlangen.de>
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//


#ifndef ROADUSERVIEWFIELD_ROADUSERVIEWFIELD_H
#define ROADUSERVIEWFIELD_ROADUSERVIEWFIELD_H

#include <vector>
#include "Coord.h"
#include "world/annotations/AnnotationManager.h"

/**
 * stores information about an view field
 */
class RoadUserViewField {
	public:
		typedef std::vector<Coord> Coords;

		RoadUserViewField(std::string id);
		std::string getID();
		const Coords& getShape() const;
		AnnotationManager::Annotation* viewFieldRepresentation;

	protected:
		std::string id;
		Coords coords;

};

#endif
