/***************************************************************************
 * file:        Aggregation.h
 *
 * author:      Jerome Rousselot <jerome.rousselot@csem.ch>
 *
 * copyright:   (C) 2010 CSEM SA, Neuchatel, Switzerland.
 *
 *              This program is free software; you can redistribute it
 *              and/or modify it under the terms of the GNU General Public
 *              License as published by the Free Software Foundation; either
 *              version 2 of the License, or (at your option) any later
 *              version.
 *              For further information see file COPYING
 *              in the top level directory
 ***************************************************************************
 * description: this class aggregates the packets received from the application
 * layer and separates packet emissions by a time InterPacketDelay.
 ***************************************************************************/


#ifndef STREETLIGHTDUMMYTRANSPORT_H_
#define STREETLIGHTDUMMYTRANSPORT_H_

#include <omnetpp.h>

#include "MiXiMDefs.h"
#include "BaseLayer.h"


class MIXIM_API StreetlightDummyTransport: public BaseLayer {
public:
    StreetlightDummyTransport();
	virtual void initialize(int);
	virtual void finish();
protected:
	    virtual void handleSelfMsg(cMessage* msg);
	    virtual void handleUpperMsg(cMessage *msg);
	    virtual void handleLowerMsg(cMessage *msg);
	    virtual void handleLowerControl(cMessage *msg);
	    virtual void handleUpperControl(cMessage *msg);
};

#endif
