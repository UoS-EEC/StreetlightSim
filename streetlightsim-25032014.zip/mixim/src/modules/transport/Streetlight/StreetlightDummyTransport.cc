#include "StreetlightDummyTransport.h"


Define_Module(StreetlightDummyTransport);

StreetlightDummyTransport::StreetlightDummyTransport()
{

}
void StreetlightDummyTransport::initialize(int stage) {
    BaseLayer::initialize(stage);
}


void StreetlightDummyTransport::handleUpperMsg(cMessage* msg) {
		sendDown(msg);

}

void StreetlightDummyTransport::handleLowerMsg(cMessage * msg) {
		sendUp(msg);
}

void StreetlightDummyTransport::handleSelfMsg(cMessage* msg) {

}

void StreetlightDummyTransport::finish() {

}

void StreetlightDummyTransport::handleLowerControl(cMessage *msg) {
	sendControlUp(msg);
}

void StreetlightDummyTransport::handleUpperControl(cMessage *msg) {
	sendControlDown(msg);
}
