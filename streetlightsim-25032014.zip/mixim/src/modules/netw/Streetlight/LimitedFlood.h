/* -*- mode:c++ -*- ********************************************************
 * file:        Flood.h
 *
 * author:      Daniel Willkomm
 *
 * copyright:   (C) 2004 Telecommunication Networks Group (TKN) at
 *              Technische Universitaet Berlin, Germany.
 *
 *              This program is free software; you can redistribute it 
 *              and/or modify it under the terms of the GNU General Public 
 *              License as published by the Free Software Foundation; either
 *              version 2 of the License, or (at your option) any later 
 *              version.
 *              For further information see file COPYING 
 *              in the top level directory
 *
 ***************************************************************************
 * part of:     framework implementation developed by tkn
 * description: a simple flooding protocol
 *              the user can decide whether to use plain flooding or not
 **************************************************************************/


#ifndef _LIMITEDFLOOD_H_
#define _LIMITEDFLOOD_H_

#include <list>
#include <vector>

#include "MiXiMDefs.h"
#include "BaseNetwLayer.h"
#include "SimpleAddress.h"
#include "BaseDecider.h"
#include "MacPkt_m.h"
#include "StreetlightApplPkt_m.h"
#include "LimitedFloodPkt_m.h"
#include "Coord.h"
/**
 * @brief A simple flooding protocol
 *
 * This implementation uses plain flooding, i.e. it "remembers"
 * (stores) already broadcasted messages in a list and does not
 * rebroadcast them again, if it gets another copy of that message.
 *
 * The maximum number of entires for that list can be defined in the
 * .ini file (@ref bcMaxEntries) as well as the time after which an entry
 * is deleted (@ref bcDelTime).
 *
 * If you prefere a memory-less version you can comment out the 
 * @verbatim #define PLAINFLOODING @endverbatim
 *
 * @ingroup netwLayer
 * @author Daniel Willkomm
 *
 * ported to Mixim 2.0 by Theodoros Kapourniotis
 **/
class MIXIM_API LimitedFlood : public BaseNetwLayer
{
protected:
    /** @brief Network layer sequence number*/
    unsigned long seqNum;

    /** @brief Default time-to-live (ttl) used for this module*/
    int defaultTtl;

    /** Default time-to-live (ttl) used for neighbour nodes discovery */
    int defaultNeighbourDiscoveryTtl;

    /**@brief flooding type used for this module.  There are:
     * PLAIN_FLOOD (a ordinary flooding)
     * STREET_TOPO_LIMITED (based on streetlight topology)
     * DISTANCE_LIMITED (based on distance from the source)
     * */
    std::string strFloodOppType;
    int intLimitedDistance;
    //bool isWithAck;

    /** @brief Defines whether to use plain flooding or not*/
    bool isPlain;

    class Bcast {
    public:
        unsigned long    seqNum;
        LAddress::L3Type srcAddr;
        simtime_t        delTime;
    public:
        Bcast(unsigned long n=0, const LAddress::L3Type& s = LAddress::L3NULL,  simtime_t_cref d=SIMTIME_ZERO) :
            seqNum(n), srcAddr(s), delTime(d) {
        }
    };

    typedef std::list<Bcast> cBroadcastList;

    /** @brief List of already broadcasted messages*/
    cBroadcastList bcMsgs;

    /**
     * @brief Max number of entries in the list of already broadcasted
     * messages
     **/
    unsigned int bcMaxEntries;

    /** 
     * @brief Time after which an entry for an already broadcasted msg
     * can be deleted
     **/
    simtime_t bcDelTime;

    /* 24/06/2013 LSP
     *
     * the triggerTrafficModelSignal is used to trigger the traffic model at SUMOTraCI Scenario Manager
     *
     * */
    //simsignal_t triggerTrafficModelSignal;
    //bool    isNeighbourDiscoveryEnd;
    int intNetwDiscoveryDuration;
    int intTotalNetwDiscoveryElapsed;

    int intMyRoadId;
    bool isAtJunction;
    Coord myGeoAddr;
    bool isSendDown;
    bool isBroadcasted;

public:

    ~LimitedFlood();
    /** @brief Initialization of omnetpp.ini parameters*/
    virtual void initialize(int);
    virtual void finish();

    void receiveSignal(cComponent *source, simsignal_t signalID, long l );

    enum MessagesTypes {
               UNKNOWN=0,
               DATA_MSG,
               NEIGHBOUR_DISCOVERY,
               NEIGHBOUR_DISCOVERY_TIMER,
           };

    enum FloodOppTypes {
        TTL_LIMITED = 0,
        DISTANCE_TO_SOURCE_LIMITED,
        DISTANCE_TRAVELLED_LIMITED,
        STREET_TOPO_LIMITED,
        BIT_ERROR_TEST,
    };

protected:

    long nbDataPacketsReceived;
    long nbDataPacketsSent;
    unsigned long nbACKPacketSent;
    long nbDataPacketsForwarded;
    long nbHops;
    long nbDataPacketsDropped;
//    long nbRxDataFrameTest;
//    long nbRxDataFrameTestMyNetwAddr;
//    long nbRxDataFrameTestMyNetwAddrElse;

    /** @brief Handle messages from upper layer */
    virtual void handleUpperMsg(cMessage *);

    /** @brief Handle messages from lower layer */
    virtual void handleLowerMsg(cMessage *);

    /** @brief we have no self messages */
    virtual void handleSelfMsg(cMessage* msg);
    
    /** @brief Checks whether a message was already broadcasted*/
    bool notBroadcasted(LimitedFloodPkt* msg);
    virtual void handleLowerControl(cMessage *msg);
    //overloading encaps method
    LimitedFloodPkt* encapsMsg(cPacket*);

    cMessage* neighbourDiscoveryTimer;



    typedef struct tRouteDiscoveryTableEntry {
            LAddress::L3Type initSrcAddr;
            Coord            geoAddr;
            double           distToNode;
            int              hopCount;
            /*
             * for street topo discovery only
             */
            //int              roadId;
            //bool             isAtJunction;

        } tDiscoveryTableEntry;

    typedef std::map<LAddress::L3Type, tDiscoveryTableEntry>        tNeighbourTable;
    typedef std::map<LAddress::L3Type, double>                      tDistanceBasedRebroadcastTable;
    typedef std::map<LAddress::L3Type, Coord>                       tGeoAddrTable;
    typedef std::map<double,LAddress::L3Type>                       tDistToNeigbourNode;
    typedef std::map<LAddress::L3Type, std::string>                 tRoutePathDetail;

    tNeighbourTable                 tDiscoveredNeighbourTable ;
    tDistanceBasedRebroadcastTable  tRebroadcastTable, tPacketLatency, tPacketLastUpdate;
    tGeoAddrTable                   tReceivedRouteInfoBroadcastTable;
    tRoutePathDetail                tDetailPathTraceTable;


    tDiscoveryTableEntry myDiscoveryTableEntry;

    typedef std::map<int, simsignal_t> tSimsignalList;
    tSimsignalList signalTable, lastUpdateSignalTable;
    simsignal_t arrSignal, lastUpdateSignal;

    //void updateRebroadcastTable(LAddress::L3Type srcAddr, double topoDist);
    void updateRebroadcastTable(tDiscoveryTableEntry m);

   void updateRebroadcastTableForPlainAndDistanceLimited(tDiscoveryTableEntry m);


    void broadcastNeighbourDiscoveryMsg();
    void printRebroadcastTable();

    void processForwardedMessageFromMac(cMessage* m);
    void processForwardedAckFromMac(cMessage* m);
    void processForwardedMsgTTL(LimitedFloodPkt* m);
    bool processForwardedMsgDistanceForSrc(LimitedFloodPkt* m);
    void processBitErrorTest(LimitedFloodPkt* m);
    void processForwardedMsgDistanceTravelled(LimitedFloodPkt* m);
    void processDiscoveryMessageFromMac(cMessage* m);
    void processForwardMessageFromAppl(cMessage* m);
    void processDiscoveryMessageFromAppl(cMessage* m);


    typedef std::map<LAddress::L3Type, long> tDataPacket;
    tDataPacket     tNBDataPacketReceivedPerNode, tNBDataPacketForwardPerNode, tNBDataPacketDropQueueLimit,
                       tNBDataPacketDropMaxBackOff, tNBDataPacketDropBitError, tNBDataPacketDropSyncOnSFDError,
                       tNBDataPacketDropMaxMissingAck, tNBDataPacketDuplicateReceivedPerNode;

    typedef std::map<double, long> tDelay;
    typedef std::vector<tDelay> delay;
    typedef std::map<LAddress::L3Type, delay> tDelayUpdate;
    tDelayUpdate        tDelayUpdatePerNode;

   void updateDataPacketReceivedPerNode(LAddress::L3Type nodeId);
   void recordDataPacketReceivedPerNode();
   void updateDataPacketForwardedPerNode(LAddress::L3Type nodeId);
   void recordDataPacketForwardedPerNode();
   void updateDataPacketLatencyPerNode(LAddress::L3Type nodeId, double TxTime);
   void recordDataPacketLatencyPerNode();
   void updateDataPacketDropQueueLimit(LAddress::L3Type nodeId);
   void recordDataPacketDropQueueLimit();
   void updateDataPacketDropMaxBackOff(LAddress::L3Type nodeId);
   void recordDataPacketDropMaxBackOff();
   void updateDataPacketDropBitError(LAddress::L3Type nodeId);
   void recordDataPacketDropBitError();
   void updateDataPacketDropSyncOnSFDError(LAddress::L3Type nodeId);
   void recordDataPacketDropSyncOnSFDError();
   void updateLastUpdatePerNode(LAddress::L3Type nodeId, double TxTime);
   void updateDataPacketDropMaxMissingAck(LAddress::L3Type nodeId);
   void recordDataPacketDropMaxMissingAck();

   void updateDataPacketDuplicateReceivedPerNode(LAddress::L3Type nodeId);
   void recordDataPacketDuplicateReceivedPerNode();

   void recordLastUpdatePerNode();
   double EuclideanDist(Coord a, Coord b);
   bool isFloodOppType(std::string str);
   void setFloodOppType(std::string str);

//   double EuclideanDist(Coord a, Coord b)
//   {
//       return sqrt((double)(pow((a.x - b.x),2)+ pow((a.y - b.y),2)));
//   }
//   std::string toUpperCase(std::string s)
//   {
//       for (unsigned int i = 0; i < s.length(); i++)
//           s[i]=toupper(s[i]);
//       return s;
//   }
//
//   bool isFloodOppType(std::string str)
//   {
//       if (toUpperCase(strFloodOppType).compare(str) == 0)
//           return true;
//       else
//           return false;
//   }
   FloodOppTypes myFloodOppMode;
//
//   void setFloodOppType(std::string str)
//   {
//       //strFloodOppType = "STREET_TOPO_LIMITED";
//       //strFloodOppType ="TTL_LIMITED";
//       //strFloodOppType = "DISTANCE_TO_SOURCE_LIMITED";
//       //strFloodOppType = "DISTANCE_TRAVELLED_LIMITED";
//
//       if (toUpperCase("STREET_TOPO_LIMITED").compare(str) == 0)
//           myFloodOppMode = STREET_TOPO_LIMITED;
//       else if (toUpperCase("TTL_LIMITED").compare(str) == 0)
//           myFloodOppMode = TTL_LIMITED;
//       else if (toUpperCase("DISTANCE_TO_SOURCE_LIMITED").compare(str) == 0)
//           myFloodOppMode = DISTANCE_TO_SOURCE_LIMITED;
//       else if (toUpperCase("DISTANCE_TRAVELLED_LIMITED").compare(str) == 0)
//           myFloodOppMode = DISTANCE_TRAVELLED_LIMITED;
//       else
//           error("LimitedFlood:setFloodOppType: unsupported flood operation mode.");
//   }

};

#endif
