/* -*- mode:c++ -*- ********************************************************
 * file:        Flood.cc
 *
 * author:      Daniel Willkomm
 *
 * copyright:   (C) 2004 Telecommunication Networks Group (TKN) at
 *              Technische Universitaet Berlin, Germany.
 *
 *              This program is free software; you can redistribute it 
 *              and/or modify it under the terms of the GNU General Public 
 *              License as published by the Free Software Foundation; either
 *              version 2 of the License, or (at your option) any later 
 *              version.
 *              For further information see file COPYING 
 *              in the top level directory
 *
 ***************************************************************************
 * part of:     framework implementation developed by tkn
 * description: a simple flooding protocol
 *              the user can decide whether to use plain flooding or not
 **************************************************************************/

#include "LimitedFlood.h"

#include <cassert>
#include <sstream>
#include "NetwPkt_m.h"
#include "NetwControlInfo.h"
#include "StreetlightApplLayer.h"
#include <string>
#include "csma.h"

using std::endl;
using std::make_pair;

Define_Module(LimitedFlood);

/**
 * Reads all parameters from the ini file. If a parameter is not
 * specified in the ini file a default value will be set.
 **/
void LimitedFlood::initialize(int stage) {
    BaseNetwLayer::initialize(stage);

    if (stage == 0) {
        //initialize seqence number to 0
        seqNum = 0;
        nbDataPacketsReceived = 0;
        //nbRxDataFrameTest = 0;
        nbDataPacketsSent = 0;
        nbDataPacketsForwarded = 0;
        nbACKPacketSent = 0;
        nbHops = 0;
        //nbRxDataFrameTestMyNetwAddr = 0;
        //nbRxDataFrameTestMyNetwAddrElse = 0;
        hasPar("defaultTtl") ? defaultTtl = par("defaultTtl") : defaultTtl = 5;
        hasPar("defaultNeighbourDiscoveryTtl") ? defaultNeighbourDiscoveryTtl = par("defaultNeighbourDiscoveryTtl") : defaultNeighbourDiscoveryTtl = 5;
//        hasPar("plainFlooding") ? plainFlooding = par("plainFlooding")
//                : plainFlooding = true;

        hasPar("floodType")? strFloodOppType = par("floodType").stdstringValue() : strFloodOppType = "TTL_LIMITED";
        setFloodOppType(strFloodOppType);

        hasPar("isPlain")? isPlain = par("isPlain").boolValue() : isPlain = true;

        hasPar("limitedFloodDistance")? intLimitedDistance = par("limitedFloodDistance") : intLimitedDistance = 150;
        //hasPar("isWithAck")? isWithAck = par("isWithAck").boolValue() : isWithAck = false;

        /*
         * hard coded for debugging purpose
         */
        //strFloodOppType = "STREET_TOPO_LIMITED";
        //strFloodOppType ="TTL_LIMITED";
        //strFloodOppType = "DISTANCE_TO_SOURCE_LIMITED";
        //strFloodOppType = "DISTANCE_TRAVELLED_LIMITED";

        EV<< "defaultTtl = " << defaultTtl
        << " floodType = " << strFloodOppType << endl;

//        if(isPlain)
//        {
            //these parameters are only needed for plain flooding
            hasPar("bcMaxEntries") ? bcMaxEntries = par("bcMaxEntries") : bcMaxEntries = 30;
            hasPar("bcDelTime") ? bcDelTime = par("bcDelTime") : bcDelTime = 3.0;
            EV <<"bcMaxEntries = "<<bcMaxEntries
            <<" bcDelTime = "<<bcDelTime<<endl;
//        }

        neighbourDiscoveryTimer = new cMessage("neighbour-discovery-timer", NEIGHBOUR_DISCOVERY_TIMER);
        //isNeighbourDiscoveryEnd = false;
        intNetwDiscoveryDuration = par("netwDiscoveryDuration");
        intTotalNetwDiscoveryElapsed = 0;
        /*
         * All the nodes start discovery the neighbouring node at different simulation time
         * to avoid collision.
         */
//      scheduleAt(simTime() + uniform(0.5, 1.5), routeDiscoveryFloodTimer);
//      opp_warning("LimitedFlood::initialize");
        isSendDown = false;
    }
    else
    {
        //triggerTrafficModelSignal = registerSignal("triggerTrafficModel");
        //simulation.getSystemModule()->subscribe(triggerTrafficModelSignal,this);
    }
}

void LimitedFlood::receiveSignal(cComponent *source, simsignal_t signalID, long l )
{
    //if (signalID == triggerTrafficModelSignal)
    //{
        /*
         * Signal "triggerTrafficModeSignal" is initiated by SUMOTraCIScenarioManager
         */
        //isNeighbourDiscoveryEnd = true;
    //}
}

LimitedFlood::~LimitedFlood()
{
    //cancelEvent(neighbourDiscoveryTimer);
    cancelAndDelete(neighbourDiscoveryTimer);
}
void LimitedFlood::finish() {

    //simulation.getSystemModule()->unsubscribe(triggerTrafficModelSignal,this);


    //if (plainFlooding) {
    if(isPlain ) {
        bcMsgs.clear();
    }
    //recordScalar("nbRxDataFrameTest",nbRxDataFrameTest);
    recordScalar("nbDataPacketsReceived", nbDataPacketsReceived);
    recordScalar("nbDataPacketsSent", nbDataPacketsSent);
    //recordScalar("nbRxDataFrameTestMyNetwAddr",nbRxDataFrameTestMyNetwAddr);
    //recordScalar("nbRxDataFrameTestMyNetwAddrElse",nbRxDataFrameTestMyNetwAddrElse);
    recordScalar("nbDataPacketsForwarded", nbDataPacketsForwarded);
    if (nbDataPacketsReceived > 0) {
      recordScalar("meanNbHops", (double) nbHops / (double) nbDataPacketsReceived);
    } else {
        recordScalar("meanNbHops", 0);
    }
    recordDataPacketForwardedPerNode();
    recordDataPacketReceivedPerNode();
    recordDataPacketLatencyPerNode();
    recordDataPacketDropMaxBackOff();
    recordDataPacketDropQueueLimit();
    recordDataPacketDropBitError();
    recordDataPacketDropSyncOnSFDError();
    recordDataPacketDropMaxMissingAck();
    recordLastUpdatePerNode();
    recordDataPacketDuplicateReceivedPerNode();
    if(neighbourDiscoveryTimer->isScheduled())
    {
        cancelEvent(neighbourDiscoveryTimer);
        delete (neighbourDiscoveryTimer);
        neighbourDiscoveryTimer = 0;
    }
}
void LimitedFlood::broadcastNeighbourDiscoveryMsg()
{
    /*
     * Send route flood packet and restart the timer
     */
    LimitedFloodPkt* pkt = new LimitedFloodPkt("ROUTE_DISCO", StreetlightApplLayer::NEIGHBOUR_DISCOVERY);


    pkt->setByteLength(headerLength);
    pkt->setSrcAddr(myNetwAddr);
    pkt->setDestAddr(LAddress::L3BROADCAST);
    pkt->setTtl(defaultNeighbourDiscoveryTtl);
    pkt->setInitialSrcGeoAddr(myDiscoveryTableEntry.geoAddr);
    //    pkt->setIsAtJunction(myDiscoveryTableEntry.isAtJunction);
    //    pkt->setRoadId(myDiscoveryTableEntry.roadId);

    setDownControlInfo(pkt, LAddress::L2BROADCAST);
    sendDown(pkt);
}
void LimitedFlood::handleSelfMsg(cMessage* msg)
{
    if (msg->getKind() == NEIGHBOUR_DISCOVERY_TIMER)
    {
        broadcastNeighbourDiscoveryMsg();
        /*
         * schedule the next route broadcast
         */
        //if(!isNeighbourDiscoveryEnd)
        if(intTotalNetwDiscoveryElapsed < intNetwDiscoveryDuration)
        {
            intTotalNetwDiscoveryElapsed++;
            scheduleAt(simTime() + uniform(0.5, 1.5), neighbourDiscoveryTimer);
        }
    }
}

/**
 * All messages have to get a sequence number and the ttl filed has to
 * be specified. Afterwards the messages can be handed to the mac
 * layer. The mac address is set to -1 (broadcast address) because the
 * message is flooded (i.e. has to be send to all neighbors)
 *
 * In the case of plain flooding the message sequence number and
 * source address has also be stored in the bcMsgs list, so that this
 * message will not be rebroadcasted, if a copy will be flooded back
 * from the neigbouring nodes.
 *
 * If the maximum number of entries is reached the first (oldest) entry
 * is deleted.
 **/
void LimitedFlood::handleUpperMsg(cMessage* m) {

    switch(m->getKind())
    {
        case  StreetlightApplLayer::NEIGHBOUR_DISCOVERY:
        {
            StreetlightApplPkt *msgAppl = static_cast<StreetlightApplPkt*> (m);

            myDiscoveryTableEntry.geoAddr = msgAppl->getGeoAddrLamppost();;
            myDiscoveryTableEntry.initSrcAddr = myNetwAddr;
            myDiscoveryTableEntry.distToNode = 0;
            myDiscoveryTableEntry.hopCount = 0;
            //myDiscoveryTableEntry.roadId = msgAppl->getIntRoadID();;
            //myDiscoveryTableEntry.isAtJunction = msgAppl->getIsAtJunction();


            ev<<"LimitedFlood::handleUpperMsg: NEIGHBOUR_DISCOVERY : node ["<<myNetwAddr<<"] Coodinate : ("<<msgAppl->getGeoAddrLamppost().x <<","
                <<myDiscoveryTableEntry.geoAddr.y<<")"<<endl ;
            updateRebroadcastTableForPlainAndDistanceLimited(myDiscoveryTableEntry);
            scheduleAt(simTime() + uniform(0.5, 1.5), neighbourDiscoveryTimer);

            delete m;
            break;
        }
        case StreetlightApplLayer::ACK:
        {
            assert(dynamic_cast<cPacket*> (m));
            //LimitedFloodPkt *msg = encapsMsg(static_cast<cPacket*> (m));


            LAddress::L2Type macAddr;
            LAddress::L3Type netwAddr;
            LAddress::L3Type AckForWhichAddr;
            LAddress::L3Type AckDestAddr;

            EV<<"in encaps...\n";

            LimitedFloodPkt *pkt = new LimitedFloodPkt(m->getName(), m->getKind());
            pkt->setBitLength(headerLength);

            cObject* cInfo = m->removeControlInfo();

            if(cInfo == NULL)
            {
                EV << "warning: Application layer did not specifiy a destination L3 address\n"
                   << "\tusing broadcast address instead\n";
                netwAddr = LAddress::L3BROADCAST;
            }
            else
            {
                EV <<"CInfo removed, netw addr="<< NetwControlInfo::getAddressFromControlInfo( cInfo ) <<endl;

                netwAddr = NetwControlInfo::getAddressFromControlInfo( cInfo );
                AckForWhichAddr = NetwControlInfo::getAckForWhichAddr(cInfo);
                AckDestAddr = NetwControlInfo::getPreviousAddressFromControlInfo(cInfo);
                delete cInfo;
            }

            pkt->setSrcAddr(myNetwAddr);
            pkt->setDestAddr(netwAddr);
            EV << " netw "<< myNetwAddr << " sending packet" <<endl;

            macAddr = LAddress::L2Type(netwAddr);

            setDownControlInfo(pkt, macAddr);

            //encapsulate the application packet
            pkt->encapsulate(static_cast<cPacket*>(m));
            EV <<" pkt encapsulated\n";

            pkt->setTtl(0);
            pkt->setTimestamp();
            pkt->setKind(StreetlightApplLayer::ACK);
            pkt->setOriginalSrcAddr(AckForWhichAddr);

            opp_warning("LimitedFlood::handleUpperMsg: preparing ACK for data for Lamp[%d] at Lamp [%d]", AckForWhichAddr, AckDestAddr);
            nbACKPacketSent++;
            sendDown(pkt);
            break;
        }
        case StreetlightApplLayer::DATA_MSG:
        {
            assert(dynamic_cast<cPacket*> (m));
            LimitedFloodPkt *msg = encapsMsg(static_cast<cPacket*> (m));

            msg->setSeqNum(seqNum);
            seqNum++;
            /*
             * use by NORMAL_FLOOD with or without isPlain
             */
            msg->setTtl(defaultTtl);
            /*
             * use by DISTANCE_LIMITED flooding protocol with or without isPlain
             */
            msg->setDistFromInitSource(intLimitedDistance);
            msg->setDistTravelFromInitSource(intLimitedDistance);
            msg->setTimestamp();
            msg->setPreviousNodeAddr(myNetwAddr);
            msg->setSrcAddr(myNetwAddr);
            msg->setOriginalSrcAddr(myNetwAddr);

            msg->setKind(StreetlightApplLayer::DATA_MSG);
            ev<<"LimitedFlood::handleUpperMsg: msg->setPreviousNodeAddr : "<<myNetwAddr << " using getFunctin : "<<msg->getPreviousNodeAddr()<<endl;

            if (bcMsgs.size() >= bcMaxEntries)
            {
                cBroadcastList::iterator it;

                //serach the broadcast list of outdated entries and delete them
                for (it = bcMsgs.begin(); it != bcMsgs.end(); ++it)
                {
                    if (it->delTime < simTime())
                    {
                        bcMsgs.erase(it);
                        it--;
                        break;
                    }
                }
                //delete oldest entry if max size is reached
                if (bcMsgs.size() >= bcMaxEntries)
                {
                    EV<<"bcMsgs is full, delete oldest entry"<<endl;
                    bcMsgs.pop_front();
                }
            }
            bcMsgs.push_back(Bcast(msg->getSeqNum(), msg->getSrcAddr(), simTime() +bcDelTime));
            //there is no routing so all messages are broadacst for the mac layer
            sendDown(msg);
            nbDataPacketsSent++;
            break;
        }
        default:
            error("LimitedFlood::handleUpperMsg: Unknown message type ::");
            break;
    }
}
void LimitedFlood::updateDataPacketDropQueueLimit(LAddress::L3Type nodeId)
{
    tDataPacket::iterator pos = tNBDataPacketDropQueueLimit.find(nodeId);
    if(pos != tNBDataPacketDropQueueLimit.end())
        pos->second++;
    else
        tNBDataPacketDropQueueLimit.insert(make_pair(nodeId, 1));
}
void LimitedFlood::recordDataPacketDropQueueLimit()
{
    tDataPacket::iterator pos;
    std::string strNodeId;
    //ev<<"LimitedFlood::recordDataPacketDropQueueLimit:size : "<< tNBDataPacketDropQueueLimit.size()<<endl;
    for(pos = tNBDataPacketDropQueueLimit.begin(); pos != tNBDataPacketDropQueueLimit.end(); pos++)
    {
        strNodeId= "node[" + static_cast<std::ostringstream*>( &(std::ostringstream() << pos->first))->str() + "]_NBDataPacketDropQueueLimit";
        recordScalar(strNodeId.c_str(), pos->second);
        //ev<<"LimitedFlood::tNBDataPacketDropQueueLimit: "<< strNodeId << " = "<<pos->second<<endl;
    }
}
void LimitedFlood::updateDataPacketDropBitError(LAddress::L3Type nodeId)
{

    tDataPacket::iterator pos =  tNBDataPacketDropBitError.find(nodeId);
    if(pos != tNBDataPacketDropBitError.end())
        pos->second++;
    else
        tNBDataPacketDropBitError.insert(make_pair(nodeId, 1));
}
void LimitedFlood::recordDataPacketDropBitError()
{
    tDataPacket::iterator pos;
    std::string strNodeId;
    //ev<<"LimitedFlood::recordDataPacketDropQueueLimit:size : "<< tNBDataPacketDropBitError.size()<<endl;
    for(pos = tNBDataPacketDropBitError.begin(); pos != tNBDataPacketDropBitError.end(); pos++)
    {
        strNodeId= "node[" + static_cast<std::ostringstream*>( &(std::ostringstream() << pos->first))->str() + "]_NBDataPacketDropBitError";
        recordScalar(strNodeId.c_str(), pos->second);
        //ev<<"LimitedFlood::tNBDataPacketDropBitError: "<< strNodeId << " = "<<pos->second<<endl;
    }
}
void LimitedFlood::updateDataPacketDropSyncOnSFDError(LAddress::L3Type nodeId)
{

    tDataPacket::iterator pos =   tNBDataPacketDropSyncOnSFDError.find(nodeId);
    if(pos !=  tNBDataPacketDropSyncOnSFDError.end())
       pos->second++;
    else
        tNBDataPacketDropSyncOnSFDError.insert(make_pair(nodeId, 1));
}
void LimitedFlood::recordDataPacketDropSyncOnSFDError()
{
    tDataPacket::iterator pos;
    std::string strNodeId;
    //ev<<"LimitedFlood::tNBDataPacketDropSyncOnSFDError:size : "<< tNBDataPacketDropSyncOnSFDError.size()<<endl;
    for(pos = tNBDataPacketDropSyncOnSFDError.begin(); pos != tNBDataPacketDropSyncOnSFDError.end(); pos++)
    {
        strNodeId= "node[" + static_cast<std::ostringstream*>( &(std::ostringstream() << pos->first))->str() + "]_NBDataPacketDropSyncOnSFDError";
        recordScalar(strNodeId.c_str(), pos->second);
        //ev<<"LimitedFlood::tNBDataPacketDropSyncOnSFDError: "<< strNodeId << " = "<<pos->second<<endl;
    }
}

void LimitedFlood::updateDataPacketDropMaxBackOff(LAddress::L3Type nodeId)
{
    tDataPacket::iterator pos =  tNBDataPacketDropMaxBackOff.find(nodeId);
    if(pos != tNBDataPacketDropMaxBackOff.end())
        pos->second++;
    else
        tNBDataPacketDropMaxBackOff.insert(make_pair(nodeId, 1));
}
void LimitedFlood::recordDataPacketDropMaxBackOff()
{
    tDataPacket::iterator pos;
    std::string strNodeId;
    //ev<<"LimitedFlood::recordDataPacketDropMaxBackOff:size : "<< tNBDataPacketDropMaxBackOff.size()<<endl;
    for(pos = tNBDataPacketDropMaxBackOff.begin(); pos != tNBDataPacketDropMaxBackOff.end(); pos++)
    {
        strNodeId= "node[" + static_cast<std::ostringstream*>( &(std::ostringstream() << pos->first))->str() + "]_NBDataPacketDropMaxBackOff";
        recordScalar(strNodeId.c_str(), pos->second);
       // ev<<"LimitedFlood::tNBDataPacketDropMaxBackOff: "<< strNodeId << " = "<<pos->second<<endl;
    }
}

void LimitedFlood::updateDataPacketForwardedPerNode(LAddress::L3Type nodeId)
{
    tDataPacket::iterator pos = tNBDataPacketForwardPerNode.find(nodeId);
    if(pos != tNBDataPacketForwardPerNode.end())
        pos->second++;
    else
        tNBDataPacketForwardPerNode.insert(make_pair(nodeId,1));
}

void LimitedFlood::recordDataPacketForwardedPerNode()
{

    tDataPacket::iterator pos;
    std::string strNodeId;
    //ev<<"LimitedFlood::recordDataPacketForwardedPerNode:size : "<< tNBDataPacketForwardPerNode.size()<<endl;
    for(pos = tNBDataPacketForwardPerNode.begin(); pos != tNBDataPacketForwardPerNode.end(); pos++)
    {
        strNodeId= "node[" + static_cast<std::ostringstream*>( &(std::ostringstream() << pos->first))->str() + "]_NBDataPacketForwarded";
        recordScalar(strNodeId.c_str(), pos->second);
        //ev<<"LimitedFlood::recordDataPacketForwardedPerNode: "<< strNodeId << " = "<<pos->second<<endl;
    }
}
void LimitedFlood::updateDataPacketDuplicateReceivedPerNode(LAddress::L3Type nodeId)
{
    tDataPacket::iterator pos = tNBDataPacketDuplicateReceivedPerNode.find(nodeId);
    if(pos != tNBDataPacketDuplicateReceivedPerNode.end())
            pos->second++;
    else
        tNBDataPacketDuplicateReceivedPerNode.insert(make_pair(nodeId,1));

}
void LimitedFlood::recordDataPacketDuplicateReceivedPerNode()
{

    tDataPacket::iterator pos;
    std::string strNodeId;
    //ev<<"LimitedFlood::recordDataPacketDuplicateReceivedPerNode:size : "<< tNBDataPacketDuplicateReceivedPerNode.size()<<endl;
    for(pos = tNBDataPacketDuplicateReceivedPerNode.begin(); pos != tNBDataPacketDuplicateReceivedPerNode.end(); pos++)
    {
        strNodeId= "node[" + static_cast<std::ostringstream*>( &(std::ostringstream() << pos->first))->str() + "]_DuplicationReceivedFromNode";
        recordScalar(strNodeId.c_str(), pos->second);
       // ev<<"LimitedFlood::recordDataPacketDuplicateReceivedPerNode: "<< strNodeId << " = "<<pos->second<<endl;
    }
}
void LimitedFlood::recordDataPacketReceivedPerNode()
{
    tDataPacket::iterator pos;
    std::string strNodeId;
    //ev<<"LimitedFlood::recordDataPacketReceivedPerNode:size : "<< tNBDataPacketReceivedPerNode.size()<<endl;
    for(pos = tNBDataPacketReceivedPerNode.begin(); pos != tNBDataPacketReceivedPerNode.end(); pos++)
    {
        strNodeId= "node[" + static_cast<std::ostringstream*>( &(std::ostringstream() << pos->first) )->str() + "]_NBDataPacketReceived";
        recordScalar(strNodeId.c_str(), pos->second);
        //ev<<"LimitedFlood::recordDataPacketReceivedPerNode: "<< strNodeId << " = "<<pos->second<<endl;
    }
}

void LimitedFlood::updateLastUpdatePerNode(LAddress::L3Type nodeId, double TxTime)
{

    tDistanceBasedRebroadcastTable::iterator posLastUpdate = tPacketLastUpdate.find(nodeId);
    if(posLastUpdate == tPacketLastUpdate.end())
    {
        tPacketLastUpdate.insert(make_pair(nodeId, TxTime));
        std::string strName = "node_"+ static_cast<std::ostringstream*>( &(std::ostringstream() << nodeId))->str()+"_LastUpdate";
        lastUpdateSignal = registerSignal(strName.c_str());
        lastUpdateSignalTable.insert(std::make_pair(nodeId, lastUpdateSignal));
        emit(lastUpdateSignal, simTime().dbl() - TxTime);
    }
    else
    {
        tSimsignalList::iterator posSignal = lastUpdateSignalTable.find(nodeId);

        emit(posSignal->second, TxTime - posLastUpdate->second);
//        if(posLastUpdate->second < TxTime)
//        {
            posLastUpdate->second = TxTime;
//        }
    }
}
void LimitedFlood::recordLastUpdatePerNode()
{
//    std::string strNodeId;
//    for (tDelayUpdate::iterator pos = tDelayUpdatePerNode.begin(); pos != tDelayUpdatePerNode.end(); pos++)
//    {
//        tDelay b = pos->second.at(0) ;
//        for(tDelay::iterator pos_tDelay = b.begin(); pos_tDelay != b.end(); pos_tDelay++ )
//        {
//            strNodeId= "node[" + static_cast<std::ostringstream*>( &(std::ostringstream() << pos->first) )->str() + "]_Delay("+ static_cast<std::ostringstream*>( &(std::ostringstream() << pos_tDelay->first) )->str() +")";
//            recordScalar(strNodeId.c_str(), pos_tDelay->second);
//        }
//    }
}

void LimitedFlood::updateDataPacketLatencyPerNode(LAddress::L3Type nodeId, double TxTime)
{
    tDistanceBasedRebroadcastTable::iterator pos = tPacketLatency.find(nodeId);
    if(pos == tPacketLatency.end())
        tPacketLatency.insert(make_pair(nodeId, simTime().dbl() - TxTime));
    else
        pos->second += simTime().dbl() - TxTime;

    updateLastUpdatePerNode(nodeId, TxTime);

    tSimsignalList::iterator posSignal = signalTable.find(nodeId);
    if(posSignal != signalTable.end())
    {
        emit(posSignal->second, simTime().dbl() - TxTime);
    }
    else
    {
        std::string strName = "node_"+ static_cast<std::ostringstream*>( &(std::ostringstream() << nodeId))->str()+"_Latency";
        arrSignal = registerSignal(strName.c_str());
        signalTable.insert(std::make_pair(nodeId, arrSignal));
        emit(arrSignal, simTime().dbl() - TxTime);
    }

}
void LimitedFlood::recordDataPacketLatencyPerNode()
{
    tDataPacket::iterator pos;
    std::string strNodeId;
    //ev<<"LimitedFlood::tPacketLatency:size : "<< tPacketLatency.size()<<endl;
    for(pos = tNBDataPacketReceivedPerNode.begin(); pos != tNBDataPacketReceivedPerNode.end(); pos++)
    {
        strNodeId= "node[" + static_cast<std::ostringstream*>( &(std::ostringstream() << pos->first) )->str() + "]_AverageLatency";
        recordScalar(strNodeId.c_str(), ((tPacketLatency.find(pos->first)->second) / pos->second));
        //ev<<"LimitedFlood::recordDataPacketLatencyPerNode: "<< strNodeId << " = "<<((tPacketLatency.find(pos->first)->second) / pos->second)<<endl;
    }
}
void LimitedFlood::updateDataPacketReceivedPerNode(LAddress::L3Type nodeId)
{
    tDataPacket::iterator pos = tNBDataPacketReceivedPerNode.find(nodeId);
    if(pos != tNBDataPacketReceivedPerNode.end())
        pos->second++;
    else
        tNBDataPacketReceivedPerNode.insert(make_pair(nodeId,1));
}

void LimitedFlood::updateDataPacketDropMaxMissingAck(LAddress::L3Type nodeId)
{
    tDataPacket::iterator pos = tNBDataPacketDropMaxMissingAck.find(nodeId);
    if(pos != tNBDataPacketDropMaxMissingAck.end())
        pos->second++;
    else
        tNBDataPacketDropMaxMissingAck.insert(make_pair(nodeId, 1));
}

void LimitedFlood::recordDataPacketDropMaxMissingAck()
{
   tDataPacket::iterator pos;
   std::string strNodeId;
   //ev<<"Unicast::tNBDataPacketDropMaxMissingAck:size : "<< tNBDataPacketDropMaxMissingAck.size()<<endl;
   for(pos = tNBDataPacketDropMaxMissingAck.begin(); pos != tNBDataPacketDropMaxMissingAck.end(); pos++)
   {
       strNodeId= "node[" + static_cast<std::ostringstream*>( &(std::ostringstream() << pos->first) )->str() + "]_NBDataPacketDropMaxMissingAck";
       recordScalar(strNodeId.c_str(), pos->second);
       //ev<<"Unicast::recordDataPackeetDropMaxMissingAckPerNode: "<< strNodeId << " = "<<pos->second<<endl;
   }
}
void LimitedFlood::processForwardedMsgTTL(LimitedFloodPkt* m)
{
    if(notBroadcasted(m))
    {
        if(m->getTtl() > 1)
        {
            LimitedFloodPkt *dMsg;
            EV <<" data msg BROADCAST! ttl = "<<m->getTtl()
            <<" > 1 -> rebroadcast msg & send to upper\n";
            m->setTtl( m->getTtl()-1 );
            dMsg = static_cast<LimitedFloodPkt*>(m->dup());
            setDownControlInfo(dMsg, LAddress::L2BROADCAST);
            sendDown(dMsg);

            //nbDataPacketsForwarded should be the same to total data packet Forwarded per node
            nbDataPacketsForwarded++;
            updateDataPacketForwardedPerNode(m->getSrcAddr());
        }
        else
            EV <<" max hops reached (ttl = "<<m->getTtl()<<") -> only send to upper\n";
    }
//    else
//    {
//        ev<< " message already broadcasted, delete messge "<<endl;
//        delete m;
//    }
}

void LimitedFlood::processBitErrorTest(LimitedFloodPkt* m)
{
    ev<<"LimitedFlood::processBitErrorTest (1): Data received! distance from Source :"<<m->getSrcAddr()<< " to "<<m->getDestAddr()<<" via previousNodeAddr : "<<m->getPreviousNodeAddr()<< endl;
//    LimitedFloodPkt *dMsg;
//    dMsg = static_cast<LimitedFloodPkt*>(m->dup());
    //updateDataPacketReceivedPerNode(m->getSrcAddr());
    //delete m;

    ev<< " LimitedFlood::processForwardedMsgDistanceForSrc (2) : still within the distance rebroadcast it! "<<endl;
}
bool LimitedFlood::processForwardedMsgDistanceForSrc(LimitedFloodPkt* m)
{
    ev<<"LimitedFlood::processForwardedMsgDistanceForSrc (1): Data received! From :"<<m->getSrcAddr()
            << " to "<<m->getDestAddr()<<", seq. num : "<<m->getSeqNum()<<endl;
    ev<<"   via previousNodeAddr : "<<m->getPreviousNodeAddr()<<endl;
    ev<<"   original Src :"<<m->getOriginalSrcAddr()<<endl;


    printRebroadcastTable();

    double distPreNodeToSrc, distMeToSrc;

    tNeighbourTable::iterator pos_PreNode = tDiscoveredNeighbourTable.find(m->getPreviousNodeAddr());
    //tNeighbourTable::iterator pos_Src = tDiscoveredNeighbourTable.find(m->getSrcAddr());
    tNeighbourTable::iterator pos_Src = tDiscoveredNeighbourTable.find(m->getOriginalSrcAddr());

    if(notBroadcasted(m))
    {
        isBroadcasted = false;
        if(pos_PreNode != tDiscoveredNeighbourTable.end() && pos_Src != tDiscoveredNeighbourTable.end())
        {

            distPreNodeToSrc = EuclideanDist(pos_Src->second.geoAddr, pos_PreNode->second.geoAddr);
            distMeToSrc = EuclideanDist(myDiscoveryTableEntry.geoAddr, pos_Src->second.geoAddr);
            /*
             * if me receives a msg from a node nearer to source compare to me
             * I will proceed to rebroadcast the msg again
             */
            ev<<"LimitedFlood::processForwardedMsgDistanceForSrc (1-1): distMeToSrc :"<<distMeToSrc<<", distPreNodeToSrc : "<< distPreNodeToSrc<<endl;
            if(distMeToSrc > distPreNodeToSrc && distMeToSrc < intLimitedDistance && distMeToSrc > 0)
            {
                m->setPreviousNodeAddr(myNetwAddr);

                LimitedFloodPkt *dMsg;
                dMsg = static_cast<LimitedFloodPkt*>(m->dup());
//                dMsg->setSrcAddr(myNetwAddr);
                dMsg->setPreviousNodeAddr(myNetwAddr);
//                dMsg->setSeqNum(seqNum);
//                seqNum++;
                setDownControlInfo(dMsg, LAddress::L2BROADCAST);

                if (bcMsgs.size() >= bcMaxEntries)
                {
                    cBroadcastList::iterator it;

                    //serach the broadcast list of outdated entries and delete them
                    for (it = bcMsgs.begin(); it != bcMsgs.end(); ++it)
                    {
                        if (it->delTime < simTime())
                        {
                            bcMsgs.erase(it);
                            it--;
                            break;
                        }
                    }
                    //delete oldest entry if max size is reached
                    if (bcMsgs.size() >= bcMaxEntries)
                    {
                        //opp_warning("test 8");
                        EV<<"bcMsgs is full, delete oldest entry"<<endl;
                        bcMsgs.pop_front();
                    }
                }
                bcMsgs.push_back(Bcast(dMsg->getSeqNum(), dMsg->getSrcAddr(), simTime() +bcDelTime));
                sendDown(dMsg);
                isSendDown = true;
                nbDataPacketsForwarded++ ;
                updateDataPacketForwardedPerNode(m->getSrcAddr());
                ev<< " LimitedFlood::processForwardedMsgDistanceForSrc (2) : still within the distance rebroadcast it! "<<endl;
                return true;
            }
            else
            {
                isSendDown = false;
                ev<< "  LimitedFlood::processForwardedMsgDistanceForSrc (3) : receive message furtherer than me, delete message "<<endl;
                //opp_warning("LimitedFlood::processForwardedMsgDistanceForSrc: receive the message further than me, cancel send down and delete message");
                return true;
                //delete m;
            }
        }
        else
        {
            //opp_warning("LimitedFlood::processForwardedMsgDistance: source not found at tDiscoveredNeighbourTable");
            isSendDown = false;
            return false;
        }
    }
    else
    {
        isBroadcasted = true;
        ev<< " message already broadcasted, delete messge "<<endl;
        isSendDown = false;
        return true;
    }
}
void LimitedFlood::processForwardedMsgDistanceTravelled(LimitedFloodPkt* m)
{
    ev<<" data msg BROADCAST! distance from initial source = "<<m->getDistFromInitSource()
            <<" > 0 -> rebroadcast msg & send to upper.  Source :"<<m->getSrcAddr()<< endl;

    printRebroadcastTable();
    if(notBroadcasted(m))
    {
        if(m->getDistFromInitSource() > 0 )
        {
            LimitedFloodPkt *dMsg;
            tNeighbourTable::iterator pos = tDiscoveredNeighbourTable.find(m->getPreviousNodeAddr());

            if(pos != tDiscoveredNeighbourTable.end() )
            {
                if(m->getDistFromInitSource() - pos->second.distToNode > 0)
                {
                    m->setDistFromInitSource(m->getDistFromInitSource() - pos->second.distToNode);
                    m->setPreviousNodeAddr(myNetwAddr);

                    dMsg = static_cast<LimitedFloodPkt*>(m->dup());
                    setDownControlInfo(dMsg, LAddress::L2BROADCAST);
                    sendDown(dMsg);

                    nbDataPacketsForwarded++ ;
                    updateDataPacketForwardedPerNode(m->getSrcAddr());
                }
            }
            else
                error("LimitedFlood::processForwardedMsgDistanceTravelled: source not found at tRebroadcastTable");
        }
        else
            ev<<" max distance reached (distance = " << m->getDistFromInitSource()<< ") -> only send to upper"<<endl;
    }
//    else
//   {
//       ev<< " message already broadcasted, delete messge "<<endl;
//       delete m;
//   }
}
/**
 * Messages from the mac layer will be forwarded to the application
 * only if the are broadcast or destined for this node.
 *
 * If the arrived message is a broadcast message it is also reflooded
 * only if the tll field is bigger than one. Before the message is
 * handed back to the mac layer the ttl field is reduced by one to
 * account for this hop.
 *
 * In the case of plain flooding the message will only be processed if
 * there is no corresponding entry in the bcMsgs list (@ref
 * notBroadcasted). Otherwise the message will be deleted.
 **/
void LimitedFlood::processForwardedMessageFromMac(cMessage* m)
{
        bool isSendUp = true;
        LimitedFloodPkt *msg = static_cast<LimitedFloodPkt *> (m);
        LAddress::L3Type preSrcAddr = msg->getPreviousNodeAddr();
        //msg is for me
//        if(msg->getSrcAddr() != myNetwAddr)
//        {
            if (msg->getDestAddr() == myNetwAddr)
            {
                EV<<" data msg for me! send to Upper"<<endl;
                nbHops = nbHops + (defaultTtl + 1 - msg->getTtl());

                nbDataPacketsReceived++;
                updateDataPacketReceivedPerNode(msg->getSrcAddr());
                updateDataPacketLatencyPerNode(msg->getSrcAddr(), msg->getTimestamp().dbl());
                //nbRxDataFrameTestMyNetwAddr++;
                if(m->getKind() == StreetlightApplLayer::ACK)
                    sendUp(decapsMsg(msg,preSrcAddr,msg->getOriginalSrcAddr(),isSendDown, isBroadcasted));
                else
                    sendUp(decapsMsg(msg));
            }
            //broadcast message
            //else if( LAddress::isL3Broadcast(msg->getDestAddr()))
            else if( LAddress::isL3Broadcast(msg->getDestAddr()))
            {
                //nbRxDataFrameTestMyNetwAddrElse++;
                switch (myFloodOppMode)
                {
                    case TTL_LIMITED :
                    {
                        processForwardedMsgTTL(msg);
                        break;
                    }
                    case DISTANCE_TRAVELLED_LIMITED :
                    {
                        processForwardedMsgDistanceTravelled(msg);
                        break;
                    }
                    case DISTANCE_TO_SOURCE_LIMITED:
                    {
                        isSendUp = processForwardedMsgDistanceForSrc(msg);
                        break;
                    }
                    case BIT_ERROR_TEST:
                    {
                        processBitErrorTest(msg);
                        break;
                    }
                    default:
                        error("LimitedFlood::processForwardedMessageFromMac: unknown flooding type");
                        break;
                }


                updateDataPacketLatencyPerNode(msg->getSrcAddr(), msg->getTimestamp().dbl());
                nbDataPacketsReceived++;
                updateDataPacketReceivedPerNode(msg->getSrcAddr());

                if(isSendUp)
                {
                    //opp_warning("LimitedFlood::processForwardedMessageFromMac: sending up : previousSrc : %d, originate form %d",preSrcAddr, msg->getOriginalSrcAddr());
                    //isSendDown
                    //sendUp(decapsMsg(msg, preSrcAddr));
                    //sendUp(decapsMsg(msg,-987,isSendDown));
					//sendUp(decapsMsg(msg,preSrcAddr,msg->getOriginalSrcAddr()));
                    sendUp(decapsMsg(msg,preSrcAddr,msg->getOriginalSrcAddr(),isSendDown, isBroadcasted));
                }
                else
                {
                    //opp_warning("LimitedFlood::processForwardedMessageFromMac: deleting and cancel sendUp : previousSrc : %d",preSrcAddr);
                    delete msg;
                }
            }
//        }
//        else
//        {
//            opp_warning("LimitedFlood::processForwardedMessageFromMac: deleting and cancel sendUp : received data packet originate from me");
//            delete msg;
//        }
}
void LimitedFlood::processForwardedAckFromMac(cMessage* m)
{
    LimitedFloodPkt *msg = static_cast<LimitedFloodPkt *> (m);
    LAddress::L3Type preSrcAddr = msg->getPreviousNodeAddr();


    sendUp(decapsMsg(msg,preSrcAddr,msg->getOriginalSrcAddr(),isSendDown, isBroadcasted));

    //sendUp(decapsMsg(msg, preSrcAddr));
}
void LimitedFlood::printRebroadcastTable()
{
    tNeighbourTable::iterator pos;
    ev<<"LimitedFlood::printRebroadcastTable::strFloodOppType:"<<strFloodOppType<<endl;
    for(pos = tDiscoveredNeighbourTable.begin(); pos != tDiscoveredNeighbourTable.end(); pos++)
    {
        ev<<"LimitedFlood::printRebroadcastTable::lamp["<<getParentModule()->getIndex()<<"] tDiscoveredNeigbourTable ["<<pos->first<<"] distance is "<< pos->second.distToNode
                <<" hop count : "<<pos->second.hopCount
                <<" geoAddr ("<<pos->second.geoAddr.x<<", "<< pos->second.geoAddr.y<<")"<<endl;
    }
}



void LimitedFlood::updateRebroadcastTableForPlainAndDistanceLimited(tDiscoveryTableEntry m)
{


    tNeighbourTable::iterator pos;

    m.distToNode = EuclideanDist(myDiscoveryTableEntry.geoAddr, m.geoAddr);
    pos = tDiscoveredNeighbourTable.find(m.initSrcAddr);
    //if(m.initSrcAddr != myNetwAddr)
    //{
        if(pos == tDiscoveredNeighbourTable.end())
            tDiscoveredNeighbourTable.insert(make_pair(m.initSrcAddr,m));
        else
        {
            if(pos->second.hopCount > m.hopCount)
                pos->second = m;
        }
    //}
}

void LimitedFlood::updateRebroadcastTable(tDiscoveryTableEntry m)
{
//    if(toUpperCase(strFloodOppType).compare("STREET_TOPO_LIMITED") == 0)
//    {
//       updateRebroadcastTableForStreetTopoLimited(m);
//    }

    //strFloodOppType ="TTL_LIMITED";
    //strFloodOppType = "DISTANCE_TO_SOURCE_LIMITED";
    //strFloodOppType = "DISTANCE_TRAVELLED_LIMITED";

    //if(isFloodOppType("DISTANCE_LIMITED")|| isFloodOppType("TTL_LIMITED"))
    if(myFloodOppMode != STREET_TOPO_LIMITED)
    {
        updateRebroadcastTableForPlainAndDistanceLimited(m);
    }
}

void LimitedFlood::processDiscoveryMessageFromMac(cMessage* m)
{

    LimitedFloodPkt* netwDiscMsg = check_and_cast<LimitedFloodPkt*> (m);
    tDiscoveryTableEntry newEntry;

    newEntry.geoAddr = netwDiscMsg->getInitialSrcGeoAddr();
    newEntry.initSrcAddr = netwDiscMsg->getSrcAddr();
    newEntry.distToNode = EuclideanDist(myDiscoveryTableEntry.geoAddr, newEntry.geoAddr);
    newEntry.hopCount = (defaultNeighbourDiscoveryTtl + 1) - netwDiscMsg->getTtl() ;

    ev<<"LimitedFlood::processDiscoveryMessageFromMac: node ["<<newEntry.initSrcAddr <<"] geoAddr ("<< newEntry.geoAddr.x << "," << newEntry.geoAddr.y<<")"<<endl;
    ev<<"   hop count :"<<newEntry.hopCount;
    /*
     * collect all the route broadcast into a table
     */
//    if(tDiscoveredNeighbourTable.find(newEntry.initSrcAddr) == tDiscoveredNeighbourTable.end())
//        tDiscoveredNeighbourTable.insert(make_pair(newEntry.initSrcAddr, newEntry));
//    ev<<"LimitedFlood::updateRebroadcastTable::size of tDiscoveredNeighbourTable : "<<tDiscoveredNeighbourTable.size()<<endl;


    updateRebroadcastTable(newEntry);
    printRebroadcastTable();

    cObject *const pCtrlInfo = netwDiscMsg->removeControlInfo();
    if (pCtrlInfo != NULL) delete pCtrlInfo;


    if(netwDiscMsg->getTtl() > 1)
    {
        LimitedFloodPkt* netwDiscMsgSendDown = static_cast<LimitedFloodPkt*>(netwDiscMsg->dup());
        LimitedFloodPkt* netwDiscMsgSendUp = static_cast<LimitedFloodPkt*>(netwDiscMsg->dup());

        cObject *const pCtrlInfo = netwDiscMsgSendDown->removeControlInfo();
        if (pCtrlInfo != NULL) delete pCtrlInfo;
        netwDiscMsgSendDown->setTtl(netwDiscMsgSendDown->getTtl()-1);
        netwDiscMsgSendDown->setPreviousNodeAddr(myNetwAddr);
        setDownControlInfo(netwDiscMsgSendDown, LAddress::L3BROADCAST);
        sendDown(netwDiscMsgSendDown);

        setUpControlInfoNetwDisco(netwDiscMsgSendUp, netwDiscMsgSendUp->getSrcAddr(),newEntry.hopCount);
        sendUp(netwDiscMsgSendUp);

//        netwDiscMsgSendDown->setTtl(netwDiscMsg->getTtl()-1);
//        setDownControlInfo(netwDiscMsgSendDown, LAddress::L3BROADCAST);
//        sendDown(netwDiscMsgSendDown);

    }
//    else
    delete netwDiscMsg;

//    setUpControlInfoNetwDisco(netwDiscMsg, netwDiscMsg->getSrcAddr(),newEntry.hopCount);
//    sendUp(netwDiscMsg->dup());

}

void LimitedFlood::handleLowerMsg(cMessage* m)
{

    switch(m->getKind())
    {
        case StreetlightApplLayer::NEIGHBOUR_DISCOVERY:
        {
//            if(simTime().dbl() >100)
//            opp_warning("LimitedFlood::handleLowerMsg:FLOOD_PATH_DISCOVERY");
            processDiscoveryMessageFromMac(m);
            break;
        }
        case StreetlightApplLayer::DATA_MSG :
        {
            //nbRxDataFrameTest++;
            processForwardedMessageFromMac(m);
            break;
        }
        case StreetlightApplLayer::ACK:
        {
            processForwardedAckFromMac(m);
            break;
        }
        default :
            error("LimitedFlood::handleLowerMsg : Unknown network state");
            break;
    }
}

/**
 * The bcMsgs list is searched for the arrived message. If the message
 * is in the list, it was already broadcasted and the function returns
 * false.
 *
 * Concurrently all outdated (older than bcDelTime) are deleted. If
 * the list is full and a new message has to be entered, the oldest
 * entry is deleted.
 **/
bool LimitedFlood::notBroadcasted(LimitedFloodPkt* msg) {

    if(isPlain)
    {
        opp_warning("LimitedFlood::notBroadcasted: is not isPlain");
        return true;
    }

    cBroadcastList::iterator it;

    //serach the broadcast list of outdated entries and delete them
    for (it = bcMsgs.begin(); it != bcMsgs.end(); it++) {
        if (it->delTime < simTime()) {
            bcMsgs.erase(it);
            it--;
        }
        //message was already broadcasted

        //if ((it->srcAddr == msg->getSrcAddr()) && (it->seqNum
        //        == msg->getSeqNum())) {
        if ((it->srcAddr == msg->getOriginalSrcAddr()) && (it->seqNum
                        == msg->getSeqNum())) {
            // update entry
            it->delTime = simTime() + bcDelTime;

            updateDataPacketDuplicateReceivedPerNode(msg->getSrcAddr());
            return false;
        }
    }

    //delete oldest entry if max size is reached
    if (bcMsgs.size() >= bcMaxEntries) {
        EV<<"bcMsgs is full, delete oldest entry\n";
        bcMsgs.pop_front();
    }

    bcMsgs.push_back(Bcast(msg->getSeqNum(), msg->getSrcAddr(), simTime() +bcDelTime));
    return true;
}

LimitedFloodPkt* LimitedFlood::encapsMsg(cPacket *appPkt) {
    LAddress::L2Type macAddr;
    LAddress::L3Type netwAddr;

    EV<<"in encaps...\n";

    LimitedFloodPkt *pkt = new LimitedFloodPkt(appPkt->getName(), appPkt->getKind());
    pkt->setBitLength(headerLength);

    cObject* cInfo = appPkt->removeControlInfo();

    if(cInfo == NULL){
    EV << "warning: Application layer did not specifiy a destination L3 address\n"
       << "\tusing broadcast address instead\n";
    netwAddr = LAddress::L3BROADCAST;
    } else {
    EV <<"CInfo removed, netw addr="<< NetwControlInfo::getAddressFromControlInfo( cInfo ) <<endl;
        netwAddr = NetwControlInfo::getAddressFromControlInfo( cInfo );
    delete cInfo;
    }

    pkt->setSrcAddr(myNetwAddr);
    pkt->setDestAddr(netwAddr);
    EV << " netw "<< myNetwAddr << " sending packet" <<endl;

    EV << "sendDown: nHop=L3BROADCAST -> message has to be broadcasted"
       << " -> set destMac=L2BROADCAST" << endl;
    macAddr = LAddress::L2BROADCAST;

    setDownControlInfo(pkt, macAddr);

    //encapsulate the application packet
    pkt->encapsulate(appPkt);
    EV <<" pkt encapsulated\n";
    return pkt;
}

void LimitedFlood::handleLowerControl(cMessage *msg) {
    //opp_warning("LimitedFlood::handleLowerControl: PACKED DROPPED 1");
    LimitedFloodPkt *netwMsg = static_cast<LimitedFloodPkt *> (msg);
    switch(msg->getKind())
    {
        case BaseDecider::PACKET_DROPPED :
        {
            //        opp_warning("LimitedFlood::handleLowerControl: PACKED DROPPED2");
            //        MacPkt * macTemp = check_and_cast<MacPkt *>(msg->dup());
            //        opp_warning("LimitedFlood::handleLowerControl: PACKED DROPPED3");
            //        cPacket * tempPacket = (macTemp->decapsulate());
            //        opp_warning("LimitedFlood::handleLowerControl: PACKED DROPPED4");
            //        //StreetlightApplPkt * ptk = check_and_cast<StreetlightApplPkt *>(tempPacket);
            //        opp_warning(" LimitedFlood::handleLowerControl:Packet_dropped");
               //    sendControlUp(macTemp);
            if(simTime().dbl() >= 15)
            {
               if(strcmp(msg->getName(),"syncOnSFD_ERRORS") == 0)
                   updateDataPacketDropSyncOnSFDError(netwMsg->getSrcAddr());
               if(strcmp(msg->getName(), "BIT_ERRORS") == 0)
                   updateDataPacketDropBitError(netwMsg->getSrcAddr());
            }
            break;
        }
        case csma::MAC_DROP_ERROR_MAX_CSMA_BACKOFFS:
        {
            //opp_warning("LimitedFlood::handleLowerControl: PACKED DROPPED 2");
            updateDataPacketDropMaxBackOff(netwMsg->getSrcAddr());
            //opp_warning("LimitedFlood::handleLowerControl: PACKED DROPPED 3");
            break;
        }
        case csma::MAC_DROP_ERROR_MAX_MISSING_ACK:
        {
            //updateDataPacketDropMaxMissingAck(netwMsg->getDestAddr());
            break;
        }
        case csma::MAC_DROP_ERROR_QUEUE_FULL:
        {
            //opp_warning("LimitedFlood::handleLowerControl: PACKED DROPPED 4");
            updateDataPacketDropQueueLimit(netwMsg->getSrcAddr());
            //opp_warning("LimitedFlood::handleLowerControl: PACKED DROPPED 5");
            break;
        }
    }

    delete netwMsg;

}


double LimitedFlood::EuclideanDist(Coord a, Coord b)
{
    return sqrt((double)(pow((a.x - b.x),2)+ pow((a.y - b.y),2)));
}
std::string toUpperCase(std::string s)
{
    for (unsigned int i = 0; i < s.length(); i++)
        s[i]=toupper(s[i]);
    return s;
}

bool LimitedFlood::isFloodOppType(std::string str)
{
    if (toUpperCase(strFloodOppType).compare(str) == 0)
        return true;
    else
        return false;
}


void LimitedFlood::setFloodOppType(std::string str)
{
    //strFloodOppType = "STREET_TOPO_LIMITED";
    //strFloodOppType ="TTL_LIMITED";
    //strFloodOppType = "DISTANCE_TO_SOURCE_LIMITED";
    //strFloodOppType = "DISTANCE_TRAVELLED_LIMITED";

    if (toUpperCase("STREET_TOPO_LIMITED").compare(str) == 0)
        myFloodOppMode = STREET_TOPO_LIMITED;
    else if (toUpperCase("TTL_LIMITED").compare(str) == 0)
        myFloodOppMode = TTL_LIMITED;
    else if (toUpperCase("DISTANCE_TO_SOURCE_LIMITED").compare(str) == 0)
        myFloodOppMode = DISTANCE_TO_SOURCE_LIMITED;
    else if (toUpperCase("DISTANCE_TRAVELLED_LIMITED").compare(str) == 0)
        myFloodOppMode = DISTANCE_TRAVELLED_LIMITED;
    else if (toUpperCase("BIT_ERROR_TEST").compare(str) == 0)
        myFloodOppMode = BIT_ERROR_TEST;
    else
        error("LimitedFlood:setFloodOppType: unsupported flood operation mode.");
}

