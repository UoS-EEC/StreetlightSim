

#ifndef _UNICAST_H_
#define _UNICAST_H_

#include <list>
#include <vector>

#include "MiXiMDefs.h"
#include "BaseNetwLayer.h"
#include "SimpleAddress.h"
#include "BaseDecider.h"
#include "MacPkt_m.h"
#include "StreetlightApplPkt_m.h"
#include "UnicastPkt_m.h"
#include "Coord.h"


class MIXIM_API Unicast : public BaseNetwLayer
{
protected:
    /** @brief Network layer sequence number*/
    unsigned long seqNum;

    /** @brief Default time-to-live (ttl) used for this module*/
    //int defaultTtl;

    /** Default time-to-live (ttl) used for neighbour nodes discovery */
    int defaultNeighbourDiscoveryTtl;

    /**@brief flooding type used for this module.  There are:
     * PLAIN_FLOOD (a ordinary flooding)
     * STREET_TOPO_LIMITED (based on streetlight topology)
     * DISTANCE_LIMITED (based on distance from the source)
     * */
    //std::string strFloodOppType;
    int intLimitedDistance;
    //bool isWithAck;

    /** @brief Defines whether to use plain flooding or not*/
    //bool isPlain;

//    class Bcast {
//    public:
//        unsigned long    seqNum;
//        LAddress::L3Type srcAddr;
//        simtime_t        delTime;
//    public:
//        Bcast(unsigned long n=0, const LAddress::L3Type& s = LAddress::L3NULL,  simtime_t_cref d=SIMTIME_ZERO) :
//            seqNum(n), srcAddr(s), delTime(d) {
//        }
//    };

//    typedef std::list<Bcast> cBroadcastList;

    /** @brief List of already broadcasted messages*/
//    cBroadcastList bcMsgs;

    /**
     * @brief Max number of entries in the list of already broadcasted
     * messages
     **/
//    unsigned int bcMaxEntries;

    /** 
     * @brief Time after which an entry for an already broadcasted msg
     * can be deleted
     **/
//    simtime_t bcDelTime;

    /* 24/06/2013 LSP
     *
     * the triggerTrafficModelSignal is used to trigger the traffic model at SUMOTraCI Scenario Manager
     *
     * */
    simsignal_t triggerTrafficModelSignal;
    bool    isNeighbourDiscoveryEnd;

    int intMyRoadId;
    bool isAtJunction;
    Coord myGeoAddr;

public:

    ~Unicast();
    /** @brief Initialization of omnetpp.ini parameters*/
    virtual void initialize(int);
    virtual void finish();

    void receiveSignal(cComponent *source, simsignal_t signalID, long l );

    enum MessagesTypes {
               UNKNOWN=0,
               DATA_MSG,
               NEIGHBOUR_DISCOVERY,
               NEIGHBOUR_DISCOVERY_TIMER,
           };

//    enum FloodOppTypes {
//        TTL_LIMITED = 0,
//        DISTANCE_TO_SOURCE_LIMITED,
//        DISTANCE_TRAVELLED_LIMITED,
//        STREET_TOPO_LIMITED,
//    };

protected:

    long nbDataPacketsReceived;
    long nbDataPacketsSent;
    long nbDataPacketsForwarded;
    long nbHops;
    long nbDataPacketsDropped;

    /** @brief Handle messages from upper layer */
    virtual void handleUpperMsg(cMessage *);

    /** @brief Handle messages from lower layer */
    virtual void handleLowerMsg(cMessage *);

    /** @brief we have no self messages */
    virtual void handleSelfMsg(cMessage* msg);
    
    /** @brief Checks whether a message was already broadcasted*/
    bool notBroadcasted(UnicastPkt* );
    virtual void handleLowerControl(cMessage *msg);
    //overloading encaps method
    UnicastPkt* encapsMsg(cPacket*);
    UnicastPkt* encapsMsg(cPacket *appPkt, LAddress::L3Type L3Addr );

    cMessage* neighbourDiscoveryTimer;

    typedef std::vector<LAddress::L3Type> path;

    typedef struct tRouteDiscoveryTableEntry {
            LAddress::L3Type initSrcAddr;
            Coord            geoAddr;
            double           distToNode;
            int              hopCount;
            path             discoverRoute;
            /*
             * for street topo discovery only
             */
            //int              roadId;
            //bool             isAtJunction;

        } tDiscoveryTableEntry;

    typedef std::map<LAddress::L3Type, tDiscoveryTableEntry>        tNeighbourTable;
    typedef std::map<LAddress::L3Type, double>                      tDistanceBasedRebroadcastTable;
    typedef std::map<LAddress::L3Type, Coord>                       tGeoAddrTable;
    typedef std::map<double,LAddress::L3Type>                       tDistToNeigbourNode;
    typedef std::multimap<double,LAddress::L3Type>                  mtDistToNeigbourNode;
    typedef std::map<LAddress::L3Type, std::string>                 tRoutePathDetail;

    tNeighbourTable                 tDiscoveredNeighbourTable ;
    tDistanceBasedRebroadcastTable  tRebroadcastTable, tPacketLatency, tPacketLastUpdate;
    tGeoAddrTable                   tReceivedRouteInfoBroadcastTable;
    tRoutePathDetail                tDetailPathTraceTable;
    mtDistToNeigbourNode             tDistToNode;

    tDiscoveryTableEntry myDiscoveryTableEntry;

    typedef std::map<int, simsignal_t> tSimsignalList;
     tSimsignalList signalTable, lastUpdateSignalTable;
     simsignal_t arrSignal,lastUpdateSignal;

    //void updateRebroadcastTable(LAddress::L3Type srcAddr, double topoDist);
   void updateRebroadcastTable(tDiscoveryTableEntry m);

   void updateRebroadcastTableUnicast(tDiscoveryTableEntry m);


    void broadcastNeighbourDiscoveryMsg();
    void printRebroadcastTable();

    void processForwardedMessageFromMac(cMessage* m);
//    void processForwardedMsgTTL(UnicastPkt* m);
//    void processForwardedMsgDistanceForSrc(UnicastPkt* m);
//    void processForwardedMsgDistanceTravelled(UnicastPkt* m);
    void processDiscoveryMessageFromMac(cMessage* m);
    void processForwardMessageFromAppl(cMessage* m);
    void processDiscoveryMessageFromAppl(cMessage* m);
    void sendDownUnicast(cMessage* msg);
    LAddress::L3Type findNextHop(LAddress::L3Type destAddr);
    typedef std::map<LAddress::L3Type, long> tDataPacket;
    tDataPacket     tNBDataPacketReceivedPerNode, tNBDataPacketForwardPerNode, tNBDataPacketDropQueueLimit,
                       tNBDataPacketDropMaxBackOff, tNBDataPacketDropBitError, tNBDataPacketDropSyncOnSFDError,
                       tNBDataPacketDropMaxMissingAck;

    typedef std::map<std::string, long> tStrDataPacket;
    tStrDataPacket tStrNBDataPacketDropSyncOnSFDError;

    typedef std::map<double, long> tDelay;
    typedef std::vector<tDelay> delay;
    typedef std::map<LAddress::L3Type, delay> tDelayUpdate;
    tDelayUpdate        tDelayUpdatePerNode;

   void updateDataPacketReceivedPerNode(LAddress::L3Type nodeId);
   void recordDataPacketReceivedPerNode();
   void updateDataPacketForwardedPerNode(LAddress::L3Type nodeId);
   void recordDataPacketForwardedPerNode();
   void updateDataPacketLatencyPerNode(LAddress::L3Type nodeId, double TxTime);
   void recordDataPacketLatencyPerNode();
   void updateDataPacketDropQueueLimit(LAddress::L3Type nodeId);
   void recordDataPacketDropQueueLimit();
   void updateDataPacketDropMaxBackOff(LAddress::L3Type nodeId);
   void recordDataPacketDropMaxBackOff();
   void updateDataPacketDropBitError(LAddress::L3Type nodeId);
   void recordDataPacketDropBitError();
   void updateDataPacketDropSyncOnSFDError(LAddress::L3Type sourceNodeId, LAddress::L3Type FinalDestNodeId);
   void recordDataPacketDropSyncOnSFDError();
   void updateLastUpdatePerNode(LAddress::L3Type nodeId, double TxTime);
   void recordLastUpdatePerNode();
   void updateDataPacketDropMaxMissingAck(LAddress::L3Type nodeId);
   void recordDataPacketDropMaxMissingAck();
   double EuclideanDist(Coord a, Coord b);
   std::string toUpperCase(std::string s);

//   double EuclideanDist(Coord a, Coord b)
//   {
//       return sqrt((double)(pow((a.x - b.x),2)+ pow((a.y - b.y),2)));
//   }
//   std::string toUpperCase(std::string s)
//   {
//       for (unsigned int i = 0; i < s.length(); i++)
//           s[i]=toupper(s[i]);
//       return s;
//   }

//   bool isFloodOppType(std::string str)
//   {
//       if (toUpperCase(strFloodOppType).compare(str) == 0)
//           return true;
//       else
//           return false;
//   }
//   FloodOppTypes myFloodOppMode;

//   void setFloodOppType(std::string str)
//   {
//       //strFloodOppType = "STREET_TOPO_LIMITED";
//       //strFloodOppType ="TTL_LIMITED";
//       //strFloodOppType = "DISTANCE_TO_SOURCE_LIMITED";
//       //strFloodOppType = "DISTANCE_TRAVELLED_LIMITED";
//
//       if (toUpperCase("STREET_TOPO_LIMITED").compare(str) == 0)
//           myFloodOppMode = STREET_TOPO_LIMITED;
//       else if (toUpperCase("TTL_LIMITED").compare(str) == 0)
//           myFloodOppMode = TTL_LIMITED;
//       else if (toUpperCase("DISTANCE_TO_SOURCE_LIMITED").compare(str) == 0)
//           myFloodOppMode = DISTANCE_TO_SOURCE_LIMITED;
//       else if (toUpperCase("DISTANCE_TRAVELLED_LIMITED").compare(str) == 0)
//           myFloodOppMode = DISTANCE_TRAVELLED_LIMITED;
//       else
//           error("LimitedFlood:setFloodOppType: unsupported flood operation mode.");
//   }

};

#endif
