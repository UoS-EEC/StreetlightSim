#include "Unicast.h"
#include <cassert>
#include <sstream>
#include "NetwPkt_m.h"
#include "NetwControlInfo.h"
#include <string>
#include "csma.h"

using std::endl;
using std::make_pair;
using std::map;

Define_Module(Unicast);

/**
 * Reads all parameters from the ini file. If a parameter is not
 * specified in the ini file a default value will be set.
 **/
void Unicast::initialize(int stage) {
    BaseNetwLayer::initialize(stage);

    if (stage == 0) {
        //initialize seqence number to 0
        seqNum = 0;
        nbDataPacketsReceived = 0;
        nbDataPacketsSent = 0;
        nbDataPacketsForwarded = 0;
        nbHops = 0;

        hasPar("defaultNeighbourDiscoveryTtl") ? defaultNeighbourDiscoveryTtl = par("defaultNeighbourDiscoveryTtl") : defaultNeighbourDiscoveryTtl = 5;
        hasPar("limitedFloodDistance")? intLimitedDistance = par("limitedFloodDistance") : intLimitedDistance = 150;

        neighbourDiscoveryTimer = new cMessage("neighbour-discovery-timer", NEIGHBOUR_DISCOVERY_TIMER);
        isNeighbourDiscoveryEnd = false;

    }
    else
    {
        triggerTrafficModelSignal = registerSignal("triggerTrafficModel");
        simulation.getSystemModule()->subscribe(triggerTrafficModelSignal,this);
    }
}

void Unicast::receiveSignal(cComponent *source, simsignal_t signalID, long l )
{
    if (signalID == triggerTrafficModelSignal)
    {
        //opp_warning("[%d]: Unicast::receiveSignal:debug: triggerTrafficModelSignal start",getParentModule()->getIndex());
        isNeighbourDiscoveryEnd = true;
    }
}

Unicast::~Unicast()
{
    //cancelEvent(neighbourDiscoveryTimer);
    cancelAndDelete(neighbourDiscoveryTimer);
}
void Unicast::finish() {

    simulation.getSystemModule()->unsubscribe(triggerTrafficModelSignal,this);

    recordScalar("nbDataPacketsReceived", nbDataPacketsReceived);
    recordScalar("nbDataPacketsSent", nbDataPacketsSent);
    recordScalar("nbDataPacketsForwarded", nbDataPacketsForwarded);
    if (nbDataPacketsReceived > 0) {
      recordScalar("meanNbHops", (double) nbHops / (double) nbDataPacketsReceived);
    } else {
        recordScalar("meanNbHops", 0);
    }
    recordDataPacketForwardedPerNode();
    recordDataPacketReceivedPerNode();
    recordDataPacketLatencyPerNode();
    recordDataPacketDropMaxBackOff();
    recordDataPacketDropQueueLimit();
    recordDataPacketDropBitError();
    recordDataPacketDropSyncOnSFDError();
    recordDataPacketDropMaxBackOff();
    recordLastUpdatePerNode();

    if(neighbourDiscoveryTimer->isScheduled())
    {
        cancelEvent(neighbourDiscoveryTimer);
        delete (neighbourDiscoveryTimer);
        neighbourDiscoveryTimer = 0;
    }
}
void Unicast::broadcastNeighbourDiscoveryMsg()
{
    /*
     * Send route flood packet and restart the timer
     */
    UnicastPkt* pkt = new UnicastPkt("route-discovery-flood", NEIGHBOUR_DISCOVERY);
    pkt->setByteLength(headerLength);
    pkt->setSrcAddr(myNetwAddr);
    pkt->setDestAddr(LAddress::L3BROADCAST);
    pkt->setTtl(defaultNeighbourDiscoveryTtl);
    pkt->setInitialSrcGeoAddr(myDiscoveryTableEntry.geoAddr);
    pkt->setPreviousNodeAddr(myNetwAddr);
    path tempPath;
    tempPath.push_back(myNetwAddr);
    pkt->setRoute(tempPath);
    //    pkt->setIsAtJunction(myDiscoveryTableEntry.isAtJunction);
    //    pkt->setRoadId(myDiscoveryTableEntry.roadId);

    setDownControlInfo(pkt, LAddress::L2BROADCAST);
    sendDown(pkt);
}
void Unicast::handleSelfMsg(cMessage* msg)
{
    if (msg->getKind() == NEIGHBOUR_DISCOVERY_TIMER)
    {
        broadcastNeighbourDiscoveryMsg();
        /*
         * schedule the next route broadcast
         */
        if(!isNeighbourDiscoveryEnd)
            scheduleAt(simTime() + uniform(0, 1.0), neighbourDiscoveryTimer);
    }
}

void Unicast::handleUpperMsg(cMessage* m) {

    switch(m->getKind())
    {
        case  NEIGHBOUR_DISCOVERY:
        {
            StreetlightApplPkt *msgAppl = static_cast<StreetlightApplPkt*> (m);

            myDiscoveryTableEntry.geoAddr = msgAppl->getGeoAddrLamppost();;
            myDiscoveryTableEntry.initSrcAddr = myNetwAddr;
            myDiscoveryTableEntry.distToNode = 0;
            myDiscoveryTableEntry.hopCount = 0;
            myDiscoveryTableEntry.discoverRoute.push_back(myNetwAddr);
            //myDiscoveryTableEntry.roadId = msgAppl->getIntRoadID();;
            //myDiscoveryTableEntry.isAtJunction = msgAppl->getIsAtJunction();


            ev<<"Unicast::handleUpperMsg: NEIGHBOUR_DISCOVERY : node ["<<myNetwAddr<<"] Coodinate : ("<<msgAppl->getGeoAddrLamppost().x <<","
                <<myDiscoveryTableEntry.geoAddr.y<<")"<<endl ;
            scheduleAt(simTime() + uniform(0.5, 1.5), neighbourDiscoveryTimer);

            delete m;
            break;
        }
        case DATA_MSG:
        {
            sendDownUnicast(m);
            break;
        }
        default:
            error("Unicast::handleUpperMsg: Unknown message type ::");
            break;
    }
}
void Unicast::sendDownUnicast(cMessage* msg)
{

    tNeighbourTable::iterator pos;
    assert(dynamic_cast<cPacket*> (msg));

    mtDistToNeigbourNode::iterator posDist;
    //opp_warning("Unicast::sendDownUnicast:1");
    for(posDist = tDistToNode.begin(); posDist != tDistToNode.end(); posDist++)
    {
        //opp_warning("Unicast::sendDownUnicast:2");
        ev<<"Unicast:: (1) sendDownUnicast to node  ["<<posDist->second<<"] distance is "<<posDist->first<<" route is "<<endl;
        //if(posDist->first <= intLimitedDistance && (posDist->second == 2 || posDist->second ==  4))
        //if(posDist->first <= intLimitedDistance)
        if(posDist->first <= (intLimitedDistance + 2))
        {

            ev<<"Unicast::(2) sendDownUnicast to node ["<<posDist->second<<"] distance is "<<posDist->first<<" route is "<<endl;

            path::iterator posPath;
            tNeighbourTable::iterator pos = tDiscoveredNeighbourTable.find(posDist->second);

            for(posPath = pos->second.discoverRoute.begin(); posPath != pos->second.discoverRoute.end(); posPath++)
            {
                ev<<*posPath<<"->";

            }
            ev<<endl;
            //for debugging purpose
            //if(posDist->second == 3)
            //{
                UnicastPkt *netwPkt = encapsMsg(static_cast<cPacket*> (msg->dup()), LAddress::L3Type(posDist->second));
                //opp_warning("Unicast::sendDownUnicast:3");
                netwPkt->setTimestamp();
                sendDown(netwPkt);
                nbDataPacketsSent++;
            //}
        }
    }
    delete msg;
}

LAddress::L3Type Unicast::findNextHop(LAddress::L3Type destAddr)
{
    tNeighbourTable::iterator pos = tDiscoveredNeighbourTable.find(destAddr);

    if(pos != tDiscoveredNeighbourTable.end())
    {
        if(pos->second.discoverRoute.size() >= 2)
        {
            return pos->second.discoverRoute.at(pos->second.discoverRoute.size()-2);
        }
        else
        {
            return LAddress::L3BROADCAST;
        }
    }
    else
    {
        return LAddress::L3BROADCAST;
    }
    return LAddress::L3BROADCAST;
}
void Unicast::updateDataPacketDropQueueLimit(LAddress::L3Type nodeId)
{
    tDataPacket::iterator pos = tNBDataPacketDropQueueLimit.find(nodeId);
    if(pos != tNBDataPacketDropQueueLimit.end())
        pos->second++;
    else
        tNBDataPacketDropQueueLimit.insert(make_pair(nodeId, 1));
}
void Unicast::recordDataPacketDropQueueLimit()
{
    tDataPacket::iterator pos;
    std::string strNodeId;
    ev<<"Unicast::recordDataPacketDropQueueLimit:size : "<< tNBDataPacketDropQueueLimit.size()<<endl;
    for(pos = tNBDataPacketDropQueueLimit.begin(); pos != tNBDataPacketDropQueueLimit.end(); pos++)
    {
        strNodeId= "node[" + static_cast<std::ostringstream*>( &(std::ostringstream() << pos->first))->str() + "]_NBDataPacketDropQueueLimit";
        recordScalar(strNodeId.c_str(), pos->second);
        ev<<"Unicast::tNBDataPacketDropQueueLimit: "<< strNodeId << " = "<<pos->second<<endl;
    }
}
void Unicast::updateDataPacketDropBitError(LAddress::L3Type nodeId)
{

    tDataPacket::iterator pos =  tNBDataPacketDropBitError.find(nodeId);
    if(pos != tNBDataPacketDropBitError.end())
        pos->second++;
    else
        tNBDataPacketDropBitError.insert(make_pair(nodeId, 1));
}
void Unicast::recordDataPacketDropBitError()
{
    tDataPacket::iterator pos;
    std::string strNodeId;
    ev<<"Unicast::recordDataPacketDropQueueLimit:size : "<< tNBDataPacketDropBitError.size()<<endl;
    for(pos = tNBDataPacketDropBitError.begin(); pos != tNBDataPacketDropBitError.end(); pos++)
    {
        strNodeId= "node[" + static_cast<std::ostringstream*>( &(std::ostringstream() << pos->first))->str() + "]_NBDataPacketDropBitError";
        recordScalar(strNodeId.c_str(), pos->second);
        ev<<"Unicast::tNBDataPacketDropBitError: "<< strNodeId << " = "<<pos->second<<endl;
    }
}
void Unicast::updateDataPacketDropSyncOnSFDError(LAddress::L3Type sourceNodeId, LAddress::L3Type finalDestNodeId)
{

//    tDataPacket::iterator pos =   tNBDataPacketDropSyncOnSFDError.find(sourceNodeId);
//    if(pos !=  tNBDataPacketDropSyncOnSFDError.end())
//       pos->second++;
//    else
//        tNBDataPacketDropSyncOnSFDError.insert(make_pair(sourceNodeId, 1));
//
//    }
    tStrDataPacket::iterator pos;
    std::string strSrcToDest = static_cast<std::ostringstream*>( &(std::ostringstream() << sourceNodeId))->str() + "-" +
            static_cast<std::ostringstream*>( &(std::ostringstream() << finalDestNodeId))->str();

    pos = tStrNBDataPacketDropSyncOnSFDError.find(strSrcToDest);

    if(pos == tStrNBDataPacketDropSyncOnSFDError.end())
    {
        tStrNBDataPacketDropSyncOnSFDError.insert(make_pair(strSrcToDest,1));
    }
    else
    {
        pos->second++;
    }
}
void Unicast::recordDataPacketDropSyncOnSFDError()
{
//    tDataPacket::iterator pos;
//    std::string strNodeId;
//    ev<<"Unicast::tNBDataPacketDropSyncOnSFDError:size : "<< tNBDataPacketDropSyncOnSFDError.size()<<endl;
//    for(pos = tNBDataPacketDropSyncOnSFDError.begin(); pos != tNBDataPacketDropSyncOnSFDError.end(); pos++)
//    {
//        strNodeId= "node[" + static_cast<std::ostringstream*>( &(std::ostringstream() << pos->first))->str() + "]_NBDataPacketDropSyncOnSFDError";
//        recordScalar(strNodeId.c_str(), pos->second);
//        ev<<"Unicast::tNBDataPacketDropSyncOnSFDError: "<< strNodeId << " = "<<pos->second<<endl;
//    }

    tStrDataPacket::iterator pos;
    for(pos = tStrNBDataPacketDropSyncOnSFDError.begin(); pos != tStrNBDataPacketDropSyncOnSFDError.end(); pos++)
    {
        recordScalar(pos->first.c_str(), pos->second);
    }
}

void Unicast::updateDataPacketDropMaxBackOff(LAddress::L3Type nodeId)
{
    tDataPacket::iterator pos =  tNBDataPacketDropMaxBackOff.find(nodeId);
    if(pos != tNBDataPacketDropMaxBackOff.end())
        pos->second++;
    else
        tNBDataPacketDropMaxBackOff.insert(make_pair(nodeId, 1));
}
void Unicast::recordDataPacketDropMaxBackOff()
{
    tDataPacket::iterator pos;
    std::string strNodeId;
    ev<<"Unicast::recordDataPacketDropMaxBackOff:size : "<< tNBDataPacketDropMaxBackOff.size()<<endl;
    for(pos = tNBDataPacketDropMaxBackOff.begin(); pos != tNBDataPacketDropMaxBackOff.end(); pos++)
    {
        strNodeId= "node[" + static_cast<std::ostringstream*>( &(std::ostringstream() << pos->first))->str() + "]_NBDataPacketDropMaxBackOff";
        recordScalar(strNodeId.c_str(), pos->second);
        ev<<"Unicast::tNBDataPacketDropMaxBackOff: "<< strNodeId << " = "<<pos->second<<endl;
    }
}

void Unicast::updateDataPacketForwardedPerNode(LAddress::L3Type nodeId)
{
    tDataPacket::iterator pos = tNBDataPacketForwardPerNode.find(nodeId);
    if(pos != tNBDataPacketForwardPerNode.end())
        pos->second++;
    else
        tNBDataPacketForwardPerNode.insert(make_pair(nodeId,1));
}
void Unicast::recordDataPacketForwardedPerNode()
{

    tDataPacket::iterator pos;
    std::string strNodeId;
    ev<<"Unicast::recordDataPacketForwardedPerNode:size : "<< tNBDataPacketForwardPerNode.size()<<endl;
    for(pos = tNBDataPacketForwardPerNode.begin(); pos != tNBDataPacketForwardPerNode.end(); pos++)
    {
        strNodeId= "node[" + static_cast<std::ostringstream*>( &(std::ostringstream() << pos->first))->str() + "]_NBDataPacketForwarded";
        recordScalar(strNodeId.c_str(), pos->second);
        ev<<"Unicast::recordDataPacketForwardedPerNode: "<< strNodeId << " = "<<pos->second<<endl;
    }
}

void Unicast::recordDataPacketReceivedPerNode()
{
    tDataPacket::iterator pos;
    std::string strNodeId;
    ev<<"Unicast::recordDataPacketReceivedPerNode:size : "<< tNBDataPacketReceivedPerNode.size()<<endl;
    for(pos = tNBDataPacketReceivedPerNode.begin(); pos != tNBDataPacketReceivedPerNode.end(); pos++)
    {
        strNodeId= "node[" + static_cast<std::ostringstream*>( &(std::ostringstream() << pos->first) )->str() + "]_NBDataPacketReceived";
        recordScalar(strNodeId.c_str(), pos->second);
        ev<<"Unicast::recordDataPacketReceivedPerNode: "<< strNodeId << " = "<<pos->second<<endl;
    }
}

void Unicast::updateLastUpdatePerNode(LAddress::L3Type nodeId, double TxTime)
{
    tDistanceBasedRebroadcastTable::iterator posLastUpdate = tPacketLastUpdate.find(nodeId);
        if(posLastUpdate == tPacketLastUpdate.end())
        {
            tPacketLastUpdate.insert(make_pair(nodeId, TxTime));
            std::string strName = "node_"+ static_cast<std::ostringstream*>( &(std::ostringstream() << nodeId))->str()+"_LastUpdate";
            lastUpdateSignal = registerSignal(strName.c_str());
            lastUpdateSignalTable.insert(std::make_pair(nodeId, lastUpdateSignal));
            emit(lastUpdateSignal, simTime().dbl() - TxTime);
        }
        else
        {
            tSimsignalList::iterator posSignal = lastUpdateSignalTable.find(nodeId);

            emit(posSignal->second, TxTime - posLastUpdate->second);
    //        if(posLastUpdate->second < TxTime)
    //        {
                posLastUpdate->second = TxTime;
    //        }
        }

}
void Unicast::recordLastUpdatePerNode()
{
//    std::string strNodeId;
//    for (tDelayUpdate::iterator pos = tDelayUpdatePerNode.begin(); pos != tDelayUpdatePerNode.end(); pos++)
//    {
//        tDelay b = pos->second.at(0) ;
//        for(tDelay::iterator pos_tDelay = b.begin(); pos_tDelay != b.end(); pos_tDelay++ )
//        {
//            strNodeId= "node[" + static_cast<std::ostringstream*>( &(std::ostringstream() << pos->first) )->str() + "]_Delay("+ static_cast<std::ostringstream*>( &(std::ostringstream() << pos_tDelay->first) )->str() +")";
//            recordScalar(strNodeId.c_str(), pos_tDelay->second);
//        }
//    }
}

void Unicast::updateDataPacketLatencyPerNode(LAddress::L3Type nodeId, double TxTime)
{
    tDistanceBasedRebroadcastTable::iterator pos = tPacketLatency.find(nodeId);
    if(pos == tPacketLatency.end())
        tPacketLatency.insert(make_pair(nodeId, simTime().dbl() - TxTime));
    else
        pos->second += simTime().dbl() - TxTime;

    updateLastUpdatePerNode(nodeId, TxTime);

    tSimsignalList::iterator posSignal = signalTable.find(nodeId);
    if(posSignal != signalTable.end())
    {
        emit(posSignal->second, simTime().dbl() - TxTime);
    }
    else
    {
        std::string strName = "node_"+ static_cast<std::ostringstream*>( &(std::ostringstream() << nodeId))->str()+"_Latency";
        arrSignal = registerSignal(strName.c_str());
        signalTable.insert(std::make_pair(nodeId, arrSignal));
        emit(arrSignal, simTime().dbl() - TxTime);
    }

}
void Unicast::recordDataPacketLatencyPerNode()
{
    tDataPacket::iterator pos;
    std::string strNodeId;
    ev<<"Unicast::tPacketLatency:size : "<< tPacketLatency.size()<<endl;
    for(pos = tNBDataPacketReceivedPerNode.begin(); pos != tNBDataPacketReceivedPerNode.end(); pos++)
    {
        strNodeId= "node[" + static_cast<std::ostringstream*>( &(std::ostringstream() << pos->first) )->str() + "]_AverageLatency";
        recordScalar(strNodeId.c_str(), ((tPacketLatency.find(pos->first)->second) / pos->second));
        ev<<"Unicast::recordDataPacketLatencyPerNode: "<< strNodeId << " = "<<((tPacketLatency.find(pos->first)->second) / pos->second)<<endl;
    }
}
void Unicast::updateDataPacketReceivedPerNode(LAddress::L3Type nodeId)
{
    tDataPacket::iterator pos = tNBDataPacketReceivedPerNode.find(nodeId);
    if(pos != tNBDataPacketReceivedPerNode.end())
        pos->second++;
    else
        tNBDataPacketReceivedPerNode.insert(make_pair(nodeId,1));
}

void Unicast::updateDataPacketDropMaxMissingAck(LAddress::L3Type nodeId)
{
    tDataPacket::iterator pos = tNBDataPacketDropMaxMissingAck.find(nodeId);
    if(pos != tNBDataPacketDropMaxMissingAck.end())
        pos->second++;
    else
        tNBDataPacketDropMaxMissingAck.insert(make_pair(nodeId, 1));
}

void Unicast::recordDataPacketDropMaxMissingAck()
{
   tDataPacket::iterator pos;
   std::string strNodeId;
   ev<<"Unicast::tNBDataPacketDropMaxMissingAck:size : "<< tNBDataPacketDropMaxMissingAck.size()<<endl;
   for(pos = tNBDataPacketDropMaxMissingAck.begin(); pos != tNBDataPacketDropMaxMissingAck.end(); pos++)
   {
       strNodeId= "node[" + static_cast<std::ostringstream*>( &(std::ostringstream() << pos->first) )->str() + "]_NBDataPacketDropMaxMissingAck";
       recordScalar(strNodeId.c_str(), pos->second);
       ev<<"Unicast::recordDataPackeetDropMaxMissingAckPerNode: "<< strNodeId << " = "<<pos->second<<endl;
   }
}

/**
 * Messages from the mac layer will be forwarded to the application
 * only if the are broadcast or destined for this node.
 *
 * If the arrived message is a broadcast message it is also reflooded
 * only if the tll field is bigger than one. Before the message is
 * handed back to the mac layer the ttl field is reduced by one to
 * account for this hop.
 *
 * In the case of plain flooding the message will only be processed if
 * there is no corresponding entry in the bcMsgs list (@ref
 * notBroadcasted). Otherwise the message will be deleted.
 **/
void Unicast::processForwardedMessageFromMac(cMessage* m)
{
    UnicastPkt *msg = static_cast<UnicastPkt *> (m);
    //msg is for me
    if(msg->getSrcAddr() != myNetwAddr)
    {
        if (msg->getDestAddr() == myNetwAddr)
        {
            EV<<" data msg for me! send to Upper"<<endl;
            //opp_warning("Unicast::processForwardedMessageFromMac : data msg is for me");
            //nbHops = nbHops + (defaultTtl + 1 - msg->getTtl());

            nbDataPacketsReceived++;
            updateDataPacketReceivedPerNode(msg->getSrcAddr());
            updateDataPacketLatencyPerNode(msg->getSrcAddr(), msg->getTimestamp().dbl());

            sendUp(decapsMsg(msg) );
        }
        //not for me -> forward
        else
        {
            EV<<" data msg not for me! proceed to next hop"<<endl;
            //opp_warning("Unicast::processForwardedMessageFromMac : data msg is not for me, proceed to next hop");

            msg->setPreviousNodeAddr(myNetwAddr);

            cObject *const pCtrlInfo = msg->removeControlInfo();
            if (pCtrlInfo != NULL)
                delete pCtrlInfo;
            setDownControlInfo(msg, findNextHop(msg->getDestAddr()));
            sendDown(msg);

        }
    }
    else
    {
        ev<<"The msg is originate from myself"<<endl;
        delete msg;
    }
}

void Unicast::printRebroadcastTable()
{

    tNeighbourTable::iterator pos;

    ev<<"Unicast::printRebroadcastTable::Lamp["<<getParentModule()->getIndex()<<"] : start"<<endl;
    for(pos = tDiscoveredNeighbourTable.begin(); pos != tDiscoveredNeighbourTable.end(); pos++)
    {
        ev<<"Unicast::printRebroadcastTable::lamp["<<getParentModule()->getIndex()<<"] - tDiscoveredNeigbourTable ["<<pos->first<<"] distance is "<< pos->second.distToNode
                <<" hop count : "<<pos->second.hopCount<< " vector size :"<<   pos->second.discoverRoute.size()<<endl;
        ev<<"    ->path :";
        path::iterator posPath;
        for(posPath = pos->second.discoverRoute.begin(); posPath != pos->second.discoverRoute.end(); posPath++)
        {
            ev<<*posPath<<"->";
        }
        ev<<endl;
    }
}

void Unicast::updateRebroadcastTableUnicast(tDiscoveryTableEntry m)
{

    tNeighbourTable::iterator pos;
    mtDistToNeigbourNode::iterator posDist;
    m.distToNode = EuclideanDist(myDiscoveryTableEntry.geoAddr, m.geoAddr);

    if(m.initSrcAddr != myNetwAddr)
    {
        pos = tDiscoveredNeighbourTable.find(m.initSrcAddr);
        if(pos == tDiscoveredNeighbourTable.end())
        {
            tDiscoveredNeighbourTable.insert(make_pair(m.initSrcAddr,m));
            tDistToNode.insert(make_pair(m.distToNode,m.initSrcAddr));
        }
        else
        {
            if(pos->second.hopCount > m.hopCount)
                pos->second = m;

            for(posDist = tDistToNode.begin(); posDist != tDistToNode.end(); posDist++)
            {
                if(posDist->second == m.initSrcAddr && posDist->first > m.distToNode)
                {
                    tDistToNode.erase(posDist);
                    tDistToNode.insert(make_pair(m.distToNode,m.initSrcAddr));
                }
            }
        }
    }
}


void Unicast::processDiscoveryMessageFromMac(cMessage* m)
{
    UnicastPkt* netwDiscMsg = check_and_cast<UnicastPkt*> (m);
    tDiscoveryTableEntry newEntry;


    newEntry.geoAddr = netwDiscMsg->getInitialSrcGeoAddr();
    newEntry.initSrcAddr = netwDiscMsg->getSrcAddr();
    newEntry.distToNode = EuclideanDist(myDiscoveryTableEntry.geoAddr, newEntry.geoAddr);
    newEntry.hopCount = (defaultNeighbourDiscoveryTtl + 1) - netwDiscMsg->getTtl() ;
    newEntry.discoverRoute = netwDiscMsg->getRoute();
    newEntry.discoverRoute.push_back(myNetwAddr);
    ev<<"Unicast::processDiscoveryMessageFromMac: node ["<<newEntry.initSrcAddr <<"] geoAddr ("<< newEntry.geoAddr.x << "," << newEntry.geoAddr.y<<"), cur TTL="<<netwDiscMsg->getTtl()<<endl;

    updateRebroadcastTableUnicast(newEntry);
    printRebroadcastTable();

    if(netwDiscMsg->getTtl() > 1)
    {
        cObject *const pCtrlInfo = netwDiscMsg->removeControlInfo();
        if (pCtrlInfo != NULL) delete pCtrlInfo;
        netwDiscMsg->setTtl(netwDiscMsg->getTtl()-1);
        netwDiscMsg->getRoute().push_back(myNetwAddr);
        setDownControlInfo(netwDiscMsg, LAddress::L3BROADCAST);
        sendDown(netwDiscMsg);
    }
    else
        delete netwDiscMsg;

}

void Unicast::handleLowerMsg(cMessage* m)
{
    switch(m->getKind())
    {
        case NEIGHBOUR_DISCOVERY:
        {
//            if(simTime().dbl() >100)
//            opp_warning("Unicast::handleLowerMsg:FLOOD_PATH_DISCOVERY");
            processDiscoveryMessageFromMac(m);
            break;
        }
        case DATA_MSG :
        {
            processForwardedMessageFromMac(m);
            break;
        }
        default :
            error("Unicast::handleLowerMsg : Unknown network state");
            break;
    }
}

UnicastPkt* Unicast::encapsMsg(cPacket *appPkt, LAddress::L3Type L3Addr ) {
    LAddress::L2Type macAddr;

    EV<<"in encaps...\n";

    UnicastPkt *pkt = new UnicastPkt(appPkt->getName(), appPkt->getKind());
    pkt->setBitLength(headerLength);

    cObject* cInfo = appPkt->removeControlInfo();
    if(cInfo != NULL){
       delete cInfo;
       }

    pkt->setSrcAddr(myNetwAddr);
    pkt->setDestAddr(L3Addr);
    EV << " netw "<< myNetwAddr << " sending packet" <<endl;

    macAddr = LAddress::L2Type(findNextHop(L3Addr)) ;
    EV << "sendDown: Destination="<<L3Addr<<" -> message has to be next hop"
       << " -> set destMac="<<macAddr<< endl;


    setDownControlInfo(pkt, macAddr);

    //encapsulate the application packet
    pkt->encapsulate(appPkt);
    EV <<" pkt encapsulated\n";
    return pkt;
}

UnicastPkt* Unicast::encapsMsg(cPacket *appPkt) {
    LAddress::L2Type macAddr;
    LAddress::L3Type netwAddr;

    EV<<"in encaps...\n";

    UnicastPkt *pkt = new UnicastPkt(appPkt->getName(), appPkt->getKind());
    pkt->setBitLength(headerLength);

    cObject* cInfo = appPkt->removeControlInfo();

    if(cInfo == NULL){
    EV << "warning: Application layer did not specifiy a destination L3 address\n"
       << "\tusing broadcast address instead\n";
    netwAddr = LAddress::L3BROADCAST;
    } else {
    EV <<"CInfo removed, netw addr="<< NetwControlInfo::getAddressFromControlInfo( cInfo ) <<endl;
        netwAddr = NetwControlInfo::getAddressFromControlInfo( cInfo );
    delete cInfo;
    }

    pkt->setSrcAddr(myNetwAddr);
    pkt->setDestAddr(netwAddr);
    EV << " netw "<< myNetwAddr << " sending packet" <<endl;

    EV << "sendDown: nHop=L3BROADCAST -> message has to be broadcasted"
       << " -> set destMac=L2BROADCAST" << endl;
    macAddr = LAddress::L2BROADCAST;

    setDownControlInfo(pkt, macAddr);

    //encapsulate the application packet
    pkt->encapsulate(appPkt);
    EV <<" pkt encapsulated\n";
    return pkt;
}



void Unicast::handleLowerControl(cMessage *msg) {
    //opp_warning("Unicast::handleLowerControl: PACKED DROPPED 1");
    UnicastPkt *netwMsg = static_cast<UnicastPkt *> (msg);
    switch(msg->getKind())
    {
        case BaseDecider::PACKET_DROPPED :
        {
           if(strcmp(netwMsg->getName(),"syncOnSFD_ERRORS") == 0)
               //updateDataPacketDropSyncOnSFDError(netwMsg->getSrcAddr());
               updateDataPacketDropSyncOnSFDError(netwMsg->getSrcAddr(), netwMsg->getDestAddr());
           if(strcmp(netwMsg->getName(), "BIT_ERRORS") == 0)
               updateDataPacketDropBitError(netwMsg->getSrcAddr());
            break;
        }
        case csma::MAC_DROP_ERROR_MAX_CSMA_BACKOFFS:
        {
            //updateDataPacketDropMaxBackOff(netwMsg->getSrcAddr());
            updateDataPacketDropMaxBackOff(netwMsg->getDestAddr());
            break;
        }
        case csma::MAC_DROP_ERROR_MAX_MISSING_ACK:
        {
            updateDataPacketDropMaxMissingAck(netwMsg->getDestAddr());
            break;
        }
        case csma::MAC_DROP_ERROR_QUEUE_FULL:
        {
            updateDataPacketDropQueueLimit(netwMsg->getSrcAddr());
            break;
        }
    }

    delete netwMsg;
}

double Unicast::EuclideanDist(Coord a, Coord b)
  {
      return sqrt((double)(pow((a.x - b.x),2)+ pow((a.y - b.y),2)));
  }

std::string Unicast::toUpperCase(std::string s)
  {
      for (unsigned int i = 0; i < s.length(); i++)
          s[i]=toupper(s[i]);
      return s;
  }

