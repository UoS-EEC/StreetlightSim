//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#ifndef SENSORDATA_H_
#define SENSORDATA_H_

#include <Coord.h>
#include "SimpleAddress.h"
class SensorData {
public:
    bool isPedestrianInRange;
    double dblDistPedestrian;
    double dblSpeedPedestrian; //only used to store pedestrian's speed.  Not used in packet

    bool isCyclistInRange;
    double dblDistCyclist;
    double dblSpeedCyclist; //only used to store cyclist's speed. Not used in packet

    bool isMotoristInRange;
    double dblDistMotorist;
    double dblSpeedMotorist; //only used to store motorist's speed. Not used in packet

    double dblMotoristSSD; //only used to store the SSD of a motorist assuming the sensor able to compute the speed of the sensed motorist.

    unsigned long dataSeqNum;
    double dataTimeStamp;
    double dataValidity;
    //double dblDistBtwLamppost; //only used to store the distance between received geoAddr with recipient (lamppost which receive the packet)

    LAddress::L3Type dataOriginateFrom;

    Coord geoAddrLamppost; //Lamppost's geoAddr
    int intOperationStatus; //Lamppost operation status;
    double dblBrightnessLevel; //Lmappost's brightness level
    Coord geoAddrMotorist; //motorist's geoAddr.  Only the nearest one is detected.
    Coord geoAddrPedestrainOrCyclist; //pedestrian or cyclist 's geoAddr.  Only the nearest one is detected.

    SensorData();
    virtual ~SensorData();
    double getMinObjDist();
    double getMaxObjDist();
    void reset();
};

#endif /* SENSORDATA_H_ */
