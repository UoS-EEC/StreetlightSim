//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#include "StreetlightApplLayer.h"

#include "NetwControlInfo.h"
#include "SimpleAddress.h"
#include "StreetlightApplPkt_m.h"
#include "LimitedFloodPkt_m.h"
#include "LimitedFlood.h"
#include "FindModule.h"


using std::make_pair;

Define_Module(StreetlightApplLayer);

const simsignalwrap_t StreetlightApplLayer::mobilityStateChangedSignal = simsignalwrap_t(MIXIM_SIGNAL_MOBILITY_CHANGE_NAME);

void StreetlightApplLayer::initialize(int stage)
{
    // TODO - Generated method body
    BaseApplLayer::initialize(stage);

    if (stage == 0) {

        distBtwSensorAndRoadUser = dblMaxLampPoleSensingDistance;
        minDistanceForPedestrianOrCyclist = dblMaxLampPoleSensingDistance;

        dblGodModeBrightnessLevel = 0.0;
        intObjCount = 0;
        distBtwSensorAndRoadUser = 0;

        nbPacketToTx = 2;
        /*
         * For streetlight sensing distance.  For God mode 150 m is assumed
         */
        dblMaxLampPoleSensingDistance = par("maxLamppostSensingDistance").doubleValue();
        /*
         * To determine whether road users' speed could be detected or not
         * Defaul = false;
         */
        isSpeedSensingEnable = par("isSpeedSensingEnable").boolValue();
        /*
         * Default SSD if speed cannot be detected (isSpeedSensingEnable = false). 59.71997 m is assumed based on residential road speed (30 miles per hour)
         */
        dblDefaultSSD = par("dblDefaultSSD").doubleValue();
        /*
         * to control the stopping of data propagation
         */
        intStopPropagateDataAfter = par("stopPropagationAfter");
        /*
         * To determine whether adaptive streetlighting is in-use
         * This parameter is used to turn the streetlight's brightness level to 100% when motorist is detected
         */
        //isAdaptiveScheme = par("isAdaptiveScheme").boolValue();
        //isUtilityTest = par("isUtilityTest");
        dblDefaultDimPercentage = par("defaultDimPercentage").doubleValue();
        dblDefaultDimPercentage = (dblDefaultDimPercentage/100);
        if(dblDefaultDimPercentage > 1)
        {
            opp_error("StreetlightApplLayer::initialize: defaultDimPercentage cannot more than 100.  Check omnet.ini configuration file!!!");
        }
//        if(isAdaptiveScheme && (dblDefaultDimPercentage > 0))
//        {
//            opp_error("StreetlightApplLayer::initialize: Simulation cannot have both isAdaptiveScheme is true and dblDefaultDimPercentage > 0.  Check omnet.ini configuration file!!!");
//        }
        /*
         * To specify the average streetlight's beam pattern width
         */
        dblAverageLightSpan = par("dblAverageLightSpan").doubleValue();
        /*
         * To specify type of road users is within the sensing range
         */
        isMotoristInRange = isPedestrianInRange = isCyclistInRange = false;
        /*
         * To specify the status propagation time
         */
        dblStatusPropagationTime = (1/par("statusPropagationTime").doubleValue());

        //isCommEnable = par("isCommEnable").boolValue();
        isGeneratePacket = par("isGeneratePacket").boolValue();
        simulation.getSystemModule()->subscribe(mobilityStateChangedSignal,this);

//        noMobileNodeSignal = registerSignal("noMobileNode");
//        simulation.getSystemModule()->subscribe(noMobileNodeSignal,this);

        computeStreetlightUtilitySignal = registerSignal("computeStreetlightUtility");

        totalLamppostSignal = registerSignal("totalLamppost");
        simulation.getSystemModule()->subscribe(totalLamppostSignal,this);

        /*
         * 27/06/2013 LSP
         * To trigger the start of the Traffic simulation
         */
        triggerTrafficModelSignal = registerSignal("triggerTrafficModel");
        simulation.getSystemModule()->subscribe(triggerTrafficModelSignal,this);
        /*
         * To check the latest streetlight operation.
         */
        msgStreetlightStatus = new cMessage("msgStreetlightStatus");
        msgPropagateStreetlightOppStatus_timer = new cMessage("msgPropagateStreetlightOppStatus_timer");
        msgStreetlightOppDelay_timer = new cMessage("msgStreetlightOppDelay_timer");
        msgStreetlightUtility_timer = new cMessage("msgStreetlightUtility_timer");

        dblTrafficSamplingRate = 1/par("trafficSamplingRate").doubleValue();
        msgTrafficSamplingRate_timer = new cMessage("msgTrafficSamplingRate_timer");

        msgWaitForApplAckTimer_timer = new cMessage("msgWaitForApplAckTimer_timer");
        dblWaitForApplAckDuration = par("WaitForApplAckDuration").doubleValue();
        dblNextAckExpireTime = 0;

        msgStopPropagateStreetlightOppStatus_timer = new cMessage("msgStopPropagateStreetlightOppStatus_timer");

        intOperateStartHour = par("operateStartHour");

        intOperationMonth = par("operationMonth");
        if(intOperationMonth < 1 || intOperationMonth > 12)
           error("StreetlightApplLayer::initialize: Invalid month found. Please check the omnet.ini setting");

        std::string strLightingScheme = par("lighting_scheme").stdstringValue();

        cVecRoadUserWithVicinity.setName("RoadUserIdPasses");
        cVecStreetlightOnOFFTime.setName("StreetLightOnOffTime");

        if(strcmp(strLightingScheme.c_str(), "adaptive") == 0)
        {
            intLightingScheme = ADAPTIVE;
            currentOperationStatus = LAMP_STATUS_OFF;
            /* record the initial OFF time */
            cVecStreetlightOnOFFTime.recordWithTimestamp(simTime(), 0.0);
        }
        else if(strcmp(strLightingScheme.c_str(), "adaptive_ideal") == 0)
        {
            intLightingScheme = ADAPTIVE_IDEAL;
            currentOperationStatus = LAMP_STATUS_OFF;
            /* record the initial OFF time */
            cVecStreetlightOnOFFTime.recordWithTimestamp(simTime(), 0.0);
        }
        else if(strcmp(strLightingScheme.c_str(), "time_based") == 0)
        {
            intLightingScheme = TIME_BASED;
            currentOperationStatus = LAMP_STATUS_ON;
            /* record the initial OFF time */
            cVecStreetlightOnOFFTime.recordWithTimestamp(simTime(), 0.0);
        }
        else if(strcmp(strLightingScheme.c_str(), "multi_sensor") == 0)
        {
            intLightingScheme = MULTI_SENSOR;
            currentOperationStatus = LAMP_STATUS_ON_40;
            /* record the initial OFF time */
            cVecStreetlightOnOFFTime.recordWithTimestamp(simTime(), 0.4);
        }
        else if(strcmp(strLightingScheme.c_str(), "zoning") == 0)
        {
            intLightingScheme = ZONING;
            currentOperationStatus = LAMP_STATUS_OFF;
            /* record the initial OFF time */
            cVecStreetlightOnOFFTime.recordWithTimestamp(simTime(), 0.0);
        }
        else if(strcmp(strLightingScheme.c_str(), "zoning_with_delay_pedestrian_only") == 0)
        {
            intLightingScheme = ZONING_WITH_DELAY_PEDESTRIAN_ONLY;
            currentOperationStatus = LAMP_STATUS_OFF;
            /* record the initial OFF time */
            cVecStreetlightOnOFFTime.recordWithTimestamp(simTime(), 0.0);
        }
        else if(strcmp(strLightingScheme.c_str(), "zoning_with_delay_all_roadusers") == 0)
        {
            intLightingScheme = ZONING_WITH_DELAY_ALL_ROAD_USERS;
            currentOperationStatus = LAMP_STATUS_OFF;
            /* record the initial OFF time */
            cVecStreetlightOnOFFTime.recordWithTimestamp(simTime(), 0.0);
        }
        else
            error("StreetlightApplLayer::initialize: Invalid lighting scheme is found.  Please check the omnet.ini setting");

        dblStreetlightOperationDelay = 0.0;
        dblDebugDelay = 0.0;
        dblCurrentStreetlightBrightnessLevel = 0.0;

        isSensingCompleted = false;
        isSensingPktReceived = false;
        isTrafficDetected = false;
        isSensorStateChange = false;
        /*
         * Used to receive signal containing total lamppost in the simulation.
         */
        totalLamppost = -1;


        currentDelayModeScr =  LAddress::L3Type(myApplAddr());
        currentRelayModeScrAddr = LAddress::L3Type(myApplAddr());

        ptrStreetlightMobility  = FindModule<StreetlightMobilityV2*>::findSubModule(const_cast<cModule*>(getParentModule()));
        ptrParentEnergyUsage = FindModule<EnergyUsage*>::findSubModule(const_cast<cModule*>(getParentModule()));

        msgNeighbourDiscovery_timer = new cMessage("neighbour-discovery-timer", NEIGHBOUR_DISCOVERY);

        if(intLightingScheme == ADAPTIVE)
            startTimer(TIMER_STREETLIGHT_NETW_DISCOVERY);

        intRoadId = -1;
        boolIsAtJunction = false;

        SDRoadUserDetectedByLocalNode = new SensorData();
        SDTempRoadUserDetectedByLocalNode = new SensorData();
        SDRoadUserDelay = new SensorData();
        dblTimeRoadUserDetectedByLocalNode = 0;
        SDRoadUserDetectedByNeighbourNode = new SensorData();
        SDForPropagation = new SensorData();
        SDNoRoadUser = new SensorData();
        dataReturn = new SensorData();
        sensing = new SensorData();
        SDReturnAck = new SensorData();
        SDRetransmission = new SensorData();
        SDtemp = new SensorData();

        dblSendPacketPeriod = dblrand();

        oppStatusBasedOnWhichLamp = myApplAddr();

        tDistToNeighbourByHop.insert(make_pair(myApplAddr(), 0));
        tNeighbourGeoAddr.insert(make_pair(myApplAddr(),ptrStreetlightMobility->getCurrentPosition()));

//        if(!isAdaptiveScheme && dblDefaultDimPercentage > 0 && !isGeneratePacket)
//        {
//               dblCurrentStreetlightBrightnessLevel = ptrParentEnergyUsage->updateEnergyUsageByDefault(dblDefaultDimPercentage);
//        }
        dataSeqNum = 0;
    }
}

StreetlightApplLayer::~StreetlightApplLayer() {
    cancelAndDelete(msgStreetlightStatus);
    //cancelAndDelete(msgGodMode);
    cancelAndDelete(msgNeighbourDiscovery_timer);
    cancelAndDelete(msgPropagateStreetlightOppStatus_timer);
    cancelAndDelete(msgStreetlightOppDelay_timer);
    cancelAndDelete(msgStreetlightUtility_timer);
    cancelAndDelete(msgWaitForApplAckTimer_timer);
    cancelAndDelete(msgStopPropagateStreetlightOppStatus_timer);
    cancelAndDelete(msgTrafficSamplingRate_timer);

    for (tNeighbourStatusUpdate::iterator pos = tNeighbourLastUpdatePerNode.begin(); pos != tNeighbourLastUpdatePerNode.end(); pos++)
    {
       delete pos->second;
    }
}

StreetlightApplLayer::streetlightOperationStatus StreetlightApplLayer::getActiveDelayNeighbourStatus(int NeighbourID)
{
    tGenericNeighbourStreetlightTable::iterator pos;
    pos = tNeighbourOperationStatus.find(NeighbourID);
    if(pos != tNeighbourOperationStatus.end())
    {
        return (StreetlightApplLayer::streetlightOperationStatus)pos->second;
    }
    return (StreetlightApplLayer::streetlightOperationStatus)-1;
}

void StreetlightApplLayer::handleLowerControl(cMessage *msg) {

}

double StreetlightApplLayer::getActiveDelayNeighbourBrightnessLevel(int NeighbourID)
{
    tGenericNeighbourStreetlightTable::iterator pos;
    pos = tNeighbourBrightnessLevel.find(NeighbourID);
    if(pos != tNeighbourOperationStatus.end())
    {
        return pos->second;
    }
    return 0.0;
}

SensorData* StreetlightApplLayer::getNeigbourOppStatus()
{
    SensorData* temp = new SensorData();
    temp->dataOriginateFrom = -1;
    dataReturn->reset();

    tGenericNeighbourStreetlightTable::iterator posUserType;
    tGenericNeighbourStreetlightTable::iterator posOppStatus;
    tGenericNeighbourStreetlightTable::iterator posOppStatusValidity;
    tGenericNeighbourStreetlightTable::iterator posSorting, posReverse;

    std::map<double, LAddress::L3Type> tReverseDistToNeighbour;
    double dblDistToNeighbour = -1;
    double dblMaxDimPercentage = 0;

    //For sorting based on distance to neighbour
   for (posSorting = tDistToNeighbour.begin(); posSorting != tDistToNeighbour.end(); posSorting++){
       tReverseDistToNeighbour.insert(make_pair(posSorting->second,posSorting->first));
   }

   /*For debugging only*/
//   for(posReverse = tReverseDistToNeighbour.begin(); posReverse != tReverseDistToNeighbour.end(); posReverse++)
//   {
//       ev<<"StreetlightApplLayer::getNeigbourOppStatus : lamp["<<getParentModule()->getIndex()<<"] at time : "<<simTime().dbl()
//              <<" ("<<posReverse->second <<","<<posReverse->first<<") ,"
//              <<" Packet timestamp : " << (tNeighbourLastUpdate.find(posReverse->second))->second
//              <<", Received : " << tNeighbourDelay.find(posReverse->second)->second
//              <<endl;
//   }

   /*
    * Check whether the source of LAMP_STATUS_ON_BY_RELAY is still in LAMP_STATUS_ON_BY_SENSOR or LAMP_STATUS_ON_BY_DELAY
    * if NOT the look for next
    */
   for(posReverse = tNeighbourOperationStatus.begin(); posReverse != tNeighbourOperationStatus.end(); posReverse++)
   {
       //check the neighbour operation status
       posOppStatus = tNeighbourOperationStatus.find(posReverse->first);
       posOppStatusValidity = tNeighbourOperationStatusValidity.find(posReverse->first);

       if(posOppStatus == tNeighbourOperationStatus.end())
           error("StreetlightApplLayer::getBrightnessLevelBasedOnSensingPacket :tNeighbourOperationStatus is empty");

       if((posOppStatus->second == LAMP_STATUS_ON_BY_SENSE
               || (posOppStatus->second == LAMP_STATUS_ON_BY_DELAY && simTime().dbl() < posOppStatusValidity->second))
               && posReverse->first != myApplAddr())
       {

           dblDistToNeighbour = tDistToNeighbour.find(posReverse->first)->second;
           temp->dataOriginateFrom = posReverse->first;

           posUserType = tNeighbourOperationUserTypeMotorist.find(posReverse->first);

           if(posUserType == tNeighbourOperationUserTypeMotorist.end())
               error("StreetlightApplLayer::getBrightnessLevelBasedOnSensingPacket : Missing operation user type");

           if(posUserType->second == MOTORIST)
           {
               temp->isMotoristInRange = true;
               temp->dblDistMotorist = dblDistToNeighbour;
               temp->dblSpeedMotorist = (tNeighbourOperationUserSpeedMotorist.find(posReverse->first))->second;
           }

           posUserType = tNeighbourOperationUserTypeCyclist.find(posReverse->first);
           if(posUserType == tNeighbourOperationUserTypeCyclist.end())
              error("StreetlightApplLayer::getBrightnessLevelBasedOnSensingPacket : Missing operation user type");
           if(posUserType->second == CYCLIST)
           {
               temp->isCyclistInRange = true;
               temp->dblDistCyclist = dblDistToNeighbour;
               temp->dblSpeedCyclist = (tNeighbourOperationUserSpeedCyclist.find(posReverse->first))->second;
           }

           posUserType = tNeighbourOperationUserTypePedestrian.find(posReverse->first);
           if(posUserType == tNeighbourOperationUserTypePedestrian.end())
               error("StreetlightApplLayer::getBrightnessLevelBasedOnSensingPacket : Missing operation user type");

           if(posUserType->second == PEDESTRIAN)
           {
               temp->isPedestrianInRange = true;
               //assuming the shortest distance is distance to neighbour - sensing radius.
               temp->dblDistPedestrian = dblDistToNeighbour;
               temp->dblSpeedPedestrian = (tNeighbourOperationUserSpeedPedestrian.find(posReverse->first))->second;
           }

           temp->geoAddrLamppost = (tNeighbourGeoAddr.find(posReverse->first))->second;
           temp->intOperationStatus = posOppStatus->second;
           temp->dblBrightnessLevel = (tNeighbourBrightnessLevel.find(posReverse->first))->second;

           int brightnessIndex = 0;
           int distRatio = (int) (floor(dblDistToNeighbour/30.0));
           double dblTempDimPercentageMotorist = 0;
           double dblTempDimPercentagePedestrian = 0;

           if(temp->isMotoristInRange || temp->isCyclistInRange)
           {
               if(distRatio <= 4)
                   brightnessIndex = 0;
               else if ( distRatio > 4)
                   brightnessIndex = 1;
               dblTempDimPercentageMotorist = 1 - brightnessIndex;
           }
           else if (temp->isPedestrianInRange)
           {
               if(distRatio == 0)
                   brightnessIndex = 0;
               else if ( distRatio > 0 && distRatio <= 5)
                   brightnessIndex = (distRatio -1);
               else if (distRatio > 5)
                   brightnessIndex = 5;
               dblTempDimPercentagePedestrian = 1 - 0.2* brightnessIndex;
           }

           if(dblMaxDimPercentage < std::max(dblTempDimPercentageMotorist,dblTempDimPercentagePedestrian))
           {
               dblMaxDimPercentage = std::max(dblTempDimPercentageMotorist,dblTempDimPercentagePedestrian);
               dataReturn->isCyclistInRange = temp->isCyclistInRange;
               dataReturn->dblDistCyclist = temp->dblDistCyclist;
               dataReturn->dblSpeedCyclist = temp->dblSpeedCyclist;

               dataReturn->isPedestrianInRange = temp->isPedestrianInRange;
               dataReturn->dblDistPedestrian = temp->dblDistPedestrian;
               dataReturn->dblSpeedPedestrian = temp->dblSpeedPedestrian;

               dataReturn->isMotoristInRange = temp->isMotoristInRange;
               dataReturn->dblDistMotorist = temp->dblDistMotorist;
               dataReturn->dblSpeedMotorist = temp->dblSpeedMotorist;


               dataReturn->geoAddrLamppost =temp->geoAddrLamppost;
               dataReturn->intOperationStatus = temp->intOperationStatus;
               dataReturn->dblBrightnessLevel = temp->dblBrightnessLevel;
               dataReturn->geoAddrMotorist = temp->geoAddrMotorist;
               dataReturn->geoAddrPedestrainOrCyclist = temp->geoAddrPedestrainOrCyclist;

               dataReturn->dataOriginateFrom = temp->dataOriginateFrom;
           }
       }
   }
   delete temp;
   return dataReturn;
}

//int StreetlightApplLayer::countNeighbourByHopNumber(int hop)
//{
//    tGenericNeighbourStreetlightTable::iterator itHop;
//    int nbNodeWithinOneHop = 0;
//    for(itHop = tDistToNeighbourByHop.begin(); itHop !=  tDistToNeighbourByHop.end(); itHop++ )
//    {
//        if(itHop->second == hop)
//            nbNodeWithinOneHop++;
//    }
//    return nbNodeWithinOneHop;
//}

//int StreetlightApplLayer::isExpectedAck(int hop, LAddress::L3Type srcAddr)
//{
//    tGenericNeighbourStreetlightTable::iterator itHop;
//    int nbNodeWithinOneHop = 0;
//    for(itHop = tDistToNeighbourByHop.begin(); itHop !=  tDistToNeighbourByHop.end(); itHop++ )
//       {
//           if(itHop->second == hop)
//           {
//               if(tNeighbourGeoAddr.find(srcAddr) == tNeighbourGeoAddr.end())
//                   opp_warning("StreetlightApplLayer::isExpectedAck: GeoAddr cannot be found !");
//               double tempDist = EuclideanDist(tNeighbourGeoAddr.find(srcAddr)->second, tNeighbourGeoAddr.find(itHop->first)->second);
//               if(tempDist < 150)
//                   nbNodeWithinOneHop++;
//           }
//       }
//    return nbNodeWithinOneHop;
//}

double StreetlightApplLayer::getOneHopNeighbourV2()
{
    double maxHopDistance = 0;
    for(tGenericNeighbourStreetlightTable::iterator itHop = tDistToNeighbourByHop.begin(); itHop !=  tDistToNeighbourByHop.end(); itHop++ )
    {
        if(itHop->second == 1)
        {
            if(tNeighbourGeoAddr.find(itHop->first) != tNeighbourGeoAddr.end())
            {
                if(maxHopDistance < EuclideanDist(tNeighbourGeoAddr.find(itHop->first)->second, ptrStreetlightMobility->getCurrentPosition()))
                    maxHopDistance = EuclideanDist(tNeighbourGeoAddr.find(itHop->first)->second, ptrStreetlightMobility->getCurrentPosition());
            }
            else
            {
                if(maxHopDistance < dblAverageLightSpan)
                    maxHopDistance = dblAverageLightSpan;
            }
        }
    }
    return maxHopDistance;
}
//double StreetlightApplLayer::getOneHopNeighbour()
//{
//    double dblDistOneHopNeighbourUpperLeft = 99999;
//    double dblDistOneHopNeighbourUpperRight = 99999;
//    double dblDistOneHopNeighbourLowerLeft = 99999;
//    double dblDistOneHopNeighbourLowerRight = 99999;
//    double dblDistOneHopNeighbour = -1;
//
//    tGenericNeighbourStreetlightTable::iterator pos;
//
//    for(pos = tNeighbourUpperLeftRegion.begin(); pos != tNeighbourUpperLeftRegion.end(); pos++)
//    {
//        if(pos->second < dblDistOneHopNeighbourUpperLeft)
//            dblDistOneHopNeighbourUpperLeft = pos->second;
//    }
//    for(pos = tNeighbourUpperRightRegion.begin(); pos != tNeighbourUpperRightRegion.end(); pos++)
//    {
//        if(pos->second < dblDistOneHopNeighbourUpperRight)
//            dblDistOneHopNeighbourUpperRight = pos->second;
//    }
//    for(pos = tNeighbourLowerLeftRegion.begin(); pos != tNeighbourLowerLeftRegion.end(); pos++)
//    {
//        if(pos->second < dblDistOneHopNeighbourLowerLeft)
//            dblDistOneHopNeighbourLowerLeft = pos->second;
//    }
//    for(pos = tNeighbourLowerRightRegion.begin(); pos != tNeighbourLowerRightRegion.end(); pos++)
//    {
//
//        if(pos->second < dblDistOneHopNeighbourLowerRight)
//        {
//            dblDistOneHopNeighbourLowerRight = pos->second;
//        }
//    }
//        //find the furthest neighbour from these left and right region
//        if (dblDistOneHopNeighbourUpperLeft != 99999)
//        {
//            if (dblDistOneHopNeighbour < dblDistOneHopNeighbourUpperLeft)
//                dblDistOneHopNeighbour = dblDistOneHopNeighbourUpperLeft;
//
//        }
//        if (dblDistOneHopNeighbourLowerLeft != 99999)
//        {
//            if (dblDistOneHopNeighbour > dblDistOneHopNeighbourLowerLeft)
//                dblDistOneHopNeighbour = dblDistOneHopNeighbourLowerLeft;
//        }
//
//        double temp = -1;
//
//        if (dblDistOneHopNeighbourLowerRight != 99999)
//        {
//            if(temp < dblDistOneHopNeighbourLowerRight)
//                temp = dblDistOneHopNeighbourLowerRight;
//       }
//       if(dblDistOneHopNeighbourUpperRight != 99999)
//       {
//                if(temp > dblDistOneHopNeighbourUpperRight)
//                    temp = dblDistOneHopNeighbourUpperRight;
//        }
//
//       if(temp > dblDistOneHopNeighbour)
//           dblDistOneHopNeighbour = temp;
//
//    ev<<"StreetlightApplLayer::getOneHopNeighbour ["<<myApplAddr()<<"]: dblDistOneHopNeighbour : "<<dblDistOneHopNeighbour <<endl;
//    if(dblDistOneHopNeighbour > 0 )
//    {
//        if ((dblDistOneHopNeighbour - 2*dblMaxLampPoleSensingDistance) < 0)
//            dblDistOneHopNeighbour = 0.001;
//        else
//            dblDistOneHopNeighbour = dblDistOneHopNeighbour - 2*dblMaxLampPoleSensingDistance;
//    }
//
//    if (dblDistOneHopNeighbour < 0) //cannot find any
//        return dblAverageLightSpan;
//    else
//        return dblDistOneHopNeighbour;
//}

void StreetlightApplLayer::handleSelfMsg(cMessage *msg)
{

    tGenericNeighbourStreetlightTable::iterator pos, tempPos;

    if (msg ==  msgNeighbourDiscovery_timer)
    {
        SensorData* temp = new SensorData();
        temp->geoAddrLamppost = ptrStreetlightMobility->getCurrentPosition();
        temp->dataOriginateFrom = LAddress::L3Type(myApplAddr());
        sendRouteDiscoveryMessage(temp);
        delete temp;
    }
    else if(msg == msgStreetlightOppDelay_timer)
    {
        /*
         * after the delay timer is triggered, the node need to check for the neighbouring node status
         * and update its operation accordingly
         */
        SDRoadUserDetectedByNeighbourNode->reset();
        updateStreetlightOppStatus(SDRoadUserDetectedByNeighbourNode, SDRoadUserDetectedByNeighbourNode->dataOriginateFrom, "by handleSelfMsg:msgStreetlightOppDelay_timer: node " +static_cast<std::ostringstream*>( &(std::ostringstream() << SDRoadUserDetectedByNeighbourNode->dataOriginateFrom))->str());
    }
    else if (msg == msgStopPropagateStreetlightOppStatus_timer)
    {
        if(msgPropagateStreetlightOppStatus_timer->isScheduled())
            cancelEvent(msgPropagateStreetlightOppStatus_timer);
    }
    else if (msg== msgPropagateStreetlightOppStatus_timer)
    {
        switch(currentOperationStatus)
        {
            case LAMP_STATUS_ON_BY_SENSE:
                generateSensingData(SDRoadUserDetectedByLocalNode,LAddress::L3BROADCAST, LAddress::L3BROADCAST, DATA_MSG,"by samplingTrafficInformation");
                break;
            //case LAMP_STATUS_ON_BY_DELAY:
            default:
            {
                generateSensingData(SDRoadUserDelay,LAddress::L3BROADCAST, LAddress::L3BROADCAST, DATA_MSG,"by samplingTrafficInformation");
            }
                break;
        }
        startTimer(TIMER_STREETLIGHT_PROPAGATE_DATA);
    }
    else if(msg == msgWaitForApplAckTimer_timer)
    {
        SDRetransmission->reset();
        SDRetransmission->dataOriginateFrom = runAckTimerForWhichData;
        SDRetransmission->dataTimeStamp = tNeighbourLastUpdate.find(runAckTimerForWhichData)->second;
        SDRetransmission->dblSpeedCyclist =tNeighbourOperationUserSpeedCyclist.find(runAckTimerForWhichData)->second;
        SDRetransmission->dblSpeedMotorist = tNeighbourOperationUserSpeedMotorist.find(runAckTimerForWhichData)->second;
        SDRetransmission->dblSpeedPedestrian= tNeighbourOperationUserSpeedPedestrian.find(runAckTimerForWhichData)->second;
        SDRetransmission->geoAddrLamppost =tNeighbourGeoAddr.find(runAckTimerForWhichData)->second;
        SDRetransmission->intOperationStatus =tNeighbourOperationStatus.find(runAckTimerForWhichData)->second;
        SDRetransmission->isCyclistInRange = tNeighbourOperationUserTypeCyclist.find(runAckTimerForWhichData)->second;
        SDRetransmission->isMotoristInRange = tNeighbourOperationUserTypeMotorist.find(runAckTimerForWhichData)->second;
        SDRetransmission->isPedestrianInRange = tNeighbourOperationUserTypePedestrian.find(runAckTimerForWhichData)->second;

        if(runAckTimerForWhichData == myApplAddr())
            updateStreetlightOppStatus(SDRoadUserDetectedByLocalNode, myApplAddr(), "by samplingTrafficInformation");
        else
            generateSensingData(SDRetransmission,LAddress::L3BROADCAST, LAddress::L3BROADCAST, DATA_MSG,"by TimeOut");

        collectAckTimerList(runAckTimerForWhichData,simTime().dbl() + dblWaitForApplAckDuration, "by handleLowerMsg");
        manageAckTimer();
    }
    else if(msg == msgTrafficSamplingRate_timer)
    {
        switch(intLightingScheme)
        {
            case ADAPTIVE:
                samplingTrafficInformationForAdaptiveScheme();
                break;
            case TIME_BASED:
                samplingTrafficInformationForTimeBasedScheme();
                break;
            case ZONING:
                samplingTrafficInformationForZoningScheme();
                break;
            case MULTI_SENSOR:
                samplingTrafficInformationForMultiSensorScheme();
                break;
            case HARDCODED_DIMMER:
                samplingTrafficInformationForHardcodedDimmer();
                break;
            case ADAPTIVE_IDEAL:
                samplingTrafficInformationForAdaptiveIdealScheme();
                break;
            case ZONING_WITH_DELAY_PEDESTRIAN_ONLY:
                samplingTrafficInformationForZoningPedestrianAndGPS_TTFF_Scheme();
                break;
            case ZONING_WITH_DELAY_ALL_ROAD_USERS:
                samplingTrafficInformationForZoningAllRoadUserAndGPS_TTFF_Scheme();
                break;
        }
        startTimer(TIMER_TRAFFIC_SAMPLING);
    }
    else
        error("StreetlightApplLayer::handleSelfMsg:Undefined Self Message : %s",msg->getName());
}

void StreetlightApplLayer::countRoadUser(int roadUserType, int roadUserId)
{
   if(mapCountRoadUser.find(roadUserId) == mapCountRoadUser.end())
   {
       mapCountRoadUser.insert(make_pair(roadUserId, roadUserType));
       cVecRoadUserWithVicinity.record(roadUserId);
   }
}

void StreetlightApplLayer::updateStreetlightStatusLatencyPerNode(LAddress::L3Type srcId)
{
    tNeighbourStatusUpdate::iterator pos = tNeighbourLastUpdatePerNode.find(srcId);
    if(pos == tNeighbourLastUpdatePerNode.end())
    {
        std::string strNodeId= "node[" + static_cast<std::ostringstream*>( &(std::ostringstream() << srcId))->str() + "]_DelayUpdate";
        cOutVector * statusUpdateLatency = new cOutVector(strNodeId.c_str());
        statusUpdateLatency->record(0.0);
        updateDataPacketArrivalTime(srcId);
        tNeighbourLastUpdatePerNode.insert(make_pair(srcId, statusUpdateLatency));
    }
    else
    {
        pos->second->record(simTime().dbl() - tNeighbourLatency.find(srcId)->second);
        updateDataPacketArrivalTime(srcId);
    }
}
//void StreetlightApplLayer::collectStreetlightApplDataPropagationLatencyPerNode(StreetlightApplPkt* ptk)
//{
//    if(tAverageLatencyApplLayer.find(ptk->getPktOriginAddr()) == tAverageLatencyApplLayer.end())
//    {
//        tAverageLatencyApplLayer.insert(make_pair(ptk->getPktOriginAddr(),simTime().dbl()-ptk->getTimestamp().dbl()));
//        tTotalApplDataReceived.insert(make_pair(ptk->getPktOriginAddr(), 1));
//    }
//    else
//    {
//        tAverageLatencyApplLayer.find(ptk->getPktOriginAddr())->second +=  (simTime().dbl()-ptk->getTimestamp().dbl());
//        tTotalApplDataReceived.find(ptk->getPktOriginAddr())->second++;
//    }
//}
void StreetlightApplLayer::recordApplDataReceivedPerNode()
{
    tGenericNeighbourStreetlightTable::iterator it;
    std::string strNodeId;
    for(it = tTotalApplDataReceived.begin(); it != tTotalApplDataReceived.end(); it++)
    {
        strNodeId= "node[" + static_cast<std::ostringstream*>( &(std::ostringstream() << it->first))->str() + "]_TotalDataPacketReceived";
        recordScalar(strNodeId.c_str(),it->second);
        strNodeId= "node[" + static_cast<std::ostringstream*>( &(std::ostringstream() << it->first))->str() + "]_AverageApplLatency";
        recordScalar(strNodeId.c_str(),(tAverageLatencyApplLayer.find(it->first)->second/it->second));
    }
}

void StreetlightApplLayer::recordDistanceToNeighbour()
{
    tGenericNeighbourStreetlightGeoAddr::iterator it;
    std::string strNodeId;
    for(it = tNeighbourGeoAddr.begin(); it != tNeighbourGeoAddr.end(); it++)
    {
        strNodeId= "Distance_to_node[" + static_cast<std::ostringstream*>( &(std::ostringstream() << it->first))->str() + "]";
        recordScalar(strNodeId.c_str(),EuclideanDist(it->second, ptrStreetlightMobility->getCurrentPosition()));
    }
    tGenericNeighbourStreetlightTable::iterator itHop;
    for (itHop = tDistToNeighbourByHop.begin(); itHop != tDistToNeighbourByHop.end(); itHop++)
    {
        strNodeId= "Hop_to_node[" + static_cast<std::ostringstream*>( &(std::ostringstream() << itHop->first))->str() + "]";
        recordScalar(strNodeId.c_str(),itHop->second);
    }
}
void StreetlightApplLayer::updateStreetlightOppStatus(SensorData* sensedTrafficData, LAddress::L3Type whichNode, std::string strInfo)
{
    oppStatusBasedOnWhichLamp = whichNode;
    switch(currentOperationStatus)
    {
        case LAMP_STATUS_OFF:
        {
            if(isTrafficDetected)
            {
                setApplNodeID("ON : " + strInfo);
                sensedTrafficData->intOperationStatus = LAMP_STATUS_ON_BY_SENSE;
                currentOperationStatus = LAMP_STATUS_ON_BY_SENSE;

                /* record the ON time */
                cVecStreetlightOnOFFTime.recordWithTimestamp(simTime(), 1.0);

                /* Adjust the brightness level*/
                updateStreetlightEnergyAndBrightnessLevel_V2(sensedTrafficData);

                /*
                 * Broadcast the traffic info.
                 */
                if(msgPropagateStreetlightOppStatus_timer->isScheduled())
                    cancelEvent(msgPropagateStreetlightOppStatus_timer);
                generateSensingData(sensedTrafficData,LAddress::L3BROADCAST, LAddress::L3BROADCAST, DATA_MSG,"by samplingTrafficInformation");
                startTimer(TIMER_STREETLIGHT_PROPAGATE_DATA);
            }
            else
            {
                /* check the table for any active neighbour then adjust the brightness level*/
                updateStreetlightEnergyAndBrightnessLevel_V2(getNeigbourOppStatus());

                int tempDataOriginateFrom = getNeigbourOppStatus()->dataOriginateFrom;
                //if (getNeigbourOppStatus()->dataOriginateFrom >= 0)
                if (tempDataOriginateFrom >= 0)
                {
                    setApplNodeID("RELAY : " + strInfo);
                    currentOperationStatus = LAMP_STATUS_ON_BY_RELAY;

                    /* record the ON time */
                    cVecStreetlightOnOFFTime.recordWithTimestamp(simTime(), 1.0);
                }
                else
                {
                    /*
                     * if non of the neighbours detect the traffic under STATUS_OFF then
                     * do nothing
                     */
                }
            }
            break;
        }
        case LAMP_STATUS_ON_BY_SENSE:
        {
            if(!isTrafficDetected)
            {
                /*
                 * For streetlight delay timer, average speed is assumed.  motorist speed = 10 miles per hour is assumed.
                 */
                setApplNodeID("DELAY : " + strInfo);
                currentOperationStatus = LAMP_STATUS_ON_BY_DELAY;

                computeStreetlightOppDelayTime(SDRoadUserDelay);
                SDRoadUserDelay->dataValidity = simTime().dbl()+dblStreetlightOperationDelay;
                startTimer(TIMER_STREETLIGHT_OPP_DELAY);

                /*
                 * Broadcast the traffic info.
                 */
                if(msgPropagateStreetlightOppStatus_timer->isScheduled())
                    cancelEvent(msgPropagateStreetlightOppStatus_timer);

                generateSensingData(SDRoadUserDelay,LAddress::L3BROADCAST, LAddress::L3BROADCAST, DATA_MSG,"by samplingTrafficInformation");
                startTimer(TIMER_STREETLIGHT_PROPAGATE_DATA);
            }
            else
            {
                /*
                 * if traffic is detected under currentOpperationStatus = ON_BY_SENSE
                 * do nothing!
                 */
            }
            break;
        }
        case LAMP_STATUS_ON_BY_DELAY:
        {
            if(isTrafficDetected)
            {
                sensedTrafficData->intOperationStatus = LAMP_STATUS_ON_BY_SENSE;
                setApplNodeID("ON : " + strInfo);
                currentOperationStatus = LAMP_STATUS_ON_BY_SENSE;
                if(msgStreetlightOppDelay_timer -> isScheduled())
                    cancelEvent(msgStreetlightOppDelay_timer);
                /*
                 * Broadcast the traffic info.
                 */
                if(msgPropagateStreetlightOppStatus_timer->isScheduled())
                    cancelEvent(msgPropagateStreetlightOppStatus_timer);
                generateSensingData(sensedTrafficData,LAddress::L3BROADCAST, LAddress::L3BROADCAST, DATA_MSG,"by samplingTrafficInformation");
                startTimer(TIMER_STREETLIGHT_PROPAGATE_DATA);
            }
            else
            {
                if(msgStreetlightOppDelay_timer->isScheduled())
                    return;
                /* check the table for any active neighbour then adjust the brightness level*/
                updateStreetlightEnergyAndBrightnessLevel_V2(getNeigbourOppStatus());

                if (getNeigbourOppStatus()->dataOriginateFrom >= 0)
                {
                    setApplNodeID("RELAY : " + strInfo);
                    currentOperationStatus = LAMP_STATUS_ON_BY_RELAY;
                }
                else
                {
                    setApplNodeID("OFF : " + strInfo);
                    /* record the OFF time */
                    cVecStreetlightOnOFFTime.recordWithTimestamp(simTime(), 0.0);
                    currentOperationStatus = LAMP_STATUS_OFF;
                }
            }
            break;
        }
        case LAMP_STATUS_ON_BY_RELAY:
        {
            if(isTrafficDetected)
            {
                sensedTrafficData->intOperationStatus = LAMP_STATUS_ON_BY_SENSE;
                setApplNodeID("ON : " + strInfo);
                currentOperationStatus = LAMP_STATUS_ON_BY_SENSE;

                /* adjust the brightness level*/
                updateStreetlightEnergyAndBrightnessLevel_V2(sensedTrafficData);

                /*
                 * Broadcast the traffic info.
                 */
                if(msgPropagateStreetlightOppStatus_timer->isScheduled())
                    cancelEvent(msgPropagateStreetlightOppStatus_timer);
                generateSensingData(sensedTrafficData,LAddress::L3BROADCAST, LAddress::L3BROADCAST, DATA_MSG,"by samplingTrafficInformation");
                startTimer(TIMER_STREETLIGHT_PROPAGATE_DATA);
            }
            else
            {
                /* check the table for any active neighbour then adjust the brightness level*/
                updateStreetlightEnergyAndBrightnessLevel_V2(getNeigbourOppStatus());

                int tempDataOriginateFrom = getNeigbourOppStatus()->dataOriginateFrom;
                if (tempDataOriginateFrom >= 0)
                {
                    setApplNodeID("RELAY : " + strInfo + "node[" + static_cast<std::ostringstream*>( &(std::ostringstream() << tempDataOriginateFrom ))->str() + "]");
                    currentOperationStatus = LAMP_STATUS_ON_BY_RELAY;
                }
                else
                {
                    setApplNodeID("OFF : " + strInfo);
                    /* record the OFF time */
                    cVecStreetlightOnOFFTime.recordWithTimestamp(simTime(), 0.0);
                    currentOperationStatus = LAMP_STATUS_OFF;
                }
            }
            break;
        }
        default:
            error("StreetlightApplLayer::updateStreetlightOppStatus: Unsupported operation state found!");
            break;
    }
    oppStatusBasedOnWhichLamp = whichNode;
}


void StreetlightApplLayer::handleReceivedSensorData(StreetlightApplPkt* receivedSensorDataInPacket, std::string strInfo)
{
    switch (currentOperationStatus)
    {
        case LAMP_STATUS_OFF:
        case LAMP_STATUS_ON_BY_RELAY:
            SDRoadUserDetectedByNeighbourNode = getNeigbourOppStatus();
            SDRoadUserDetectedByNeighbourNode->geoAddrLamppost = ptrStreetlightMobility->getCurrentPosition();
            if (SDRoadUserDetectedByNeighbourNode->dataOriginateFrom >= 0)
            {
                 SDRoadUserDetectedByNeighbourNode->intOperationStatus = LAMP_STATUS_ON_BY_RELAY;
                 updateStreetlightOppStatus(SDRoadUserDetectedByNeighbourNode, SDRoadUserDetectedByNeighbourNode->dataOriginateFrom , strInfo + " node "  + static_cast<std::ostringstream*>( &(std::ostringstream() << SDRoadUserDetectedByNeighbourNode->dataOriginateFrom))->str());
            }
            else //none of the neighbouring node is active -> everyone is turned off
            {
                SDRoadUserDetectedByNeighbourNode->dataOriginateFrom = LAddress::L3Type(myApplAddr());
                SDRoadUserDetectedByNeighbourNode->intOperationStatus = LAMP_STATUS_OFF;
                updateStreetlightOppStatus(SDRoadUserDetectedByNeighbourNode, myApplAddr(),  strInfo+ " node "  + static_cast<std::ostringstream*>( &(std::ostringstream() << SDRoadUserDetectedByNeighbourNode->dataOriginateFrom))->str());
            }
            break;
        default:
            break;
    }
}

double StreetlightApplLayer::getCurrentBrightnessLevel() const
{
    return dblCurrentStreetlightBrightnessLevel;
}

int StreetlightApplLayer::getCurrentOppStatus() const
{
    return currentOperationStatus;
}

void StreetlightApplLayer::computeStreetlightOppDelayTime(SensorData * data)
{
    //double temp = getOneHopNeighbour();
    double temp =(getOneHopNeighbourV2()- dblMaxLampPoleSensingDistance)/2;
    if (temp < 0 )
        temp = 0;

    //double temp = dblAverageLightSpan/2;
    if(data->isPedestrianInRange)
    {
        //assuming the slowest walking speed is 0.73 meter per seconds
        dblStreetlightOperationDelay =  (double)(temp/0.73) + 1.0;
    }
    if(data->isMotoristInRange ||  data->isCyclistInRange)
    {
        //assuming car is travelling at 10 miles per hours
        dblStreetlightOperationDelay = (double)(temp/4.5) + 1.0;
    }
}

void StreetlightApplLayer::startTimer(t_streetlight_timer timerType)
{
    switch(timerType)
    {
        case TIMER_STREETLIGHT_OPP_DELAY:
            if(dblStreetlightOperationDelay < 0)
                dblStreetlightOperationDelay = 0;
            scheduleAt(simTime()+ dblStreetlightOperationDelay, msgStreetlightOppDelay_timer);
            break;
        case TIMER_STREETLIGHT_PROPAGATE_DATA:
            switch(currentOperationStatus)
            {
                case LAMP_STATUS_ON_BY_SENSE:
                    if(msgStopPropagateStreetlightOppStatus_timer->isScheduled())
                        cancelEvent(msgStopPropagateStreetlightOppStatus_timer);
                    break;
                case  LAMP_STATUS_ON_BY_DELAY:
                    startTimer(TIMER_STREETLIGHT_STOP_PROPAGATE_DATA);
                    break;
            }
            scheduleAt(simTime() + dblStatusPropagationTime, msgPropagateStreetlightOppStatus_timer);
            break;
        case TIMER_STREETLIGHT_STOP_PROPAGATE_DATA:

            /* only last for 5 second*/
            if(!(msgStopPropagateStreetlightOppStatus_timer->isScheduled()))
            {
                if(intStopPropagateDataAfter > 0)
                {
                    dblTestStopPropagation = simTime().dbl();
                    scheduleAt(simTime()+intStopPropagateDataAfter, msgStopPropagateStreetlightOppStatus_timer);
                }
                else if(intStopPropagateDataAfter < 0)
                {
                    scheduleAt(simTime()+dblStreetlightOperationDelay, msgStopPropagateStreetlightOppStatus_timer);
                }
                else if(intStopPropagateDataAfter == 0)
                {
                    //never stop the propagation
                }
            }
            break;
        case TIMER_STREETLIGHT_NETW_DISCOVERY:
            scheduleAt(simTime(), msgNeighbourDiscovery_timer);
            break;
        case TIMER_STREETLIGHT_UTILITY:
            scheduleAt(simTime() + 0.5, msgStreetlightUtility_timer);
            break;
        case TIMER_TRAFFIC_SAMPLING:
            scheduleAt(simTime() + dblTrafficSamplingRate, msgTrafficSamplingRate_timer);
            break;
        case TIMER_WAIT_FOR_APPL_ACK:
            /* if not ACK timer is scheduled then schedule a new one
             * else need to keep track on next timer to be triggered.
             */
             //scheduleAt(simTime() + dblWaitForApplAckDuration, msgWaitForApplAckTimer_timer);
            scheduleAt(simTime() + dblNextAckExpireTime, msgWaitForApplAckTimer_timer);

            break;
        default:
            error("StreetlightApplLayer::startTimer: unknown timer type");
            break;
    }
}
void StreetlightApplLayer::samplingTrafficInformationForAdaptiveIdealScheme()
{
    SDTempRoadUserDetectedByLocalNode->reset();
    SDRoadUserDetectedByLocalNode->reset();

   //reset all the previouslly detected road users' status to 0


   myGlobalTraci = FindModule<SUMOTraCIScenarioManagerV2*>::findGlobalModule();
   mapObjHost = myGlobalTraci->getManagedHostsPointer();

   double dblTempMotorisSSD = 0.0, dblTempMotoristSpeed =0.0, dblTempCyclistOrPedestrianSpeed = 0.0;
   Coord tempGeoAddrMotorist, tempGeoAddrCyclistOrPedestrian;

   std::map<std::string, cModule*> :: const_iterator itr;
   for(itr = mapObjHost->begin() ; itr != mapObjHost->end(); ++itr)
   {
       const cModule* mod = (*itr).second;
       const SUMOTraCIMobilityV2* globalMobility = FindModule<SUMOTraCIMobilityV2*>::findSubModule(const_cast<cModule*>(mod));
       //distanceBetweenCar = sqrt((double)(pow((globalMobility->getCurrentPosition().x - ptrStreetlightMobility->getCurrentPosition().x),2)+ pow((globalMobility->getCurrentPosition().y-ptrStreetlightMobility->getCurrentPosition().y),2)));
       distBtwSensorAndRoadUser = sqrt((double)(pow((globalMobility->getCurrentPosition().x - ptrStreetlightMobility->getCurrentPosition().x),2)+ pow((globalMobility->getCurrentPosition().y-ptrStreetlightMobility->getCurrentPosition().y),2)));

       /*09/08/2012 - LSP For debugging
        * to display necessary information on distance sensing mode
        */
       /*
       ev << "Car: " << (*itr).first << " Position:(" <<  globalMobility->getCurrentPosition().x << ", "<< globalMobility->getCurrentPosition().y <<")" <<endl;
       ev<<"Pole Position:("<<move.getCurrentPosition().x<<","<<move.getCurrentPosition().y<<")"<<endl;
       ev<<"distance between them :"<< distanceBetweenCar<<endl;
       */

       //if(distanceBetweenCar <= dblMaxLampPoleSensingDistance ) //if MaxLampPoleSensingDistance = 17 m then sensing is in-use
       //if(distBtwSensorAndRoadUser <= dblMaxLampPoleSensingDistance)
       if(distBtwSensorAndRoadUser <= (150 + (dblAverageLightSpan/2)))
       {
           dblTimeRoadUserDetectedByLocalNode = simTime().dbl();

           if(!isObstacleBtwPoleAndCar(mod))
           {
               /* record the detected road user  */
               countRoadUser(globalMobility->getRoadUserType(), globalMobility->getParentModule()->getIndex());

               if(intLightingScheme == ADAPTIVE_IDEAL)
               {
                   if(globalMobility->getRoadUserType() == MOTORIST)
                   {
                       ptrMotoristMobility = globalMobility;
                       dblTempMotorisSSD = globalMobility->getSSD();
                       dblTempMotoristSpeed =globalMobility->getSpeed(),
                       tempGeoAddrMotorist = globalMobility->getCurrentPosition();
                       isMotoristInRange = true;

                       //LSP 13/08/2013
                       SDTempRoadUserDetectedByLocalNode->isMotoristInRange = isMotoristInRange;

                       if(SDTempRoadUserDetectedByLocalNode->dblDistMotorist < 0) //for the first entry
                       {
                           SDTempRoadUserDetectedByLocalNode->dblDistMotorist = distBtwSensorAndRoadUser;
                           SDTempRoadUserDetectedByLocalNode->dblMotoristSSD = dblTempMotorisSSD;
                            SDTempRoadUserDetectedByLocalNode->dblSpeedMotorist = dblTempMotoristSpeed;
                           SDTempRoadUserDetectedByLocalNode->geoAddrMotorist = tempGeoAddrMotorist;
                       }
                       else if(SDTempRoadUserDetectedByLocalNode->dblDistMotorist > distBtwSensorAndRoadUser) //for subsequent entry, only look for the nearest one
                       {
                           SDTempRoadUserDetectedByLocalNode->dblDistMotorist = distBtwSensorAndRoadUser;
                           SDTempRoadUserDetectedByLocalNode->dblMotoristSSD = dblTempMotorisSSD;
                           SDTempRoadUserDetectedByLocalNode->dblSpeedMotorist = dblTempMotoristSpeed;
                           SDTempRoadUserDetectedByLocalNode->geoAddrMotorist = tempGeoAddrMotorist;
                       }
                   }
                   else if(globalMobility->getRoadUserType() == PEDESTRIAN)
                   {
                       //minDistanceForPedestrianOrCyclist = distanceBetweenCar;
                       ptrCyclistOrPedestrianMobility = globalMobility;
                       dblTempCyclistOrPedestrianSpeed = globalMobility->getSpeed();
                       tempGeoAddrCyclistOrPedestrian = globalMobility->getCurrentPosition();
                       globalMobility->getRoadUserType() == PEDESTRIAN ? isPedestrianInRange = true : isCyclistInRange = true;

                       //LSP 13/08/2013
                       SDTempRoadUserDetectedByLocalNode->isPedestrianInRange = isPedestrianInRange;
                       if(SDTempRoadUserDetectedByLocalNode->dblDistPedestrian < 0 )
                       {
                           SDTempRoadUserDetectedByLocalNode->dblDistPedestrian = distBtwSensorAndRoadUser;
                           SDTempRoadUserDetectedByLocalNode->dblSpeedPedestrian = dblTempCyclistOrPedestrianSpeed;
                           SDTempRoadUserDetectedByLocalNode->geoAddrPedestrainOrCyclist = tempGeoAddrCyclistOrPedestrian;
                       }
                       else if(SDTempRoadUserDetectedByLocalNode->dblDistPedestrian > distBtwSensorAndRoadUser)
                       {
                           SDTempRoadUserDetectedByLocalNode->dblDistPedestrian = distBtwSensorAndRoadUser;
                           SDTempRoadUserDetectedByLocalNode->dblSpeedPedestrian = dblTempCyclistOrPedestrianSpeed;
                           SDTempRoadUserDetectedByLocalNode->geoAddrPedestrainOrCyclist = tempGeoAddrCyclistOrPedestrian;
                       }
                   }
               }
               else //for other lighting schemes
               {
                     error("StreetlightApplLayer::samplingTrafficInformation:: This function is used to evaluate lighting scheme other than adaptive_ideal!  Check the omnet.ini setting!");
               }
           }
       }
   }

   SDTempRoadUserDetectedByLocalNode->dataOriginateFrom = myApplAddr();
   if(SDTempRoadUserDetectedByLocalNode->isMotoristInRange || SDTempRoadUserDetectedByLocalNode->isPedestrianInRange || SDTempRoadUserDetectedByLocalNode->isCyclistInRange)
   {
      /*lsp 13/08/2013
       *if road user detected then turn on the streetlight immediately
       *both SDRoadUserDetectedByLocalNode and SDTempRoadUserDetectedByLocalNode is pointer
       *thus, once SDTempRoadUserDetectedByLocalNode is reseted, SDRoadUserDetectedByLocalNode also been reseted.
       *Manual value assignment is need
       *
       *SDRoadUserDetectedByLocalNode = SDTempRoadUserDetectedByLocalNode;
       */

       SDRoadUserDetectedByLocalNode->isCyclistInRange = SDTempRoadUserDetectedByLocalNode->isCyclistInRange;
       SDRoadUserDetectedByLocalNode->dblDistCyclist = SDTempRoadUserDetectedByLocalNode->dblDistCyclist;

       SDRoadUserDetectedByLocalNode->isPedestrianInRange = SDTempRoadUserDetectedByLocalNode->isPedestrianInRange;
       SDRoadUserDetectedByLocalNode->dblDistPedestrian = SDTempRoadUserDetectedByLocalNode->dblDistPedestrian;

       SDRoadUserDetectedByLocalNode->isMotoristInRange = SDTempRoadUserDetectedByLocalNode->isMotoristInRange;
       SDRoadUserDetectedByLocalNode->dblDistMotorist = SDTempRoadUserDetectedByLocalNode->dblDistMotorist;

       //SDRoadUserDetectedByLocalNode->dataOriginateFrom = SDTempRoadUserDetectedByLocalNode->dataOriginateFrom;
       SDRoadUserDetectedByLocalNode->dataOriginateFrom = myApplAddr();

       /*
        * Only used if speed detection is allowed and they are used to calculate the streetlight delay timer.
        * For streetlight delay timer, average speed is assumed.  motorist speed = 10 miles per hour is assumed.
        */
       SDRoadUserDetectedByLocalNode->dblSpeedCyclist = SDTempRoadUserDetectedByLocalNode->dblSpeedCyclist;
       SDRoadUserDetectedByLocalNode->dblSpeedMotorist = SDTempRoadUserDetectedByLocalNode->dblSpeedMotorist;
       SDRoadUserDetectedByLocalNode->dblSpeedPedestrian = SDTempRoadUserDetectedByLocalNode->dblSpeedPedestrian;

       //SDRoadUserDetectedByLocalNode->geoAddrLamppost = SDTempRoadUserDetectedByLocalNode->geoAddrLamppost;
       SDRoadUserDetectedByLocalNode->geoAddrLamppost = ptrStreetlightMobility->getCurrentPosition();

       //SDRoadUserDetectedByLocalNode->intOperationStatus = SDTempRoadUserDetectedByLocalNode->intOperationStatus;

       SDRoadUserDetectedByLocalNode->dblBrightnessLevel = SDTempRoadUserDetectedByLocalNode->dblBrightnessLevel;
       SDRoadUserDetectedByLocalNode->geoAddrMotorist = SDTempRoadUserDetectedByLocalNode->geoAddrMotorist;
       SDRoadUserDetectedByLocalNode->geoAddrPedestrainOrCyclist = SDTempRoadUserDetectedByLocalNode->geoAddrPedestrainOrCyclist;

       //SDRoadUserDetectedByLocalNode->intOperationStatus = LAMP_STATUS_ON_BY_SENSE;

       SDRoadUserDelay->isCyclistInRange = SDTempRoadUserDetectedByLocalNode->isCyclistInRange;
       SDRoadUserDelay->dblDistCyclist = SDTempRoadUserDetectedByLocalNode->dblDistCyclist;

       SDRoadUserDelay->isPedestrianInRange = SDTempRoadUserDetectedByLocalNode->isPedestrianInRange;
       SDRoadUserDelay->dblDistPedestrian = SDTempRoadUserDetectedByLocalNode->dblDistPedestrian;

       SDRoadUserDelay->isMotoristInRange = SDTempRoadUserDetectedByLocalNode->isMotoristInRange;
       SDRoadUserDelay->dblDistMotorist = SDTempRoadUserDetectedByLocalNode->dblDistMotorist;

       //SDRoadUserDelay->dataOriginateFrom = SDTempRoadUserDetectedByLocalNode->dataOriginateFrom;
       SDRoadUserDelay->dataOriginateFrom = myApplAddr();

       /*
        * Only used if speed detection is allowed and they are used to calculate the streetlight delay timer.
        * For streetlight delay timer, average speed is assumed.  motorist speed = 10 miles per hour is assumed.
        */
       SDRoadUserDelay->dblSpeedCyclist = SDTempRoadUserDetectedByLocalNode->dblSpeedCyclist;
       SDRoadUserDelay->dblSpeedMotorist = SDTempRoadUserDetectedByLocalNode->dblSpeedMotorist;
       SDRoadUserDelay->dblSpeedPedestrian = SDTempRoadUserDetectedByLocalNode->dblSpeedPedestrian;


       SDRoadUserDelay->geoAddrLamppost = ptrStreetlightMobility->getCurrentPosition();
       //SDRoadUserDelay->intOperationStatus = SDTempRoadUserDetectedByLocalNode->intOperationStatus;
       SDRoadUserDelay->dblBrightnessLevel = SDTempRoadUserDetectedByLocalNode->dblBrightnessLevel;
       SDRoadUserDelay->geoAddrMotorist = SDTempRoadUserDetectedByLocalNode->geoAddrMotorist;
       SDRoadUserDelay->geoAddrPedestrainOrCyclist = SDTempRoadUserDetectedByLocalNode->geoAddrPedestrainOrCyclist;

       isTrafficDetected = true;
   }
   else
   {
       isTrafficDetected = false;
   }

   //updateStreetlightOppStatus(SDRoadUserDetectedByLocalNode, myApplAddr(), "by samplingTrafficInformation");
   updateStreetlightEnergyAndBrightnessLevel_V2(SDRoadUserDetectedByLocalNode);

   if(dblCurrentStreetlightBrightnessLevel == 0.2)
   {
       if(currentOperationStatus !=  LAMP_STATUS_ON_20 )
           cVecStreetlightOnOFFTime.recordWithTimestamp(simTime(), 0.2);
       currentOperationStatus = LAMP_STATUS_ON_20;
   }
   else if (dblCurrentStreetlightBrightnessLevel == 0.4)
   {
       if(currentOperationStatus !=  LAMP_STATUS_ON_40 )
           cVecStreetlightOnOFFTime.recordWithTimestamp(simTime(), 0.2);
       currentOperationStatus = LAMP_STATUS_ON_40;
   }
   else if (dblCurrentStreetlightBrightnessLevel == 0.6)
   {
       if(currentOperationStatus !=  LAMP_STATUS_ON_60 )
           cVecStreetlightOnOFFTime.recordWithTimestamp(simTime(), 0.6);
       currentOperationStatus = LAMP_STATUS_ON_60;
   }
   else if (dblCurrentStreetlightBrightnessLevel == 0.8)
   {
       if(currentOperationStatus !=  LAMP_STATUS_ON_80 )
           cVecStreetlightOnOFFTime.recordWithTimestamp(simTime(), 0.8);
       currentOperationStatus = LAMP_STATUS_ON_80;
   }
   else if (dblCurrentStreetlightBrightnessLevel == 1.0)
   {
       if(currentOperationStatus !=  LAMP_STATUS_ON_100 )
           cVecStreetlightOnOFFTime.recordWithTimestamp(simTime(), 1.0);
       currentOperationStatus = LAMP_STATUS_ON_100;
   }
}
void StreetlightApplLayer::samplingTrafficInformationForAdaptiveScheme()
{
    SDTempRoadUserDetectedByLocalNode->reset();
    SDRoadUserDetectedByLocalNode->reset();

    myGlobalTraci = FindModule<SUMOTraCIScenarioManagerV2*>::findGlobalModule();
    mapObjHost = myGlobalTraci->getManagedHostsPointer();

    double dblTempMotorisSSD = 0.0, dblTempMotoristSpeed =0.0, dblTempCyclistOrPedestrianSpeed = 0.0;
    Coord tempGeoAddrMotorist, tempGeoAddrCyclistOrPedestrian;

    std::map<std::string, cModule*> :: const_iterator itr;
    for(itr = mapObjHost->begin() ; itr != mapObjHost->end(); ++itr)
    {

          const cModule* mod = (*itr).second;
          const SUMOTraCIMobilityV2* globalMobility = FindModule<SUMOTraCIMobilityV2*>::findSubModule(const_cast<cModule*>(mod));
          //distanceBetweenCar = sqrt((double)(pow((globalMobility->getCurrentPosition().x - ptrStreetlightMobility->getCurrentPosition().x),2)+ pow((globalMobility->getCurrentPosition().y-ptrStreetlightMobility->getCurrentPosition().y),2)));
          distBtwSensorAndRoadUser = sqrt((double)(pow((globalMobility->getCurrentPosition().x - ptrStreetlightMobility->getCurrentPosition().x),2)+ pow((globalMobility->getCurrentPosition().y-ptrStreetlightMobility->getCurrentPosition().y),2)));

          /*09/08/2012 - LSP For debugging
           * to display necessary information on distance sensing mode
           */
          /*
          ev << "Car: " << (*itr).first << " Position:(" <<  globalMobility->getCurrentPosition().x << ", "<< globalMobility->getCurrentPosition().y <<")" <<endl;
          ev<<"Pole Position:("<<move.getCurrentPosition().x<<","<<move.getCurrentPosition().y<<")"<<endl;
          ev<<"distance between them :"<< distanceBetweenCar<<endl;
          */

          //if(distanceBetweenCar <= dblMaxLampPoleSensingDistance ) //if MaxLampPoleSensingDistance = 17 m then sensing is in-use
          if(distBtwSensorAndRoadUser <= dblMaxLampPoleSensingDistance)
          {
              dblTimeRoadUserDetectedByLocalNode = simTime().dbl();

              if(!isObstacleBtwPoleAndCar(mod))
              {
                  /* record the detected road user  */
                  countRoadUser(globalMobility->getRoadUserType(), globalMobility->getParentModule()->getIndex());


                  //if(isAdaptiveScheme) // only apply to my adaptive lighting scheme, assuming sensor can differentiate road user types
                  if(intLightingScheme == ADAPTIVE)
                  {
                      if(globalMobility->getRoadUserType() == MOTORIST)
                      {
                          ptrMotoristMobility = globalMobility;
                          dblTempMotorisSSD = globalMobility->getSSD();
                          dblTempMotoristSpeed =globalMobility->getSpeed(),
                          tempGeoAddrMotorist = globalMobility->getCurrentPosition();
                          isMotoristInRange = true;

                          //LSP 13/08/2013
                          SDTempRoadUserDetectedByLocalNode->isMotoristInRange = isMotoristInRange;
                          SDTempRoadUserDetectedByLocalNode->dblDistMotorist = dblMaxLampPoleSensingDistance;
                          SDTempRoadUserDetectedByLocalNode->dblMotoristSSD = dblTempMotorisSSD;
                          SDTempRoadUserDetectedByLocalNode->dblSpeedMotorist = dblTempMotoristSpeed;
                          SDTempRoadUserDetectedByLocalNode->geoAddrMotorist = tempGeoAddrMotorist;

                      }
                      else if(globalMobility->getRoadUserType() == PEDESTRIAN)
                      {
                          //minDistanceForPedestrianOrCyclist = distanceBetweenCar;
                          ptrCyclistOrPedestrianMobility = globalMobility;
                          dblTempCyclistOrPedestrianSpeed = globalMobility->getSpeed();
                          tempGeoAddrCyclistOrPedestrian = globalMobility->getCurrentPosition();
                          globalMobility->getRoadUserType() == PEDESTRIAN ? isPedestrianInRange = true : isCyclistInRange = true;

                          //LSP 13/08/2013
                          SDTempRoadUserDetectedByLocalNode->isPedestrianInRange = isPedestrianInRange;
                          SDTempRoadUserDetectedByLocalNode->dblDistPedestrian = dblMaxLampPoleSensingDistance;
                          SDTempRoadUserDetectedByLocalNode->dblSpeedPedestrian = dblTempCyclistOrPedestrianSpeed;
                          SDTempRoadUserDetectedByLocalNode->geoAddrPedestrainOrCyclist = tempGeoAddrCyclistOrPedestrian;
                      }
                  }
                  else //for other lighting schemes
                  {
                      error("StreetlightApplLayer::samplingTrafficInformation:: This function is used to evaluate lighting scheme other than adaptive!  Check the omnet.ini setting!");
                  }
              }
          }
    }
//    /* counting the detected road user based on those left the detection range  */
//    countRoadUser(0,0,2);

   SDTempRoadUserDetectedByLocalNode->dataOriginateFrom = myApplAddr();
   if(SDTempRoadUserDetectedByLocalNode->isMotoristInRange || SDTempRoadUserDetectedByLocalNode->isPedestrianInRange || SDTempRoadUserDetectedByLocalNode->isCyclistInRange)
   {
       /*lsp 13/08/2013
        *if road user detected then turn on the streetlight immediately
        *both SDRoadUserDetectedByLocalNode and SDTempRoadUserDetectedByLocalNode is pointer
        *thus, once SDTempRoadUserDetectedByLocalNode is reseted, SDRoadUserDetectedByLocalNode also been reseted.
        *Manual value assignment is need
        *
        *SDRoadUserDetectedByLocalNode = SDTempRoadUserDetectedByLocalNode;
        */
       SDRoadUserDetectedByLocalNode->isCyclistInRange = SDTempRoadUserDetectedByLocalNode->isCyclistInRange;
       SDRoadUserDetectedByLocalNode->dblDistCyclist = SDTempRoadUserDetectedByLocalNode->dblDistCyclist;

       SDRoadUserDetectedByLocalNode->isPedestrianInRange = SDTempRoadUserDetectedByLocalNode->isPedestrianInRange;
       SDRoadUserDetectedByLocalNode->dblDistPedestrian = SDTempRoadUserDetectedByLocalNode->dblDistPedestrian;

       SDRoadUserDetectedByLocalNode->isMotoristInRange = SDTempRoadUserDetectedByLocalNode->isMotoristInRange;
       SDRoadUserDetectedByLocalNode->dblDistMotorist = SDTempRoadUserDetectedByLocalNode->dblDistMotorist;

       //SDRoadUserDetectedByLocalNode->dataOriginateFrom = SDTempRoadUserDetectedByLocalNode->dataOriginateFrom;
       SDRoadUserDetectedByLocalNode->dataOriginateFrom = myApplAddr();

         /*
         * Only used if speed detection is allowed and they are used to calculate the streetlight delay timer.
         * For streetlight delay timer, average speed is assumed.  motorist speed = 10 miles per hour is assumed.
         */
       SDRoadUserDetectedByLocalNode->dblSpeedCyclist = SDTempRoadUserDetectedByLocalNode->dblSpeedCyclist;
       SDRoadUserDetectedByLocalNode->dblSpeedMotorist = SDTempRoadUserDetectedByLocalNode->dblSpeedMotorist;
       SDRoadUserDetectedByLocalNode->dblSpeedPedestrian = SDTempRoadUserDetectedByLocalNode->dblSpeedPedestrian;

       //SDRoadUserDetectedByLocalNode->geoAddrLamppost = SDTempRoadUserDetectedByLocalNode->geoAddrLamppost;
       SDRoadUserDetectedByLocalNode->geoAddrLamppost = ptrStreetlightMobility->getCurrentPosition();

       //SDRoadUserDetectedByLocalNode->intOperationStatus = SDTempRoadUserDetectedByLocalNode->intOperationStatus;

       SDRoadUserDetectedByLocalNode->dblBrightnessLevel = SDTempRoadUserDetectedByLocalNode->dblBrightnessLevel;
       SDRoadUserDetectedByLocalNode->geoAddrMotorist = SDTempRoadUserDetectedByLocalNode->geoAddrMotorist;
       SDRoadUserDetectedByLocalNode->geoAddrPedestrainOrCyclist = SDTempRoadUserDetectedByLocalNode->geoAddrPedestrainOrCyclist;

       //SDRoadUserDetectedByLocalNode->intOperationStatus = LAMP_STATUS_ON_BY_SENSE;

       SDRoadUserDelay->isCyclistInRange = SDTempRoadUserDetectedByLocalNode->isCyclistInRange;
       SDRoadUserDelay->dblDistCyclist = SDTempRoadUserDetectedByLocalNode->dblDistCyclist;

       SDRoadUserDelay->isPedestrianInRange = SDTempRoadUserDetectedByLocalNode->isPedestrianInRange;
       SDRoadUserDelay->dblDistPedestrian = SDTempRoadUserDetectedByLocalNode->dblDistPedestrian;

       SDRoadUserDelay->isMotoristInRange = SDTempRoadUserDetectedByLocalNode->isMotoristInRange;
       SDRoadUserDelay->dblDistMotorist = SDTempRoadUserDetectedByLocalNode->dblDistMotorist;

       //SDRoadUserDelay->dataOriginateFrom = SDTempRoadUserDetectedByLocalNode->dataOriginateFrom;
       SDRoadUserDelay->dataOriginateFrom = myApplAddr();

      /*
      * Only used if speed detection is allowed and they are used to calculate the streetlight delay timer.
      * For streetlight delay timer, average speed is assumed.  motorist speed = 10 miles per hour is assumed.
      */
       SDRoadUserDelay->dblSpeedCyclist = SDTempRoadUserDetectedByLocalNode->dblSpeedCyclist;
       SDRoadUserDelay->dblSpeedMotorist = SDTempRoadUserDetectedByLocalNode->dblSpeedMotorist;
       SDRoadUserDelay->dblSpeedPedestrian = SDTempRoadUserDetectedByLocalNode->dblSpeedPedestrian;

       SDRoadUserDelay->geoAddrLamppost = ptrStreetlightMobility->getCurrentPosition();
       //SDRoadUserDelay->intOperationStatus = SDTempRoadUserDetectedByLocalNode->intOperationStatus;
       SDRoadUserDelay->dblBrightnessLevel = SDTempRoadUserDetectedByLocalNode->dblBrightnessLevel;
       SDRoadUserDelay->geoAddrMotorist = SDTempRoadUserDetectedByLocalNode->geoAddrMotorist;
       SDRoadUserDelay->geoAddrPedestrainOrCyclist = SDTempRoadUserDetectedByLocalNode->geoAddrPedestrainOrCyclist;

       isTrafficDetected = true;
   }
   else
   {
      isTrafficDetected = false;
   }
   updateStreetlightOppStatus(SDRoadUserDetectedByLocalNode, myApplAddr(), "sampling");
}

void StreetlightApplLayer::samplingTrafficInformationForHardcodedDimmer()
{
    myGlobalTraci = FindModule<SUMOTraCIScenarioManagerV2*>::findGlobalModule();
    mapObjHost = myGlobalTraci->getManagedHostsPointer();
    Coord tempGeoAddrMotorist, tempGeoAddrCyclistOrPedestrian;
    std::map<std::string, cModule*> :: const_iterator itr;

    for(itr = mapObjHost->begin() ; itr != mapObjHost->end(); ++itr)
    {
       const cModule* mod = (*itr).second;
       const SUMOTraCIMobilityV2* globalMobility = FindModule<SUMOTraCIMobilityV2*>::findSubModule(const_cast<cModule*>(mod));
       distBtwSensorAndRoadUser = sqrt((double)(pow((globalMobility->getCurrentPosition().x - ptrStreetlightMobility->getCurrentPosition().x),2)+ pow((globalMobility->getCurrentPosition().y-ptrStreetlightMobility->getCurrentPosition().y),2)));
       if(distBtwSensorAndRoadUser <= (dblAverageLightSpan/2))
        {
            if(!isObstacleBtwPoleAndCar(mod))
            {
                /* record the detected road user  */
                countRoadUser(globalMobility->getRoadUserType(), globalMobility->getParentModule()->getIndex());
            }
        }
    }
    SDtemp->reset();
    updateStreetlightEnergyAndBrightnessLevel_V2(SDtemp);
}
void StreetlightApplLayer::samplingTrafficInformationForTimeBasedScheme()
{
    myGlobalTraci = FindModule<SUMOTraCIScenarioManagerV2*>::findGlobalModule();
    mapObjHost = myGlobalTraci->getManagedHostsPointer();
    Coord tempGeoAddrMotorist, tempGeoAddrCyclistOrPedestrian;
    std::map<std::string, cModule*> :: const_iterator itr;

    for(itr = mapObjHost->begin() ; itr != mapObjHost->end(); ++itr)
    {
       const cModule* mod = (*itr).second;
       const SUMOTraCIMobilityV2* globalMobility = FindModule<SUMOTraCIMobilityV2*>::findSubModule(const_cast<cModule*>(mod));
       distBtwSensorAndRoadUser = sqrt((double)(pow((globalMobility->getCurrentPosition().x - ptrStreetlightMobility->getCurrentPosition().x),2)+ pow((globalMobility->getCurrentPosition().y-ptrStreetlightMobility->getCurrentPosition().y),2)));
       if(distBtwSensorAndRoadUser <= (dblAverageLightSpan/2))
        {
            if(!isObstacleBtwPoleAndCar(mod))
            {
                /* record the detected road user  */
                countRoadUser(globalMobility->getRoadUserType(), globalMobility->getParentModule()->getIndex());
            }
        }
    }
    SDtemp->reset();
    updateStreetlightEnergyAndBrightnessLevel_V2(SDtemp);
}
void StreetlightApplLayer::samplingTrafficInformationForZoningScheme()
{
    myGlobalTraci = FindModule<SUMOTraCIScenarioManagerV2*>::findGlobalModule();
    mapObjHost = myGlobalTraci->getManagedHostsPointer();

    std::map<std::string, cModule*> :: const_iterator itr;
    SDtemp->reset();

    for(itr = mapObjHost->begin() ; itr != mapObjHost->end(); ++itr)
    {
          const cModule* mod = (*itr).second;
          const SUMOTraCIMobilityV2* globalMobility = FindModule<SUMOTraCIMobilityV2*>::findSubModule(const_cast<cModule*>(mod));
          distBtwSensorAndRoadUser = sqrt((double)(pow((globalMobility->getCurrentPosition().x - ptrStreetlightMobility->getCurrentPosition().x),2)+ pow((globalMobility->getCurrentPosition().y-ptrStreetlightMobility->getCurrentPosition().y),2)));

          /* for counting the road user passes this lamppost*/
          if(distBtwSensorAndRoadUser <= (dblAverageLightSpan/2))
          {
              /* record the detected road user  */
              countRoadUser(globalMobility->getRoadUserType(), globalMobility->getParentModule()->getIndex());
          }

          /* for lighting control */
          if(distBtwSensorAndRoadUser <= (150 + (dblAverageLightSpan/2)))
          {
              if(!isObstacleBtwPoleAndCar(mod))
              {
                  /* for motorist the zoning is set to 100 m, similar to adaptive scheme*/
                  if(globalMobility->getRoadUserType() == MOTORIST && distBtwSensorAndRoadUser <= (100 + (dblAverageLightSpan/2)))
                  {
                      SDtemp->isMotoristInRange = true;
                      SDtemp->dblDistMotorist = std::max(SDtemp->dblDistMotorist, distBtwSensorAndRoadUser);
                  }
                  /* for pedestrian the zoning is set to 150 m, similar to adaptive scheme*/
                  else if (globalMobility->getRoadUserType() == PEDESTRIAN && distBtwSensorAndRoadUser <= (150 + (dblAverageLightSpan/2)))
                  {
                      SDtemp->isPedestrianInRange = true;
                      SDtemp->dblDistPedestrian = std::max(SDtemp->dblDistPedestrian, distBtwSensorAndRoadUser);
                  }
              }
          }
    }

    /* To record the ON and OFF of  the streetlight.  For blinking analysis  */
    //if(SDtemp->isPedestrianInRange || SDtemp->isMotoristInRange) // there is a traffic in the range
    if(SDtemp->getMaxObjDist() > 0)
    {
        if (currentOperationStatus != LAMP_STATUS_ON)
        {
            currentOperationStatus = LAMP_STATUS_ON;
            /* record the ON time */
            cVecStreetlightOnOFFTime.recordWithTimestamp(simTime(), 1.0);
        }
    }
    else
    {
        if(currentOperationStatus != LAMP_STATUS_OFF)
        {
            currentOperationStatus = LAMP_STATUS_OFF;
            /* record the OFF time */
            cVecStreetlightOnOFFTime.recordWithTimestamp(simTime(), 0.0);
        }
    }
    updateStreetlightEnergyAndBrightnessLevel_V2(SDtemp);

}
void StreetlightApplLayer::samplingTrafficInformationForZoningPedestrianAndGPS_TTFF_Scheme()
{
    myGlobalTraci = FindModule<SUMOTraCIScenarioManagerV2*>::findGlobalModule();
    mapObjHost = myGlobalTraci->getManagedHostsPointer();

    std::map<std::string, cModule*> :: const_iterator itr;
    SDtemp->reset();

    for(itr = mapObjHost->begin() ; itr != mapObjHost->end(); ++itr)
    {
          const cModule* mod = (*itr).second;
          const SUMOTraCIMobilityV2* globalMobility = FindModule<SUMOTraCIMobilityV2*>::findSubModule(const_cast<cModule*>(mod));
          distBtwSensorAndRoadUser = sqrt((double)(pow((globalMobility->getCurrentPosition().x - ptrStreetlightMobility->getCurrentPosition().x),2)+ pow((globalMobility->getCurrentPosition().y-ptrStreetlightMobility->getCurrentPosition().y),2)));

          /* for counting the road user passes this lamppost*/
          if(distBtwSensorAndRoadUser <= (dblAverageLightSpan/2))
          {
              /* record the detected road user  */
              countRoadUser(globalMobility->getRoadUserType(), globalMobility->getParentModule()->getIndex());
          }

          /* for lighting control */
          if(distBtwSensorAndRoadUser <= (150 + (dblAverageLightSpan/2)) &&
                  (simTime().dbl() - globalMobility->getRoadUserStartTime()) > globalMobility->getRoadUserGPS_TTFF())
          {
              if(!isObstacleBtwPoleAndCar(mod))
              {
                  /* for motorist the zoning is set to 100 m, similar to adaptive scheme*/
                  /* not considered for zoning for pedestrian only */
                  /*
                  if(globalMobility->getRoadUserType() == MOTORIST && distBtwSensorAndRoadUser <= (100 + (dblAverageLightSpan/2)))
                  {
                      SDtemp->isMotoristInRange = true;
                      SDtemp->dblDistMotorist = std::max(SDtemp->dblDistMotorist, distBtwSensorAndRoadUser);
                  }
                  */
                  /* for pedestrian the zoning is set to 150 m, similar to adaptive scheme*/
                  if (globalMobility->getRoadUserType() == PEDESTRIAN && distBtwSensorAndRoadUser <= (150 + (dblAverageLightSpan/2)))
                  {
                      //opp_warning("4. distBtwSensorAndRoadUser = %4.5f, getRoadUserGPS_TTFF() = %4.5f, different = %4.5f",distBtwSensorAndRoadUser, globalMobility->getRoadUserGPS_TTFF(), (simTime().dbl() - globalMobility->getRoadUserStartTime()));
                      SDtemp->isPedestrianInRange = true;
                      SDtemp->dblDistPedestrian = std::max(SDtemp->dblDistPedestrian, distBtwSensorAndRoadUser);
                  }
              }
          }
    }

    /* To record the ON and OFF of  the streetlight.  For blinking analysis  */
    if(SDtemp->getMaxObjDist() > 0)
    {
        if (currentOperationStatus != LAMP_STATUS_ON)
        {
            currentOperationStatus = LAMP_STATUS_ON;
            /* record the ON time */
            cVecStreetlightOnOFFTime.recordWithTimestamp(simTime(), 1.0);
        }
    }
    else
    {
        if(currentOperationStatus != LAMP_STATUS_OFF)
        {
            currentOperationStatus = LAMP_STATUS_OFF;
            /* record the OFF time */
            cVecStreetlightOnOFFTime.recordWithTimestamp(simTime(), 0.0);
        }
    }
    updateStreetlightEnergyAndBrightnessLevel_V2(SDtemp);

}

void StreetlightApplLayer::samplingTrafficInformationForZoningAllRoadUserAndGPS_TTFF_Scheme()
{
    myGlobalTraci = FindModule<SUMOTraCIScenarioManagerV2*>::findGlobalModule();
    mapObjHost = myGlobalTraci->getManagedHostsPointer();

    std::map<std::string, cModule*> :: const_iterator itr;
    SDtemp->reset();

    for(itr = mapObjHost->begin() ; itr != mapObjHost->end(); ++itr)
    {
          const cModule* mod = (*itr).second;
          const SUMOTraCIMobilityV2* globalMobility = FindModule<SUMOTraCIMobilityV2*>::findSubModule(const_cast<cModule*>(mod));
          distBtwSensorAndRoadUser = sqrt((double)(pow((globalMobility->getCurrentPosition().x - ptrStreetlightMobility->getCurrentPosition().x),2)+ pow((globalMobility->getCurrentPosition().y-ptrStreetlightMobility->getCurrentPosition().y),2)));


          /* for counting the road user passes this lamppost*/
          if(distBtwSensorAndRoadUser <= (dblAverageLightSpan/2))
          {
                  /* record the detected road user  */
                  countRoadUser(globalMobility->getRoadUserType(), globalMobility->getParentModule()->getIndex());
          }

          /* for lighting control & GPS TTFF delay */
          if(distBtwSensorAndRoadUser <= (150 + (dblAverageLightSpan/2)) &&
                  (simTime().dbl() - globalMobility->getRoadUserStartTime()) > globalMobility->getRoadUserGPS_TTFF())
          {
              if(!isObstacleBtwPoleAndCar(mod))
              {
                  /* for motorist the zoning is set to 100 m, similar to adaptive scheme*/

                  if(globalMobility->getRoadUserType() == MOTORIST && distBtwSensorAndRoadUser <= (100 + (dblAverageLightSpan/2)))
                  {
                      SDtemp->isMotoristInRange = true;
                      SDtemp->dblDistMotorist = std::max(SDtemp->dblDistMotorist, distBtwSensorAndRoadUser);
                  }
                  /* for pedestrian the zoning is set to 150 m, similar to adaptive scheme*/
                  else if (globalMobility->getRoadUserType() == PEDESTRIAN && distBtwSensorAndRoadUser <= (150 + (dblAverageLightSpan/2)))
                  {
                      SDtemp->isPedestrianInRange = true;
                      SDtemp->dblDistPedestrian = std::max(SDtemp->dblDistPedestrian, distBtwSensorAndRoadUser);
                  }
              }
          }
    }

    /* To record the ON and OFF of  the streetlight.  For blinking analysis  */
    if(SDtemp->getMaxObjDist() > 0)
    {
        if (currentOperationStatus != LAMP_STATUS_ON)
        {
            currentOperationStatus = LAMP_STATUS_ON;
            /* record the ON time */
            cVecStreetlightOnOFFTime.recordWithTimestamp(simTime(), 1.0);
        }
    }
    else
    {
        if(currentOperationStatus != LAMP_STATUS_OFF)
        {
            currentOperationStatus = LAMP_STATUS_OFF;
            /* record the OFF time */
            cVecStreetlightOnOFFTime.recordWithTimestamp(simTime(), 0.0);
        }
    }
    updateStreetlightEnergyAndBrightnessLevel_V2(SDtemp);

}
void StreetlightApplLayer::samplingTrafficInformationForMultiSensorScheme()
{

    myGlobalTraci = FindModule<SUMOTraCIScenarioManagerV2*>::findGlobalModule();
    mapObjHost = myGlobalTraci->getManagedHostsPointer();

    std::map<std::string, cModule*> :: const_iterator itr;
    SDtemp->reset();

    for(itr = mapObjHost->begin() ; itr != mapObjHost->end(); ++itr)
    {
          const cModule* mod = (*itr).second;
          const SUMOTraCIMobilityV2* globalMobility = FindModule<SUMOTraCIMobilityV2*>::findSubModule(const_cast<cModule*>(mod));
          distBtwSensorAndRoadUser = sqrt((double)(pow((globalMobility->getCurrentPosition().x - ptrStreetlightMobility->getCurrentPosition().x),2)+ pow((globalMobility->getCurrentPosition().y-ptrStreetlightMobility->getCurrentPosition().y),2)));


          /* for counting the road user passes this lamppost*/
          if(distBtwSensorAndRoadUser <= (dblAverageLightSpan/2))
          {
              countRoadUser(globalMobility->getRoadUserType(), globalMobility->getParentModule()->getIndex());
          }

          /* for lighting control */
          if(distBtwSensorAndRoadUser <= dblMaxLampPoleSensingDistance )
          {
              //if(!isObstacleBtwPoleAndCar(mod))
              //{
                  /* always keep the nearest distance*/
                  if(globalMobility->getRoadUserType() == MOTORIST)
                  {
                      SDtemp->isMotoristInRange = true;
                      if (SDtemp->dblDistMotorist < 0)
                          SDtemp->dblDistMotorist = distBtwSensorAndRoadUser;
                      else
                          SDtemp->dblDistMotorist = std::min(SDtemp->dblDistMotorist, distBtwSensorAndRoadUser);
                  }
                  else if (globalMobility->getRoadUserType() == PEDESTRIAN)
                  {
                      SDtemp->isPedestrianInRange = true;
                      if(SDtemp->dblDistPedestrian < 0)
                          SDtemp->dblDistPedestrian = distBtwSensorAndRoadUser;
                      else
                          SDtemp->dblDistPedestrian = std::min(SDtemp->dblDistPedestrian, distBtwSensorAndRoadUser);
                  }
              //}
          }
    }

    /* To record the ON and OFF of  the streetlight.  For blinking analysis  */

    if(SDtemp->isPedestrianInRange || SDtemp->isMotoristInRange) // there is a traffic in the range
    {
        if (SDtemp->getMinObjDist() > 0 && SDtemp->getMinObjDist() <=10)
        {
            if(currentOperationStatus != LAMP_STATUS_ON_100)
            {
                cVecStreetlightOnOFFTime.recordWithTimestamp(simTime(), 1.0);
            }
            currentOperationStatus = LAMP_STATUS_ON_100;
        }
        else if (SDtemp->getMinObjDist() > 10 && SDtemp->getMinObjDist() <=20)
        {
            // at 70% brightness
            if(currentOperationStatus != LAMP_STATUS_ON_70)
                cVecStreetlightOnOFFTime.recordWithTimestamp(simTime(), 0.7);

            currentOperationStatus = LAMP_STATUS_ON_70;
        }
        else //meaning the light is always at 40 % brightness
        {
            /* record the turn to 0.4 time */
            if(currentOperationStatus != LAMP_STATUS_ON_40)
                cVecStreetlightOnOFFTime.recordWithTimestamp(simTime(), 0.4);
            currentOperationStatus = LAMP_STATUS_ON_40;
        }
    }
    updateStreetlightEnergyAndBrightnessLevel_V2(SDtemp);
}

void StreetlightApplLayer::generateSensingData(SensorData* data, std::string strInfo){
    Enter_Method_Silent();
    sendMessage(data);
}

void StreetlightApplLayer::generateSensingData(SensorData* data, LAddress::L3Type destAddr, StreetlightApplLayer::MessagesTypes msgType , unsigned long returnACKSeqNum, std::string strInfo){
    Enter_Method_Silent();
    sendMessage(data,msgType,destAddr, returnACKSeqNum);
}

void StreetlightApplLayer::generateSensingData(SensorData* data, LAddress::L3Type destAddr, LAddress::L3Type ForWhichData, StreetlightApplLayer::MessagesTypes msgType, std::string strInfo){
    Enter_Method_Silent();
    data->intOperationStatus = currentOperationStatus;
    sendMessage(data,msgType,destAddr, ForWhichData);
}


void StreetlightApplLayer::finish(){
    //simulation.getSystemModule()->unsubscribe(poleSenseMobileNodeStateChangedSignal,this);

    simulation.getSystemModule()->unsubscribe(mobilityStateChangedSignal,this);
    //simulation.getSystemModule()->unsubscribe(noMobileNodeSignal,this);
    simulation.getSystemModule()->unsubscribe(totalLamppostSignal,this);
    simulation.getSystemModule()->unsubscribe(triggerTrafficModelSignal,this);

    if(msgStreetlightStatus->isScheduled())
    {
        cancelEvent(msgStreetlightStatus);
        delete(msgStreetlightStatus);
        msgStreetlightStatus = 0;
    }

    if(msgNeighbourDiscovery_timer->isScheduled())
    {
        cancelEvent(msgNeighbourDiscovery_timer);
        delete (msgNeighbourDiscovery_timer);
        msgNeighbourDiscovery_timer = 0;
    }
    if(msgPropagateStreetlightOppStatus_timer->isScheduled())
    {
        cancelEvent(msgPropagateStreetlightOppStatus_timer);
        delete(msgPropagateStreetlightOppStatus_timer);
        msgPropagateStreetlightOppStatus_timer = 0;
    }
    if(msgStreetlightOppDelay_timer->isScheduled())
    {
        cancelEvent(msgStreetlightOppDelay_timer);
        delete(msgStreetlightOppDelay_timer);
        msgStreetlightOppDelay_timer = 0;
    }
    if(msgStopPropagateStreetlightOppStatus_timer->isScheduled())
    {
        cancelEvent(msgStopPropagateStreetlightOppStatus_timer);
        delete(msgStopPropagateStreetlightOppStatus_timer);
        msgStopPropagateStreetlightOppStatus_timer = 0;
    }
    if(msgStreetlightUtility_timer->isScheduled())
    {
        cancelEvent(msgStreetlightUtility_timer);
        delete(msgStreetlightUtility_timer);
        msgStreetlightUtility_timer = 0;
    }
    if(msgWaitForApplAckTimer_timer->isScheduled())
    {
        cancelEvent(msgWaitForApplAckTimer_timer);
        delete(msgWaitForApplAckTimer_timer);
        msgWaitForApplAckTimer_timer = 0;
    }
    if(msgTrafficSamplingRate_timer->isScheduled())
    {
        cancelEvent(msgTrafficSamplingRate_timer);
        delete(msgTrafficSamplingRate_timer);
        msgTrafficSamplingRate_timer = 0;
    }

    recordRoadUserCount();
    recordReceivedAckPerNode();
    recordApplDataReceivedPerNode();
    recordDistanceToNeighbour();
    recordScalar("TotalApplDataSent", dataSeqNum);

}

void StreetlightApplLayer::recordReceivedAckPerNode()
{
    tGenericAck::iterator pos;
    std::string strNodeId;
    for(pos = tTotalReceivedAckPerNode.begin(); pos != tTotalReceivedAckPerNode.end(); pos++)
    {
        strNodeId= "node[" + static_cast<std::ostringstream*>( &(std::ostringstream() << pos->first))->str() + "]_TotalACKReceived";
        recordScalar(strNodeId.c_str(), pos->second);
    }
}
void StreetlightApplLayer::recordRoadUserCount()
{
    std::map<int, int>::iterator it;
    int intCountMotorist = 0;
    int intCountPedestrian = 0;

    for(it = mapCountRoadUser.begin(); it != mapCountRoadUser.end(); it++)
    {
        switch(it->second)
        {
            case MOTORIST:
                intCountMotorist++;
                break;
            case PEDESTRIAN:
                intCountPedestrian++;
                break;
        }
    }
    recordScalar("Motorist_count", intCountMotorist);
    recordScalar("Pedestrian_count", intCountPedestrian);
    recordScalar("TotalRoadUser", intCountMotorist+intCountPedestrian);
}
void StreetlightApplLayer::recordDataPacketLatencyPerNode()
{

    tGenericNeighbourStreetlightTable::iterator pos;
    std::string strNodeId;
    for(pos = tNeighbourLatency.begin(); pos != tNeighbourLatency.end(); pos++)
    {
        strNodeId= "node[" + static_cast<std::ostringstream*>( &(std::ostringstream() << pos->first))->str() + "]_TotalLatency";
        recordScalar(strNodeId.c_str(), pos->second);
    }
}
void StreetlightApplLayer::updateDataPacketArrivalTime(LAddress::L3Type srcAddr)
{

    tGenericNeighbourStreetlightTable::iterator pos;
    pos = tNeighbourLatency.find(srcAddr);
    if(pos == tNeighbourLatency.end())
    {
        tNeighbourLatency.insert(make_pair(srcAddr, simTime().dbl()));
    }
    else
    {
        if(pos->second)
        pos->second = simTime().dbl();
    }
}
//void StreetlightApplLayer::updateStreetlightEnergyAndBrightnessLevel(SensorData* data )
//{
//    //EnergyUsage* ptrParentEnergyUsage = FindModule<EnergyUsage*>::findSubModule(const_cast<cModule*>(getParentModule()));
//    //StreetlightMobilityV2* ptrStreetlightMobility  = FindModule<StreetlightMobilityV2*>::findSubModule(const_cast<cModule*>(getParentModule()));
//
//    //opp_warning("StreetlightMobilityV2::handleCarPossitionChangeSignal ");
//   if(isAdaptiveScheme) // only apply to my adaptive lighting scheme.
//   {
//       if((data->isPedestrianInRange || data->isCyclistInRange) && !data->isMotoristInRange) //only pedestrian or cyclist is in range
//       {
//           dblCurrentStreetlightBrightnessLevel = ptrParentEnergyUsage->updateEnergyUsage(true,data->dblDistPedestrian);
//       }
//       else if(data->isMotoristInRange && (data->isPedestrianInRange || data->isCyclistInRange)) //both motorist & pedestrian or cyclist is in range
//       {
//           //if stopping distrance required by motorist is within lamppost's beam pattern then turn on the streetlight
//           if((data->dblDistMotorist- data->dblMotoristSSD) <= (dblAverageLightSpan/2))
//           {
//               //value 0 for parameter distance is to trigger the streetlight to 100% brightness
//               dblCurrentStreetlightBrightnessLevel = ptrParentEnergyUsage->updateEnergyUsage(true,1);
//           }
//           else
//               dblCurrentStreetlightBrightnessLevel = ptrParentEnergyUsage->updateEnergyUsage(true,data->dblDistPedestrian);
//       }
//       else if (data->isMotoristInRange && !(data->isPedestrianInRange ||data->isCyclistInRange))//only motorist in range
//       {
//           if((data->dblDistMotorist- data->dblMotoristSSD) <= (dblAverageLightSpan/2))
//           {
//               dblCurrentStreetlightBrightnessLevel = ptrParentEnergyUsage->updateEnergyUsage(true,1); //Value 1 is used to trigger streetlight operation with 100 brightness level.
//           }
//           else
//               dblCurrentStreetlightBrightnessLevel = ptrParentEnergyUsage->updateEnergyUsage(false,200); //Value 200 is assumed to be out of range of streetlight operation distance.  Max distance is assumed to be 150 m
//       }
//       else //both motorist and pedestrian or cyclist are not in range
//           dblCurrentStreetlightBrightnessLevel = ptrParentEnergyUsage->updateEnergyUsage(false,200);
//   }
//   else
//       dblCurrentStreetlightBrightnessLevel = ptrParentEnergyUsage->updateEnergyUsage(true,data->getMinObjDist());
//}

void StreetlightApplLayer::updateStreetlightEnergyAndBrightnessLevel_V2(SensorData* data )
{
   switch(intLightingScheme)
   {
       case ADAPTIVE: case ADAPTIVE_IDEAL:
       {
           if((data->isPedestrianInRange || data->isCyclistInRange) && !data->isMotoristInRange) //only pedestrian or cyclist is in range
           {
               dblCurrentStreetlightBrightnessLevel = ptrParentEnergyUsage->updateEnergyUsageByDistancePedestrian(true,data->dblDistPedestrian);
           }
           else if(data->isMotoristInRange && (data->isPedestrianInRange || data->isCyclistInRange)) //both motorist & pedestrian or cyclist is in range
           {
               dblCurrentStreetlightBrightnessLevel = ptrParentEnergyUsage->updateEnergyUsageByDistanceMixTraffic(true,data->dblDistPedestrian,data->dblDistMotorist);
           }
           else if (data->isMotoristInRange && !(data->isPedestrianInRange ||data->isCyclistInRange))//only motorist in range
           {
               dblCurrentStreetlightBrightnessLevel = ptrParentEnergyUsage->updateEnergyUsageByDistanceMotorist(true, data->dblDistMotorist);
           }
           else if (!(data->isMotoristInRange && (data->isPedestrianInRange || data->isCyclistInRange))) //road user is not in range
           {
               dblCurrentStreetlightBrightnessLevel = ptrParentEnergyUsage->updateEnergyUsageByDistanceTurnOff();
           }
           break;
       }
       case HARDCODED_DIMMER:
       {
           dblCurrentStreetlightBrightnessLevel = ptrParentEnergyUsage->updateEnergyUsageByDefault(dblDefaultDimPercentage);
           break;
       }
       case TIME_BASED:
       {
           dblCurrentStreetlightBrightnessLevel = ptrParentEnergyUsage->updateEnergyUsageByDimmerProfileBasedOnHour(intOperateStartHour, intOperationMonth);
           break;
       }
       case MULTI_SENSOR:
       {
           //dblCurrentStreetlightBrightnessLevel = ptrParentEnergyUsage->updateEnergyUsage(true,data->getMinObjDist());
           dblCurrentStreetlightBrightnessLevel = ptrParentEnergyUsage->updateEnergyUsageMultiSensor(data->getMinObjDist());
           break;
       }
       case ZONING:
       {
           dblCurrentStreetlightBrightnessLevel = ptrParentEnergyUsage->updateEnergyUsageZoning(data->getMaxObjDist());
           break;
       }
       case ZONING_WITH_DELAY_PEDESTRIAN_ONLY: case ZONING_WITH_DELAY_ALL_ROAD_USERS:
       {
           /* The delay represents the  time to first fix (TTFF) of the smartphone's GPS receiver.
            * 92% of the GPS receivers require 0 to 2 seconds of TTFF and the rest requires 2 to 4 seconds.
            *
            * Lehtinen, M.; Happonen, A.; Ikonen, J., "Accuracy and time to first fix using consumer-grade GPS receivers",
            * Software, Telecommunications and Computer Networks, 2008. SoftCOM 2008. 16th International Conference on , vol., no., pp.334,340, 25-27 Sept. 2008
            *
            * doi: 10.1109/SOFTCOM.2008.4669506.
            * URL: http://ieeexplore.ieee.org/stamp/stamp.jsp?tp=&arnumber=4669506&isnumber=4669441
            */

           double delay = 0.0;
           if (uniform(0,1,0) > 0.92)
           {
               delay = uniform(2, 4, 0);
           }
           else
           {
               delay = uniform(0, 2, 0);
           }

           dblCurrentStreetlightBrightnessLevel = ptrParentEnergyUsage->updateEnergyUsageZoningWithGPRSDelay(data->getMaxObjDist(),  delay);
           break;
       }
   }
}


double StreetlightApplLayer::computeDelayStreetlightOperation(SensorData* data)
{

    double dblDistBtwLamppost = 0.0;


    sensorAccuracy eSensorAccuracy = PRESENCE;


    if(eSensorAccuracy == PRESENCE)
    {
        dblDistBtwLamppost = sqrt((double)(pow((data->geoAddrLamppost.x- ptrStreetlightMobility->getCurrentPosition().x),2)+ pow((data->geoAddrLamppost.y-ptrStreetlightMobility->getCurrentPosition().y),2)));

        /*
         * Assuming road user is at the furthest side of the streetlight
         */
        if(data->isPedestrianInRange)
            return ((dblAverageLightSpan)/data->dblSpeedPedestrian);
        if(data->isCyclistInRange)
            return ((dblAverageLightSpan)/data->dblSpeedCyclist);
        if(data->isMotoristInRange)
            return ((dblAverageLightSpan)/4.4704); //assuming motorist at minimum speed of 4.4704 m/s (10 miles per hour)
    }
    if(eSensorAccuracy == GEO_ADDR)
    {
        /*
         * Assuming road user actual location is know which is unlikely
         */
        if(data->isPedestrianInRange)
        {
            dblDistBtwLamppost = sqrt((double)(pow((data->geoAddrPedestrainOrCyclist.x- ptrStreetlightMobility->getCurrentPosition().x),2)+ pow((data->geoAddrPedestrainOrCyclist.y-ptrStreetlightMobility->getCurrentPosition().y),2)));
            return (dblDistBtwLamppost/data->dblSpeedPedestrian);
        }
        if(data->isCyclistInRange)
        {
            dblDistBtwLamppost = sqrt((double)(pow((data->geoAddrPedestrainOrCyclist.x- ptrStreetlightMobility->getCurrentPosition().x),2)+ pow((data->geoAddrPedestrainOrCyclist.y-ptrStreetlightMobility->getCurrentPosition().y),2)));
            return (dblDistBtwLamppost / data->dblSpeedCyclist);
        }
        if(data->isMotoristInRange)
        {
            dblDistBtwLamppost = sqrt((double)(pow((data->geoAddrMotorist.x- ptrStreetlightMobility->getCurrentPosition().x),2)+ pow((data->geoAddrMotorist.y-ptrStreetlightMobility->getCurrentPosition().y),2)));
            return (dblDistBtwLamppost / data->dblSpeedMotorist);
        }
    }
    return 0.0;
}
void StreetlightApplLayer::collectNumOfHopToNeighbour(StreetlightApplPkt* ptk)
{
    tNeighbourHopTable::iterator it = tHopToNeighbour.find(ptk->getSrcAddr());

    cObject *const cInfo = ptk->removeControlInfo();
    //const NetwControlInfo *const cCtrlInfo = dynamic_cast<const NetwControlInfo *>(cInfo);
    const int hopCount = NetwControlInfo::getNetwHopCount(cInfo);
    const LAddress::L3Type& SrcAddr = ptk->getSrcAddr();
    delete cInfo;

   if(ptk->getSrcAddr() != myApplAddr())
   {
       if(it == tHopToNeighbour.end())
           tHopToNeighbour.insert(make_pair(SrcAddr,hopCount));
       else
       {
           if(it->second > hopCount)
               it->second = hopCount;
       }
   }
   //For debugging purpose
   /*
   for(it = tHopToNeighbour.begin(); it != tHopToNeighbour.end(); it++)
   {
       ev<<"StreetlightApplLayer::collectNumOfHopToNeighbour : ("<<it->first<<", "<<it->second<<")"<<endl;
   }
   */
   delete ptk;
}
void StreetlightApplLayer::collectNeighbourLocationIntoRegion(StreetlightApplPkt* ptk)
{
    double dblDistToAdjacentStreetlight = sqrt((double)(pow((ptk->getGeoAddrLamppost().x- ptrStreetlightMobility->getCurrentPosition().x),2)+ pow((ptk->getGeoAddrLamppost().y-ptrStreetlightMobility->getCurrentPosition().y),2)));

    tGenericNeighbourStreetlightTable::iterator pos;

    //neighbour is at Upper left region
    if((ptk->getGeoAddrLamppost().x < ptrStreetlightMobility->getCurrentPosition().x) && (ptk->getGeoAddrLamppost().y < ptrStreetlightMobility->getCurrentPosition().y))
    {
        pos = tNeighbourUpperLeftRegion.find(ptk->getSrcAddr());
        if(pos == tNeighbourUpperLeftRegion.end() && ptk->getSrcAddr() != myApplAddr())
            tNeighbourUpperLeftRegion.insert(make_pair(ptk->getSrcAddr(), dblDistToAdjacentStreetlight));
    }
    //neighbour is at Upper right region
    else if ((ptk->getGeoAddrLamppost().x >= ptrStreetlightMobility->getCurrentPosition().x) && (ptk->getGeoAddrLamppost().y < ptrStreetlightMobility->getCurrentPosition().y))
    {
        pos = tNeighbourUpperRightRegion.find(ptk->getSrcAddr());
        if(pos == tNeighbourUpperRightRegion.end()&& ptk->getSrcAddr() != myApplAddr())
            tNeighbourUpperRightRegion.insert(make_pair(ptk->getSrcAddr(), dblDistToAdjacentStreetlight));
    }
    //neighbour is at lower left region
    else if ((ptk->getGeoAddrLamppost().x < ptrStreetlightMobility->getCurrentPosition().x) && (ptk->getGeoAddrLamppost().y >= ptrStreetlightMobility->getCurrentPosition().y))
    {
        pos = tNeighbourLowerLeftRegion.find(ptk->getSrcAddr());
        if(pos == tNeighbourLowerLeftRegion.end()&& ptk->getSrcAddr() != myApplAddr())
            tNeighbourLowerLeftRegion.insert(make_pair(ptk->getSrcAddr(), dblDistToAdjacentStreetlight));
    }
    //neighbour is at lower right region
    else if ((ptk->getGeoAddrLamppost().x >= ptrStreetlightMobility->getCurrentPosition().x) && (ptk->getGeoAddrLamppost().y >= ptrStreetlightMobility->getCurrentPosition().y))
    {
        pos = tNeighbourLowerRightRegion.find(ptk->getSrcAddr());
        if(pos == tNeighbourLowerRightRegion.end() && ptk->getSrcAddr() != myApplAddr())
            tNeighbourLowerRightRegion.insert(make_pair(ptk->getSrcAddr(), dblDistToAdjacentStreetlight));
    }
}

void StreetlightApplLayer::recalibrateReceivedSensingDataDistance(SensorData* data)
{
    double dblDistBtwLamppost = -1;

    sensorAccuracy eSensorAccuracy = PRESENCE; //current accuracy is only able to detect presence only

    if(eSensorAccuracy == PRESENCE)
    {
        dblDistBtwLamppost = sqrt((double)(pow((data->geoAddrLamppost.x- ptrStreetlightMobility->getCurrentPosition().x),2)+ pow((data->geoAddrLamppost.y-ptrStreetlightMobility->getCurrentPosition().y),2)));

        if(dblDistBtwLamppost - (dblAverageLightSpan/2) < 0 )
            dblDistBtwLamppost =  1;
        else
            //dblDistBtwLamppost-= (dblAverageLightSpan/2);
            dblDistBtwLamppost+= (dblAverageLightSpan/2);

        if(data->isPedestrianInRange)
            data->dblDistPedestrian = dblDistBtwLamppost;
        if(data->isCyclistInRange)
            data->dblDistCyclist = dblDistBtwLamppost ;
        if(data->isMotoristInRange)
            data->dblDistMotorist = dblDistBtwLamppost ;
    }
    if(eSensorAccuracy == GEO_ADDR)
    {
        /* For further implementation */
    }
}
void StreetlightApplLayer::printNeighbourOppStatus()
{

    for( tGenericNeighbourStreetlightTable::iterator pos = tDistToNeighbour.begin(); pos != tDistToNeighbour.end(); pos++)
    {
        ev<<"StreetlightApplLayer::printNeighbourOppStatus : Lamp["<<pos->first
                <<"] is "<<tNeighbourOperationStatus.find(pos->first)->second<<", valid until "<<tNeighbourOperationStatusValidity.find(pos->first)->second
                <<", time stamp :"<<tNeighbourLastUpdate.find(pos->first)->second<<endl;
    }
}
SensorData* StreetlightApplLayer::applLayerPacketToSensorData(StreetlightApplPkt* ptk)
{
    SensorData* tempSensorData;
    tempSensorData->dataOriginateFrom = ptk->getPktOriginAddr();
    tempSensorData->dataSeqNum = ptk->getDataSeqNum();
    tempSensorData->dataTimeStamp = ptk->getTimestamp().dbl();
    tempSensorData->dblDistCyclist = ptk->getDblDistCyclist();
    tempSensorData->dblDistMotorist = ptk->getDblDistMotorist();
    tempSensorData->dblDistPedestrian = ptk->getDblDistPedestrian();
    tempSensorData->dblSpeedCyclist = ptk->getDblSpeedCyclist();
    tempSensorData->dblSpeedMotorist = ptk->getDblSpeedMotorist();
    tempSensorData->dblSpeedPedestrian= ptk->getDblSpeedPedestrian();
    tempSensorData->geoAddrLamppost = ptk->getGeoAddrLamppost();
    tempSensorData->geoAddrMotorist = ptk->getGeoAddrMotorist();
    tempSensorData->geoAddrPedestrainOrCyclist = ptk->getGeoAddrPedstrianOrCyclist();
    tempSensorData->intOperationStatus = ptk->getIntOperationMode();
    tempSensorData->isCyclistInRange = ptk->getIsCyclistInRange();
    tempSensorData->isMotoristInRange = ptk->getIsMotoristInRange();
    tempSensorData->isPedestrianInRange = ptk->getIsPedestrianInRange();

    return tempSensorData;
}
void StreetlightApplLayer::collectNeighbourOppStatus(StreetlightApplPkt* ptk)
{

    double dblDistToAdjacentStreetlight = sqrt((double)(pow((ptk->getGeoAddrLamppost().x- ptrStreetlightMobility->getCurrentPosition().x),2)+ pow((ptk->getGeoAddrLamppost().y-ptrStreetlightMobility->getCurrentPosition().y),2)));

    /*
     * Collected the neighbour operation status into tables
     */
    tGenericNeighbourStreetlightTable::iterator pos;
    pos =tDistToNeighbour.find(ptk->getSrcAddr());

    if(pos == tDistToNeighbour.end())
    {

        tDistToNeighbour.insert(make_pair(ptk->getSrcAddr(),dblDistToAdjacentStreetlight));
        tNeighbourBrightnessLevel.insert(make_pair(ptk->getSrcAddr(),ptk->getDblBrightnessLevel()));
        tNeighbourOperationStatus.insert(make_pair(ptk->getSrcAddr(),ptk->getIntOperationMode()));
        tNeighbourOperationStatusValidity.insert(make_pair(ptk->getSrcAddr(),ptk->getOppStatusValidDuration()));

       if(ptk->getIsCyclistInRange())
       {
           tNeighbourOperationUserTypeCyclist.insert(make_pair(ptk->getSrcAddr(),CYCLIST));
           tNeighbourOperationUserSpeedCyclist.insert(make_pair(ptk->getSrcAddr(),ptk->getDblSpeedCyclist()));
       }
       else
       {
           tNeighbourOperationUserTypeCyclist.insert(make_pair(ptk->getSrcAddr(),-1));
           tNeighbourOperationUserSpeedCyclist.insert(make_pair(ptk->getSrcAddr(),-1));
       }
       if(ptk->getIsPedestrianInRange())
       {
           tNeighbourOperationUserTypePedestrian.insert(make_pair(ptk->getSrcAddr(),PEDESTRIAN));
           tNeighbourOperationUserSpeedPedestrian.insert(make_pair(ptk->getSrcAddr(),ptk->getDblSpeedPedestrian()));
       }
       else
       {
           tNeighbourOperationUserTypePedestrian.insert(make_pair(ptk->getSrcAddr(),-1));
           tNeighbourOperationUserSpeedPedestrian.insert(make_pair(ptk->getSrcAddr(),-1));
       }
       if(ptk->getIsMotoristInRange())
       {
           tNeighbourOperationUserTypeMotorist.insert(make_pair(ptk->getSrcAddr(),MOTORIST));
           tNeighbourOperationUserSpeedMotorist.insert(make_pair(ptk->getSrcAddr(),ptk->getDblSpeedMotorist()));
       }
       else
       {
           tNeighbourOperationUserTypeMotorist.insert(make_pair(ptk->getSrcAddr(),-1));
           tNeighbourOperationUserSpeedMotorist.insert(make_pair(ptk->getSrcAddr(),-1));
       }

       tNeighbourLastUpdate.insert(make_pair(ptk->getSrcAddr(),ptk->getTimestamp().dbl()));
       tNeighbourDelay.insert(make_pair(ptk->getSrcAddr(),simTime().dbl() - ptk->getTimestamp().dbl()));
    }
    else
    {
        //Update the record timestamp
        pos =tNeighbourLastUpdate.find(ptk->getSrcAddr());
        if(pos->second < ptk->getTimestamp().dbl())
        {
            pos->second = ptk->getTimestamp().dbl();
            pos = tNeighbourDelay.find(ptk->getSrcAddr());
            pos->second  = simTime().dbl() - ptk->getTimestamp().dbl();
            pos->second = dblDistToAdjacentStreetlight;
            //Update the latest neighbour brightness level
            pos =tNeighbourBrightnessLevel.find(ptk->getSrcAddr());
            pos->second = ptk->getDblBrightnessLevel();
            //Update the latest neighbour operation status
            pos =tNeighbourOperationStatus.find(ptk->getSrcAddr());
            pos->second = ptk->getIntOperationMode();
            /* update the opp. status validity duration*/
            pos = tNeighbourOperationStatusValidity.find(ptk->getSrcAddr());
            pos->second = ptk->getOppStatusValidDuration();
            //Update the latest neighbour operation status
            pos =tNeighbourOperationUserTypeCyclist.find(ptk->getSrcAddr());
            if(ptk->getIsCyclistInRange())
            {
                pos->second = CYCLIST;
                (tNeighbourOperationUserSpeedCyclist.find(pos->first))->second = ptk->getDblSpeedCyclist();
            }
            else
            {
                pos->second = -1;
                (tNeighbourOperationUserSpeedCyclist.find(pos->first))->second = -1;
            }
            if(ptk->getIsPedestrianInRange())
            {
                pos->second = PEDESTRIAN;
                (tNeighbourOperationUserSpeedPedestrian.find(pos->first))->second = ptk->getDblSpeedPedestrian();
            }
            else
            {
                pos->second = -1;
                (tNeighbourOperationUserSpeedPedestrian.find(pos->first))->second = -1;
            }
            if(ptk->getIsMotoristInRange())
            {
                pos->second = MOTORIST;
                (tNeighbourOperationUserSpeedMotorist.find(pos->first))->second = ptk->getDblSpeedMotorist();
            }
            else
            {
                pos->second = -1;
                (tNeighbourOperationUserSpeedMotorist.find(pos->first))->second = -1;
            }
        }
    }
}

void StreetlightApplLayer::collectAckTimerList(LAddress::L3Type forWhich, double expireTime, std::string strInfo)
{
    if(tAckTimeUpList.find(forWhich) == tAckTimeUpList.end())
    {
        tAckTimeUpList.insert(make_pair(forWhich, expireTime));
    }
    else
    {
        /* For debugging purpose */
        /*
        if(tAckTimeUpList.find(forWhich)->second > 0)
        {
            opp_warning("StreetlightApplLayer::collectAckTimerList: AckTimer for data[%d] is active!",  tAckTimeUpList.find(forWhich)->second);
        }
        */
        tAckTimeUpList.find(forWhich)->second = expireTime;
    }
}
void StreetlightApplLayer::manageAckTimer()
{
    /* look for the nearest ACK expire time */
   double dblNearestAckExpireTime = 9999999;
   for(tGenericAddrDbl::iterator it = tAckTimeUpList.begin(); it != tAckTimeUpList.end(); it++)
   {
       if(it->second < dblNearestAckExpireTime && it->second > 0)
       {
           runAckTimerForWhichData = it->first;
           dblNearestAckExpireTime = it->second;
       }
   }
   if(dblNearestAckExpireTime != 9999999)
   {
       dblNextAckExpireTime = (dblNearestAckExpireTime - simTime().dbl()) > 0 ? (dblNearestAckExpireTime - simTime().dbl()) : 0;
       if(!(msgWaitForApplAckTimer_timer ->isScheduled()))
       {
           startTimer(TIMER_WAIT_FOR_APPL_ACK);
           /* remove the entry from the list*/
           tAckTimeUpList.erase(runAckTimerForWhichData);
       }
   }
}
void StreetlightApplLayer::handleReceivedApplACK(LAddress::L3Type srcAddr, std::string strInfo)
{
    tGenericAck::iterator it;
    it = tReceivedAck.find(srcAddr);

    if(it == tReceivedAck.end())
    {
        tReceivedAck.insert(make_pair(srcAddr,1));
    }
    else
    {
        it->second++;
    }
    if(tTotalReceivedAckPerNode.find(srcAddr) == tTotalReceivedAckPerNode.end() )
    {
        tTotalReceivedAckPerNode.insert(make_pair(srcAddr,1));
    }
    else
    {
        tTotalReceivedAckPerNode.find(srcAddr)->second++;
    }

    /* for debuging only*/
    /*
    ev<<"StreetlightApplLayer::handleReceivedApplACK: Received ACK for data  "<<srcAddr<<endl;
    for(it = tReceivedAck.begin(); it != tReceivedAck.end(); it++)
    {
        ev<<"    At ["<<getParentModule()->getIndex()<<"] : For data ["<<it->first<<"] Received "<<it->second<<" ACK vs Expected "<<tExpectedAck.find(it->first)->second<<" ACK"<<endl;
    }
    */
    if(tReceivedAck.find(srcAddr)->second >= tExpectedAck.find(srcAddr)->second)
    {
        //tReceivedAck.find(srcAddr)->second = 0;
        tReceivedAck.erase(srcAddr);
        if(tAckTimeUpList.find(srcAddr) != tAckTimeUpList.end())
            tAckTimeUpList.erase(srcAddr);
        if(msgWaitForApplAckTimer_timer->isScheduled())
            cancelEvent(msgWaitForApplAckTimer_timer);
    }
    else
    {
        //opp_warning("StreetlightApplLayer::handleReceivedApplACK: still waiting for more ACK from neighbours");
    }

    //For debugging purpose
    /*
    for(it = tReceivedAck.begin(); it != tReceivedAck.end(); it++)
     {
         ev<<"Ack timer up for data ["<<it->first<<"] is "<<tAckTimeUpList.find(srcAddr)->second<<endl;
     }
     */
}
void StreetlightApplLayer::colloctDistToNeighbourByHop(LAddress::L3Type addr, int hopCount, Coord geoAddr)
{
    tGenericNeighbourStreetlightTable::iterator it = tDistToNeighbourByHop.find(addr);
    if(it == tDistToNeighbourByHop.end())
    {
        tDistToNeighbourByHop.insert(make_pair(addr, hopCount));
    }
    else
    {
        if(hopCount < it->second)
            it->second = hopCount;
    }

    //For debugging purpose
    /*
    for(it = tDistToNeighbourByHop.begin(); it != tDistToNeighbourByHop.end(); it++)
    {
        ev<<"StreetlightApplLayer::colloctDistToNeighbourByHop : ("<<it->first<<", "<<it->second<<")"<<endl;
    }
    */
    if(tNeighbourGeoAddr.find(addr) == tNeighbourGeoAddr.end())
        tNeighbourGeoAddr.insert(make_pair(addr, geoAddr));
    else
        tNeighbourGeoAddr.find(addr)->second = geoAddr;

    /* For debugging only*/
    /*
    for ( tGenericNeighbourStreetlightGeoAddr::iterator itGeoAddr = tNeighbourGeoAddr.begin(); itGeoAddr != tNeighbourGeoAddr.end(); itGeoAddr++)
        ev<<"StreetlightApplLayer::colloctDistToNeighbourByHop : Lamp ["<<itGeoAddr->first<<"] GeoAddr ("<<itGeoAddr->second.x<<","<<itGeoAddr->second.y<<")"<<endl;
    */
}
void StreetlightApplLayer::handleLowerMsg(cMessage* msg)
{
    switch(msg->getKind())
    {
        case NEIGHBOUR_DISCOVERY:
        {
            LimitedFloodPkt* ptk = check_and_cast<LimitedFloodPkt *>(msg);

            cObject *const pCtrlInfo = msg->removeControlInfo();
            const int hopCount = NetwControlInfo::getNetwHopCount(pCtrlInfo);

            const LAddress::L3Type& SrcAddr = ptk->getSrcAddr();

            if (pCtrlInfo != NULL)
                delete pCtrlInfo;

            if(SrcAddr != myApplAddr())
                colloctDistToNeighbourByHop(SrcAddr, hopCount, ptk->getInitialSrcGeoAddr());

            delete msg;
            break;
        }
        case ACK:
        {
            StreetlightApplPkt* ptk = check_and_cast<StreetlightApplPkt *>(msg);
            cObject *const cInfo = msg->removeControlInfo();

            LAddress::L3Type preSrcAddr = NetwControlInfo::getPreviousAddressFromControlInfo(cInfo);
            LAddress::L3Type AckFor = NetwControlInfo::getAckForWhichAddr(cInfo);

            delete cInfo;

            opp_warning("StreetlightApplLayer::handleLowerMsg: ACK for data for lamp[%d], from %d", AckFor, preSrcAddr);
            handleReceivedApplACK(AckFor , "by handleLowerMsg");

            delete ptk;
            break;
        }
        case DATA_MSG:
        {
            StreetlightApplPkt* ptk = check_and_cast<StreetlightApplPkt *>(msg);

            cObject *const cInfo = msg->removeControlInfo();

//            LAddress::L3Type preSrcAddr = NetwControlInfo::getPreviousAddressFromControlInfo(cInfo);
//            LAddress::L3Type SrcAddr = NetwControlInfo::getAddressFromControlInfo(cInfo);
//            LAddress::L3Type AckFor = NetwControlInfo::getAckForWhichAddr(cInfo);
//            bool isSendDown = NetwControlInfo::isStillForwarding(cInfo);
//            bool isBroadcastedBefore = NetwControlInfo::isBroadcastedBefore(cInfo);

            delete cInfo;
//            unsigned long receivedSeqNum = ptk->getDataSeqNum();
//
//            double dblDistToAdjacentStreetlight = sqrt((double)(pow((ptk->getGeoAddrLamppost().x- ptrStreetlightMobility->getCurrentPosition().x),2)+ pow((ptk->getGeoAddrLamppost().y-ptrStreetlightMobility->getCurrentPosition().y),2)));

            /* For debugging only*/
            /*
            ev<<"(1) StreetlightApplLayer::handleLowerMsg::Received from MAC layer at streetLight [" <<getParentModule()->getIndex() <<"]"<<endl;
                    ev<<"The msg has : "<<endl;
                    ev<<"    isPedestrianInRange : "<<ptk->getIsPedestrianInRange() << " ("<< ptk->getDblDistPedestrian()
                            <<") : isCyclistInRange : " << ptk->getIsCyclistInRange() << " ("<<ptk->getDblDistCyclist()
                            <<") : isMotoristInRange : "<<ptk->getIsMotoristInRange() <<" ("<<ptk->getDblDistMotorist()<<") "
                            <<"neighbour operation mode is "<<ptk->getIntOperationMode()
                            <<" and status valid for "<<ptk->getOppStatusValidDuration()<< endl;
                    ev<<"The msg originated from Lamp["<<ptk->getPktOriginAddr()<<"] : GeoAddr : (" <<ptk->getGeoAddrLamppost().x<<","<<ptk->getGeoAddrLamppost().y<<"), distance to it : "<<dblDistToAdjacentStreetlight
                            <<", msg time stamp is : " << ptk->getTimestamp()
                            <<", seq number : "<<receivedSeqNum<<endl;
                    ev<<"Msg : isSendDown : "<<isSendDown << ", isBroadcasted : "<<isBroadcastedBefore<<endl;
            */

            collectNeighbourOppStatus(ptk);
            printNeighbourOppStatus();
            /*
             * Need to update the delay table
             */
            updateStreetlightStatusLatencyPerNode(ptk->getSrcAddr());
            handleReceivedSensorData(ptk, "by handleLowerMsg");
            delete ptk;
            break;
        }
    }
}

void StreetlightApplLayer::receiveSignal(cComponent *source, simsignal_t signalID, double data) {
    Enter_Method_Silent();

    if(signalID == totalLamppostSignal)
    {
        totalLamppost = data;
    }
}

void StreetlightApplLayer::sendMessage() {
}

void StreetlightApplLayer::sendMessage(SensorData* data, StreetlightApplLayer::MessagesTypes msgType, LAddress::L3Type destAddr, LAddress::L3Type forWhichData)
{
    StreetlightApplPkt *pkt ;

    switch(msgType)
    {
        case DATA_MSG:
        {
            /* record the data sequence number */
            dataSeqNum++;
            pkt = new StreetlightApplPkt("TRAFFIC_INFO", DATA_MSG);
            pkt->setDestAddr(destAddr);
            pkt->setDataSeqNum(dataSeqNum);
            pkt->setIntOperationMode(data->intOperationStatus);
            pkt->setOppStatusValidDuration(data->dataValidity);
            NetwControlInfo::setControlInfo(pkt, destAddr);

            break;
        }
        case ACK:
        {
            if(forWhichData == LAddress::L3BROADCAST)
                opp_error("StreetlightApplLayer::sendMessage: invalid ACK source data!");
            pkt = new StreetlightApplPkt("APPL_ACK", ACK);
            pkt->setDestAddr(destAddr);
            NetwControlInfo::setControlInfo(pkt, destAddr,destAddr,forWhichData);
            opp_warning("StreetlightApplLayer::sendMessage: Preparing ACK for Lamp[%d] at Lamp [%d]", forWhichData, destAddr);
            break;
        }
        default:
        {
            opp_error("StreetlightApplLayer::sendMessage: invalid message type !!");
            break;
        }
    }


    pkt->setDataSeqNum(dataSeqNum);
    pkt->setSrcAddr(myApplAddr());
    pkt->setBitLength(headerLength);

    pkt->setIsCyclistInRange(data->isCyclistInRange);
    pkt->setDblDistCyclist(data->dblDistCyclist);
    pkt->setIsPedestrianInRange(data->isPedestrianInRange);
    pkt->setDblDistPedestrian(data->dblDistPedestrian);
    pkt->setIsMotoristInRange(data->isMotoristInRange);
    pkt->setDblDistMotorist(data->dblDistMotorist);

    /*
     * Only used if speed detection is allowed and they are used to calculate the streetlight delay timer.
     * For streetlight delay timer, average speed is assumed.  motorist speed = 10 miles per hour is assumed.
     */
    pkt->setDblSpeedCyclist(data->dblSpeedCyclist);
    pkt->setDblSpeedPedestrian(data->dblSpeedPedestrian);
    pkt->setDblSpeedMotorist(data->dblSpeedMotorist);

    /*
     * Assuming we know the position of the road user.
     */
    pkt->setGeoAddrLamppost(data->geoAddrLamppost);

    //pkt->setIntOperationMode(currentOperationStatus);

    pkt->setDblBrightnessLevel(dblCurrentStreetlightBrightnessLevel);
    pkt->setGeoAddrMotorist(data->geoAddrMotorist);
    pkt->setGeoAddrPedstrianOrCyclist(data->geoAddrPedestrainOrCyclist);
    pkt->setPktOriginAddr(data->dataOriginateFrom);
    pkt->setTimestamp();

    sendDown(pkt);
}
void StreetlightApplLayer::sendMessage(SensorData* data) {
    //sentMessage = true;

    StreetlightApplPkt *pkt = new StreetlightApplPkt("BROADCAST_SENSOR_DATA", LimitedFlood::DATA_MSG);

    pkt->setDestAddr(-1);
    pkt->setSrcAddr(myApplAddr());
    pkt->setBitLength(headerLength);
    pkt->setPktOriginAddr(myApplAddr());
    pkt->setIsCyclistInRange(data->isCyclistInRange);
    pkt->setDblDistCyclist(data->dblDistCyclist);
    pkt->setIsPedestrianInRange(data->isPedestrianInRange);
    pkt->setDblDistPedestrian(data->dblDistPedestrian);
    pkt->setIsMotoristInRange(data->isMotoristInRange);
    pkt->setDblDistMotorist(data->dblDistMotorist);

    /*
     * Only used if speed detection is allowed and they are used to calculate the streetlight delay timer.
     * For streetlight delay timer, average speed is assumed.  motorist speed = 10 miles per hour is assumed.
     */
    pkt->setDblSpeedCyclist(data->dblSpeedCyclist);
    pkt->setDblSpeedPedestrian(data->dblSpeedPedestrian);
    pkt->setDblSpeedMotorist(data->dblSpeedMotorist);

    /*
     * Assuming we know the position of the road user.
     */
    pkt->setGeoAddrLamppost(data->geoAddrLamppost);
    pkt->setIntOperationMode(data->intOperationStatus);
    pkt->setDblBrightnessLevel(dblCurrentStreetlightBrightnessLevel);
    pkt->setGeoAddrMotorist(data->geoAddrMotorist);
    pkt->setGeoAddrPedstrianOrCyclist(data->geoAddrPedestrainOrCyclist);
    pkt->setPktOriginAddr(data->dataOriginateFrom);
    pkt->setTimestamp();


    NetwControlInfo::setControlInfo(pkt, LAddress::L3BROADCAST );
    sendDown(pkt);

}
void StreetlightApplLayer::sendRouteDiscoveryMessage(SensorData* data) {

    StreetlightApplPkt *pkt = new StreetlightApplPkt("init-route-discovery", LimitedFlood::NEIGHBOUR_DISCOVERY);

    pkt->setDestAddr(-1);
    pkt->setSrcAddr(myApplAddr());
    pkt->setBitLength(headerLength);
    pkt->setPktOriginAddr(myApplAddr());
    pkt->setIntRoadID(intRoadId);
    pkt->setIsAtJunction(boolIsAtJunction);
    pkt->setIsCyclistInRange(data->isCyclistInRange);
    pkt->setDblDistCyclist(data->dblDistCyclist);
    pkt->setIsPedestrianInRange(data->isPedestrianInRange);
    pkt->setDblDistPedestrian(data->dblDistPedestrian);
    pkt->setIsMotoristInRange(data->isMotoristInRange);
    pkt->setDblDistMotorist(data->dblDistMotorist);

    /*
     * Only used if speed detection is allowed and they are used to calculate the streetlight delay timer.
     * For streetlight delay timer, average speed is assumed.  motorist speed = 10 miles per hour is assumed.
     */
    pkt->setDblSpeedCyclist(data->dblSpeedCyclist);
    pkt->setDblSpeedPedestrian(data->dblSpeedPedestrian);
    pkt->setDblSpeedMotorist(data->dblSpeedMotorist);

    /*
     * Assuming we know the position of the road user.
     */
    pkt->setGeoAddrLamppost(data->geoAddrLamppost);
    pkt->setIntOperationMode(currentOperationStatus);
    pkt->setDblBrightnessLevel(dblCurrentStreetlightBrightnessLevel);
    pkt->setGeoAddrMotorist(data->geoAddrMotorist);
    pkt->setGeoAddrPedstrianOrCyclist(data->geoAddrPedestrainOrCyclist);
    pkt->setPktOriginAddr(data->dataOriginateFrom);
    sendDown(pkt);
}

bool StreetlightApplLayer::isObstacleBtwPoleAndCar(const cModule* car)
{

    ObstacleControl* obstaclesCtr = ObstacleControlAccess().getIfExists();
    std::vector<Obstacle> tempObstacle = obstaclesCtr->getObtacleList();

    const SUMOTraCIMobilityV2* globalMobility = FindModule<SUMOTraCIMobilityV2*>::findSubModule(const_cast<cModule*>(car));

    for(unsigned int i = 0; i < tempObstacle.size(); i++)
    {
        Obstacle tempOb = tempObstacle.at(i);
        Coords tempCoords= tempOb.getShape();
        for(unsigned int j=0; j < tempCoords.size()-1; j++)
        {
            if(isLineSegmentIntersectedV2(globalMobility->getCurrentPosition(),ptrStreetlightMobility->getCurrentPosition(),tempCoords.at(j),tempCoords.at(j+1)) )
            {
                return true;
                break;
            }
        }
    }
    return false;
}

bool StreetlightApplLayer::isLineSegmentIntersectedV2(Coord obj, Coord pole, Coord wallPointA, Coord wallPointB)
{
    /*
     * Return false if either of the lines have zero lenght
     */
    if((obj.x == pole.x && obj.y == pole.y )|| (wallPointA.x == wallPointB.x && wallPointA.y == wallPointB.y))
        return false;

    double ax = pole.x - obj.x;
    double ay = pole.y - obj.y;
    double bx = wallPointA.x - wallPointB.x;
    double by = wallPointA.y - wallPointB.y;
    double cx = obj.x - wallPointA.x;
    double cy = obj.y - wallPointA.y;

   double alphaNumerator = by*cx - bx*cy;
   double commonDenominator = ay*bx - ax*by;
   if(commonDenominator >0)
   {
       if(alphaNumerator < 0 || alphaNumerator > commonDenominator )
       {
           return false;
       }
   }else if (commonDenominator < 0)
   {
       if(alphaNumerator > 0 || alphaNumerator < commonDenominator)
       {
               return false;
       }
   }
   double betaNumerator = ax*cy - ay*cx;
   if(commonDenominator > 0)
   {
       if(betaNumerator < 0 || betaNumerator > commonDenominator)
       {
               return false;
       }
   }else if (commonDenominator < 0)
   {
       if(betaNumerator > 0|| betaNumerator < commonDenominator)
       {
               return false;
       }
   }
   if(commonDenominator == 0)
   {
      double y3LessY1 = wallPointA.y - obj.y;
      double collinearityTestForP3 = obj.x*(pole.y - wallPointA.y) + pole.x*(y3LessY1) + wallPointA.x*(obj.y -pole.y);

      if(collinearityTestForP3 == 0)
      {
          if(((obj.x >= wallPointA.x) && (obj.x <= wallPointB.x)) || ((obj.x <= wallPointA.x) && (obj.x >= wallPointB.x)) ||
                  ((pole.x >= wallPointA.x) && (pole.x <= wallPointB.x)) || ((pole.x <= wallPointA.x) && (pole.x >= wallPointB.x)) ||
                 ((wallPointA.x >= obj.x) && (wallPointA.x <= pole.x)) || ((wallPointA.x <= obj.x) && (wallPointA.x >= pole.x)))
          {
              if((obj.y >= wallPointA.y && obj.y <= wallPointB.y) || (obj.y <= wallPointA.y && obj.y >= wallPointB.y) ||
                                   (pole.y >= wallPointA.y && pole.y <= wallPointB.y ) || (pole.y <= wallPointA.y && pole.y >= wallPointB.y) ||
                                  ( wallPointA.y >= obj.y && wallPointA.y <= pole.y) || (wallPointA.y <= obj.y && wallPointA.y >= pole.y))
              {
                  return true;
              }
          }
      }
      return false;
   }
   return true;
}

void StreetlightApplLayer::setApplNodeID(std::string strNodeID)
{
    //getParentModule()->getDisplayString().setTagArg("t",0,strNodeID.c_str());
    if(strNodeID.length() == 9)
    {
        intRoadId =  atoi(strNodeID.substr(0,3).c_str());
        if(atoi(strNodeID.substr(8,1).c_str()) == 1)
        {
            boolIsAtJunction = true;
        }
    }
}
std::string StreetlightApplLayer::getApplNodeID()
{
  return std::string (getParentModule()->getDisplayString().getTagArg("t", 0));
}
void StreetlightApplLayer::receiveSignal(cComponent *source, simsignal_t signalID, cObject *obj)
{
    Enter_Method_Silent();
    if (signalID == mobilityStateChangedSignal)
    {

    }
}

void StreetlightApplLayer::receiveSignal(cComponent *source, simsignal_t signalID, long l )
{
    if(signalID == triggerTrafficModelSignal)
    {
       //scheduleAt(simTime().dbl() +10,msgTrafficSamplingRate_timer);
        scheduleAt(simTime(),msgTrafficSamplingRate_timer);
    }
}
double StreetlightApplLayer::EuclideanDist(Coord a, Coord b)
{
    return sqrt((double)(pow((a.x - b.x),2)+ pow((a.y - b.y),2)));
}

