//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#ifndef __MIXIM_STREETLIGHTAPPLLAYER_H_
#define __MIXIM_STREETLIGHTAPPLLAYER_H_

#include "Coord.h"
#include "BaseApplLayer.h"
#include "SensorData.h"
#include "EnergyUsage.h"

#include "SUMOTraCIScenarioManagerV2.h"
#include "SUMOTraCIMobilityV2.h"
#include "StreetlightMobilityV2.h"
#include "SimpleAddress.h"
#include "StreetlightApplPkt_m.h"
#include "LimitedFloodPkt_m.h"

#include <map>
#include <FWMath.h>
#include <time.h>
#include <cstring>
#include <vector>
/**
 * TODO - Generated class
 */
class StreetlightApplLayer : public BaseApplLayer
{

    public:
        enum MessagesTypes {
                  UNKNOWN=0,
                  DATA_MSG,
                  NEIGHBOUR_DISCOVERY,
                  NEIGHBOUR_DISCOVERY_TIMER,
                  ACK,
               };

        enum streetlightOperationStatus {
                    LAMP_STATUS_OFF = 0,
                    LAMP_STATUS_ON_BY_SENSE = 1,
                    LAMP_STATUS_ON_BY_DELAY = 2,
                    LAMP_STATUS_ON_BY_RELAY = 3,
                    LAMP_STATUS_ON = 4,
                    LAMP_STATUS_ON_40 = 5,
                    LAMP_STATUS_ON_70 = 6,
                    LAMP_STATUS_ON_100 = 7,
                    LAMP_STATUS_ON_20 = 8,
                    LAMP_STATUS_ON_60 = 9,
                    LAMP_STATUS_ON_80 = 10,
                };
    protected:
        static const simsignalwrap_t mobilityStateChangedSignal;
        //simsignal_t noMobileNodeSignal;

        simsignal_t poleSenseMobileNodeStateChangedSignal;
        simsignal_t computeStreetlightUtilitySignal;
        simsignal_t totalLamppostSignal;
        double totalLamppost;
        cOutVector cVecStreetlightOnOFFTime;
        cOutVector cVecRoadUserWithVicinity;


        /* 24/06/2013 LSP
         *
         * the triggerTrafficModelSignal is used to trigger the traffic model at SUMOTraCI Scenario Manager
         *
         * */
        simsignal_t triggerTrafficModelSignal;

        int intRoadId;
        bool boolIsAtJunction;
        bool isGeneratePacket;
        LAddress::L3Type waitingAckForDataFrom, runAckTimerForWhichData;

        SensorData* SDRoadUserDetectedByLocalNode;
        SensorData* SDRoadUserDelay;
        SensorData* SDTempRoadUserDetectedByLocalNode;
        SensorData* SDReturnAck;
        double dblTimeRoadUserDetectedByLocalNode;
        SensorData* SDRoadUserDetectedByNeighbourNode;
        SensorData* SDNoRoadUser;
        SensorData* dataReturn;
        SensorData* SDForPropagation;
        SensorData* SDtemp;
        SensorData* SDRetransmission;

        std::map<int, int> mapCountRoadUser;


    protected:
        /*
         * For selecting random start time of send data to MAC
         */
        double dblSendPacketPeriod;
        bool sentMessage;
        typedef std::vector<Coord> Coords;
        /*
         * For sensing the road user within a user defined range
         */
        //double minDistanceForOtherLightingScheme;
        double dblGodModeMinDist;
        double dblGodModeBrightnessLevel;
        double minDistanceForPedestrianOrCyclist;
        int intObjCount;
        SUMOTraCIScenarioManagerV2* myGlobalTraci;
        const SUMOTraCIMobilityV2* ptrMotoristMobility;
        const SUMOTraCIMobilityV2* ptrCyclistOrPedestrianMobility;
        const StreetlightMobilityV2* ptrStreetlightMobility;
        EnergyUsage* ptrParentEnergyUsage;
        /*
         * for debugging only
         * to test the number of packet send and received by neighbouring node
         * and to ensure all the packet is send before simulation ended
         */
        long nbPacketToTx;

        /*
         *Whether a sensor can detect road users's speed or not
         *Defaul = False, check at NED file.
         */
        bool isSpeedSensingEnable;
        double dblDefaultSSD;
        int intStopPropagateDataAfter;
        double distBtwSensorAndRoadUser;
        double dblTestStopPropagation;

        enum roadUserType {
            MOTORIST = 0,
            CYCLIST = 1,
            PEDESTRIAN = 2,
        };

        enum sensorAccuracy {
            PRESENCE = 0,
            GEO_ADDR = 1,
        };



        enum t_streetlight_timer {
            TIMER_STREETLIGHT_OPP_DELAY=0,
            TIMER_STREETLIGHT_PROPAGATE_DATA,
            TIMER_STREETLIGHT_NETW_DISCOVERY,
            TIMER_STREETLIGHT_UTILITY,
            TIMER_TRAFFIC_SAMPLING,
            TIMER_WAIT_FOR_APPL_ACK,
            TIMER_STREETLIGHT_STOP_PROPAGATE_DATA,
          };

        enum lighting_scheme {
            TIME_BASED = 1,
            MULTI_SENSOR = 2,
            ZONING = 3,
            ADAPTIVE = 4,
            HARDCODED_DIMMER = 5,
            ADAPTIVE_IDEAL = 6,
            ZONING_WITH_DELAY_PEDESTRIAN_ONLY = 7,
            ZONING_WITH_DELAY_ALL_ROAD_USERS = 8,
        };

        lighting_scheme intLightingScheme;
        int intOperateStartHour;
        int intOperationMonth;
        streetlightOperationStatus currentOperationStatus, oppPropagationMode;
        LAddress::L3Type oppStatusBasedOnWhichLamp;

        LAddress::L3Type currentDelayModeScr, currentRelayModeScrAddr;
        double dblCurrentDelayModeScrOperationMode;
        double dblCurrentStreetlightBrightnessLevel;
        bool isMotoristInRange, isPedestrianInRange, isCyclistInRange;
        void computeStreetlightOppDelayTime(SensorData* data);
        void startTimer(t_streetlight_timer timerType);
        /*
         * Self msg to check the latest streetlight operation status
         */
        cMessage* msgStreetlightStatus;
        cMessage* msgPropagateStreetlightOppStatus_timer;
        cMessage* msgStopPropagateStreetlightOppStatus_timer;
        cMessage* msgTrafficSamplingRate_timer;
        double dblTrafficSamplingRate;
        cMessage* msgStreetlightOppDelay_timer;
        cMessage* msgNeighbourDiscovery_timer;
        cMessage* msgStreetlightUtility_timer;
        cMessage* msgWaitForApplAckTimer_timer;
        double dblWaitForApplAckDuration, dblNextAckExpireTime;
        cMessage* msgGodMode;

        double dblStreetlightOperationDelay;
        double dblDebugDelay;

        bool isSensingCompleted;
        bool isSensingPktReceived;
        bool isTrafficDetected;
        bool isSensorStateChange;

        SensorData* receivedSensorData;
        SensorData* sensing;
        SensorData previousSensorData;

        typedef std::map<LAddress::L3Type, double>        tGenericNeighbourStreetlightTable;

        tGenericNeighbourStreetlightTable tDistToNeighbour, tNeighbourBrightnessLevel, tNeighbourOperationStatus, tNeighbourLastUpdate,tNeighbourTimeStamp, tNeighbourDelay;
        tGenericNeighbourStreetlightTable tNeighbourDelayCounter, tNeighbourLatency, tNeighbourLastCheckUpdate, tDistToNeighbourByHop, tNeighbourOperationStatusValidity;
        //tGenericNeighbourStreetlightTable tNeighbourOperationUserType, tNeighbourOperationUserSpeed;
        tGenericNeighbourStreetlightTable tNeighbourOperationUserTypeCyclist, tNeighbourOperationUserSpeedCyclist, tNeighbourOperationUserTypeMotorist, tNeighbourOperationUserSpeedMotorist, tNeighbourOperationUserTypePedestrian, tNeighbourOperationUserSpeedPedestrian;

        tGenericNeighbourStreetlightTable tNeighbourUpperLeftRegion, tNeighbourUpperRightRegion, tNeighbourLowerLeftRegion, tNeighbourLowerRightRegion;
        tGenericNeighbourStreetlightTable tAverageLatencyApplLayer, tTotalApplDataReceived;

        typedef std::map<LAddress::L3Type, double> tGenericAddrDbl;

        tGenericAddrDbl tAckTimeUpList;

        typedef std::map<LAddress::L3Type, long > tGenericAck;
        tGenericAck tReceivedAck, tExpectedAck, tTotalReceivedAckPerNode;
        unsigned long dataSeqNum;

        typedef std::map<LAddress::L3Type, Coord> tGenericNeighbourStreetlightGeoAddr;
        tGenericNeighbourStreetlightGeoAddr tNeighbourGeoAddr;

        //std::map<double, LAddress::L3Type> mapDistAdjacentStreetlight; //distance to adjacent streetlight, adjacent streetlight's ID
        //std::map<int, Coord> mapAdjacentStreetlightIDGeoAddr; //adjacent streetlight's ID, GeoAddr;

        typedef std::map<LAddress::L3Type, cOutVector*> tNeighbourStatusUpdate;
        tNeighbourStatusUpdate tNeighbourLastUpdatePerNode;

        /*
         * To enable the communication for sensor based streetlight operation
         */
        //bool isCommEnable;
        /*
         * For lighting scheme control
         */
        //bool isAdaptiveScheme;

        /*
         * For utility analysis test
         */
        //bool isUtilityTest;
        double dblDefaultDimPercentage;
        /*
         * For streetlight's beam pattern
         */
        double dblAverageLightSpan;

        /*
         * For streetlight utility calulation
         */
        double maxViewDepth;

        const std::map<std::string, cModule*>* mapObjHost;

        double dblMaxLampPoleSensingDistance;
        double dblStatusPropagationTime;

        typedef std::map<LAddress::L3Type, int>        tNeighbourHopTable;
        tNeighbourHopTable tHopToNeighbour;

    protected:
        virtual void handleSelfMsg(cMessage*);
        virtual void handleLowerMsg(cMessage*);
        virtual void handleLowerControl(cMessage *msg);

        virtual void receiveSignal(cComponent *source, simsignal_t signalID, double data);
        virtual void finish();

        void sendMessage();
        void sendMessage(SensorData* data);
        void sendMessage(SensorData* data, StreetlightApplLayer::MessagesTypes msgType, LAddress::L3Type destAddr,LAddress::L3Type forWhichData);
        void sendMessage(SensorData* data, StreetlightApplLayer::MessagesTypes msgType, LAddress::L3Type destAddr, LAddress::L3Type AckForWhichAddr, unsigned long returnACKSeqNum);
        void sendRouteDiscoveryMessage(SensorData* data);
        void handlePositionUpdate();

        void samplingTrafficInformationForAdaptiveScheme();
        void samplingTrafficInformationForAdaptiveIdealScheme();
        void samplingTrafficInformationForTimeBasedScheme();
        void samplingTrafficInformationForHardcodedDimmer();
        void samplingTrafficInformationForMultiSensorScheme();
        void samplingTrafficInformationForZoningScheme();
        void samplingTrafficInformationForZoningPedestrianAndGPS_TTFF_Scheme();
        void samplingTrafficInformationForZoningAllRoadUserAndGPS_TTFF_Scheme();
        void handleReceivedSensorData(StreetlightApplPkt* receivedSensorDataInPacket, std::string strInfo);
        void handleStreetlightDelayTimer(std::string strInfo);
        void handleReceivedApplACK(LAddress::L3Type srcAddr, std::string strInfo);
        void manageAckTimer();
        void collectAckTimerList(LAddress::L3Type forWhich, double expireTime, std::string strInfo);
        bool isObstacleBtwPoleAndCar(const cModule* mod);
        bool isLineSegmentIntersectedV2(Coord obj, Coord pole, Coord wallPointA, Coord wallPointB);

        //void updateStreetlightEnergyAndBrightnessLevel(SensorData* data);
        void updateStreetlightEnergyAndBrightnessLevel_V2(SensorData* data);
        void recalibrateReceivedSensingDataDistance(SensorData* data);
        double computeDelayStreetlightOperation(SensorData* data);
        double getOneHopNeighbour();
        double getOneHopNeighbourV2();
        int countNeighbourByHopNumber(int hop);
        int isAckExpectedByHopNumber(int hop, LAddress::L3Type expectedACKFor);
        int isExpectedAck(int hop, LAddress::L3Type srcAddr);
        SensorData* getNeigbourOppStatus();

        void updateDataPacketArrivalTime(LAddress::L3Type srcAddr);
        void recordDataPacketLatencyPerNode();
        void recordReceivedAckPerNode();
        StreetlightApplLayer::streetlightOperationStatus getActiveDelayNeighbourStatus(int NeighbourID);
        double getActiveDelayNeighbourBrightnessLevel(int NeighbourID);

        void updateStreetlightOppStatus(SensorData* sensedTraffiData,LAddress::L3Type whichLamp, std::string strInfo);
        void updateStreetlightOppStatusForTimeBasedScheme();
        void setTransmissionSensorData(SensorData* data);
        void updateStreetlightStatusLatencyPerNode(LAddress::L3Type srcId);
        void collectStreetlightApplDataPropagationLatencyPerNode(StreetlightApplPkt* ptk);
        void recordApplDataReceivedPerNode();
        void recordDistanceToNeighbour();
        void countRoadUser(int roadUserType, int roadUserId);

        void recordRoadUserCount();

        void collectNeighbourLocationIntoRegion(StreetlightApplPkt* ptk);
        void collectNumOfHopToNeighbour(StreetlightApplPkt* ptk);
        void collectNeighbourOppStatus(StreetlightApplPkt* ptk);
        void printNeighbourOppStatus();
        void colloctDistToNeighbourByHop(LAddress::L3Type addr, int hopCount, Coord geoAddr);
        SensorData* applLayerPacketToSensorData(StreetlightApplPkt* ptk);

     public:
        double getCurrentBrightnessLevel() const;
        int getCurrentOppStatus() const;

        ~StreetlightApplLayer();
        virtual void initialize(int);
        void generateSensingData(SensorData* data, std::string strInfo);
        void generateSensingData(SensorData* data, LAddress::L3Type destAddr, StreetlightApplLayer::MessagesTypes msgType, unsigned long returnACKSeqNum, std::string strInfo);
        void generateSensingData(SensorData* data, LAddress::L3Type destAddr, LAddress::L3Type ForWhichData, StreetlightApplLayer::MessagesTypes msgType, std::string strInfo);
        void setApplNodeID(std::string strNodeID);
        std::string getApplNodeID();
        void receiveSignal(cComponent *source, simsignal_t signalID, cObject *obj);
        void receiveSignal(cComponent *source, simsignal_t signalID, long l );
        double EuclideanDist(Coord a, Coord b);
};

#endif
