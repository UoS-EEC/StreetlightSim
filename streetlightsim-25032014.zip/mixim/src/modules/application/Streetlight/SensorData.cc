//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#include "SensorData.h"

SensorData::SensorData() {
    // TODO Auto-generated constructor stub
    isPedestrianInRange = false;
    dblDistPedestrian = -1;
    isCyclistInRange = false;
    dblDistCyclist = -1;
    isMotoristInRange = false;
    dblDistMotorist = -1;
    dblMotoristSSD = 0.0;

    //dblDistBtwLamppost = 0.0;

    geoAddrLamppost.x = -1;
    geoAddrLamppost.y = -1;
    geoAddrLamppost.z = -1;

    geoAddrMotorist.x = -1;
    geoAddrMotorist.y = -1;
    geoAddrMotorist.z = -1;

    geoAddrPedestrainOrCyclist.x = -1;
    geoAddrPedestrainOrCyclist.y = -1;
    geoAddrPedestrainOrCyclist.z = -1;

    intOperationStatus = -1;
    dblBrightnessLevel = -1;
    dataOriginateFrom = -1;
    dataSeqNum = 0;
    dataTimeStamp = 0.0;


}

SensorData::~SensorData() {
    // TODO Auto-generated destructor stub
}
void SensorData::reset()
{
    isPedestrianInRange = false;
    dblDistPedestrian = -1;
    isCyclistInRange = false;
    dblDistCyclist = -1;
    isMotoristInRange = false;
    dblDistMotorist = -1;
    dblMotoristSSD = 0.0;

    //dblDistBtwLamppost = 0.0;

    geoAddrLamppost.x = -1;
    geoAddrLamppost.y = -1;
    geoAddrLamppost.z = -1;

    geoAddrMotorist.x = -1;
    geoAddrMotorist.y = -1;
    geoAddrMotorist.z = -1;

    geoAddrPedestrainOrCyclist.x = -1;
    geoAddrPedestrainOrCyclist.y = -1;
    geoAddrPedestrainOrCyclist.z = -1;

    intOperationStatus = -1;
    dblBrightnessLevel = -1;
    dataOriginateFrom = -1;

    dataSeqNum = 0;
    dataTimeStamp = 0.0;
    dataValidity = 0.0;
}
double SensorData :: getMinObjDist()
{
    double dblMinDist = 0.0;
    double tmpDistPedestrian, tmpDistCyclist, tmpDistMotorist;


    dblDistPedestrian == -1?tmpDistPedestrian = 999999:tmpDistPedestrian = dblDistPedestrian;
    dblDistCyclist == -1? tmpDistCyclist = 999999:tmpDistCyclist=dblDistCyclist;
    dblDistMotorist == -1?tmpDistMotorist = 999999:tmpDistMotorist = dblDistMotorist;

    if(tmpDistPedestrian < tmpDistCyclist)
        dblMinDist = tmpDistPedestrian;
    else
        dblMinDist = tmpDistCyclist;

    if(dblMinDist > tmpDistMotorist)
        dblMinDist = tmpDistMotorist;

    if(!isPedestrianInRange && !isCyclistInRange && !isMotoristInRange && dblMinDist == 999999)
        return -1.0;
    else
        return dblMinDist;
}

double SensorData :: getMaxObjDist()
{
    return std::max(dblDistMotorist, dblDistPedestrian);
}


