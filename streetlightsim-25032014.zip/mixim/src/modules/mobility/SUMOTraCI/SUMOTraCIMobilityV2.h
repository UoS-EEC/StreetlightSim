//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#ifndef __MIXIM_MYTRACIMOBILITYADDVEHICLE_H_
#define __MIXIM_MYTRACIMOBILITYADDVEHICLE_H_

#include <string>
#include <fstream>
#include <list>
#include <stdexcept>
#include <math.h>
#include <BaseMobility.h>
#include "FindModule.h"
#include "SUMOTraCIScenarioManagerV2.h"
#include "world/annotations/AnnotationManager.h"
#include <sstream>

/**
 * @brief
 * TraCIMobility is a mobility module for hosts controlled by TraCIScenarioManager.
 * It receives position and state updates from an external module and updates
 * the parent module accordingly.
 * See NED file for more info.
 *
 * @ingroup mobility
 * @author Christoph Sommer
 *
 * Update
 * LSP - Add streetlight utility for pedestrian and motorist
 *
 */
class SUMOTraCIMobilityV2 : public BaseMobility
{
    public:
        class Statistics {
            public:
                double firstRoadNumber; /**< for statistics: number of first road we encountered (if road id can be expressed as a number) */
                simtime_t startTime; /**< for statistics: start time */
                simtime_t totalTime; /**< for statistics: total time travelled */
                simtime_t stopTime; /**< for statistics: stop time */
                double minSpeed; /**< for statistics: minimum value of currentSpeed */
                double maxSpeed; /**< for statistics: maximum value of currentSpeed */
                double totalDistance; /**< for statistics: total distance travelled */
                double totalCO2Emission; /**< for statistics: total CO2 emission */
                double averageSpeed;
                double countCollectedSpeed;
                double totalUtility; /** <for statistics: total utility */

                void initialize();
                void watch(cSimpleModule& module);
                void recordScalars(cSimpleModule& module);
        };
        class sort_map_PoleInfo {
            public:
                double key;
                double value;
        };

        enum roadUserType { MOTORIST=0, CYCLIST=1, PEDESTRIAN=2 };
        SUMOTraCIMobilityV2() : BaseMobility(), isPreInitialized(false) {}
        virtual void initialize(int);
        virtual void finish();

        virtual void handleSelfMsg(cMessage *msg);
        virtual void preInitializePole(std::string external_id, const Coord& position);
        virtual void preInitialize(std::string external_id, std::string strRoadUserType, const Coord& position, std::string road_id = "", double speed = -1, double angle = -1, std::string route_Id = "");
        virtual void nextPosition(const Coord& position, std::string road_id = "", double speed = -1, double angle = -1);
        virtual void changePosition();
        virtual void updateDisplayString();
        virtual void setExternalId(std::string external_id) {
            this->external_id = external_id;
        }
        virtual std::string getExternalId() const {
            if (external_id == "") throw cRuntimeError("SUMOTraCIMobility::getExternalId called with no external_id set yet");
            return external_id;
        }
        virtual Coord getPositionAt(const simtime_t& t) const {
            return move.getPositionAt(t) ;
        }
        virtual std::string getRoadId() const {
            if (road_id == "") throw cRuntimeError("SUMOTraCIMobility::getRoadId called with no road_id set yet");
            return road_id;
        }
        virtual double getSpeed() const {
            if (speed == -1) throw cRuntimeError("SUMOTraCIMobility::getSpeed called with no speed set yet");
            return speed;
        }
        /**
         * returns angle in rads, 0 being east, with -M_PI <= angle < M_PI.
         */
        virtual double getAngleRad() const {
            if (angle == M_PI) throw cRuntimeError("TraCIMobility::getAngleRad called with no angle set yet");
            return angle;
        }
        virtual SUMOTraCIScenarioManagerV2* getManager() const {
            //if (!manager) manager = myTraCIScenarioManagerAccess().get();
            if (!manager) manager = SUMOTraCIScenarioManagerV2Access().get();
            return manager;
        }
        void commandSetSpeedMode(int32_t bitset) {
            getManager()->commandSetSpeedMode(getExternalId(), bitset);
        }
        void commandSetSpeed(double speed) {
            getManager()->commandSetSpeed(getExternalId(), speed);
        }
        void commandChangeRoute(std::string roadId, double travelTime) {
            getManager()->commandChangeRoute(getExternalId(), roadId, travelTime);
        }
        double commandDistanceRequest(Coord position1, Coord position2, bool returnDrivingDistance) {
            return getManager()->commandDistanceRequest(position1, position2, returnDrivingDistance);
        }
        void commandStopNode(std::string roadId, double pos, uint8_t laneid, double radius, double waittime) {
            return getManager()->commandStopNode(getExternalId(), roadId, pos, laneid, radius, waittime);
        }
        std::list<std::string> commandGetPolygonIds() {
            return getManager()->commandGetPolygonIds();
        }
        std::string commandGetPolygonTypeId(std::string polyId) {
            return getManager()->commandGetPolygonTypeId(polyId);
        }
        std::list<Coord> commandGetPolygonShape(std::string polyId) {
            return getManager()->commandGetPolygonShape(polyId);
        }
        void commandSetPolygonShape(std::string polyId, std::list<Coord> points) {
            getManager()->commandSetPolygonShape(polyId, points);
        }
        bool commandAddVehicle(std::string vehicleId, std::string vehicleTypeId, std::string routeId, std::string laneId, double emitPosition, double emitSpeed) {
            return getManager()->commandAddVehicle(vehicleId, vehicleTypeId, routeId, laneId, emitPosition, emitSpeed);
        }
        virtual std::list<Coord> getVisualFieldFront() const
        {
              return visualFieldFront;
        }
        virtual std::list<Coord> getVisualFieldRear() const
        {
              return visualFieldRear;
        }
        bool Sort_by(const sort_map_PoleInfo& a ,const sort_map_PoleInfo& b)
        {
            return a.key < b.key;
        }
        void collectStreetlightStatusV2(double distance, double brightnessLevel, int PoleID, double lightSpanDistance, bool isRear);
        void calStreetLightUtilityOfPedestrian();
        void computeStreetlightUtilityOfPedestrianRear();
        void computeStreetlightUtilityOfPedestrianFront();
        void calStreetLightUtilityOfDriver();
        void collectStreetlightInfoBasedOnFoV();
        bool isObstacleBtwPoleAndCar(const cModule* lamppost);
        bool isLineSegmentIntersectedV2(Coord obj, Coord pole, Coord wallPointA, Coord wallPointB);

        int getRoadUserType() const
        {
            return intUserType;
        }
        double getSSD() const;
        double getRoadUserStartTime() const
        {
            return statistics.startTime.dbl();
        }


    private:
        /*
         * 11/03/2013 -LSP
         * Used to compute stopping distance
         */
        double dblDriverReactionDelay;
        double dblFrictionCoefficient;
        double dblGravity;
        double SSD;
        double dblUtiltyDistance;
        double dblGPS_TTFF;
        int intMaxTTFF;
    protected:

        /*
         * 22/04/2013 - LSP
         * Used to set whether a road user is a driver or a pedestrian.
         */
        std::string strRoadUserType;
        roadUserType intUserType;

        int intUtilityCount;
        /*
         * 05/02/2012 LSP
         * to draw the polygon which represent the visual field of a driver
         */
        AnnotationManager* annotations;

        AnnotationManager::Annotation* viewerFront;
        AnnotationManager::Annotation* viewerRear;

        AnnotationManager::Annotation* preViewerFront;
        AnnotationManager::Annotation* preViewerRear;

        std::string viewFieldGroupIdFront;
        std::string viewFieldGroupIdRear;

        AnnotationManager::Group* annotationGroupFront;
        AnnotationManager::Group* annotationGroupRear;

        //RoadUserViewFieldControl* viewFieldControl;

        bool isFirstViewField;
        bool isNormalEraseViewField;
        /*
         * 12/07/2012 LSP
         * To test record the actual Mobile Node Coordinate after all the call as finish signalling
         */
        simsignal_t recordActualMobileNodeCoodinateSignal;
        simsignal_t mobileNodeCoodinate_X_Signal;
        simsignal_t mobileNodeCoodinate_Y_Signal;

        /*
         * 07/05/2013 LSP
         * To trigger the streetlight utility computation
         */
        simsignal_t computeStreetlightUtilitySignal;
        cMessage* computeStreetlightUtilityMsg;
        double dblComputeUtilityDuration;

        int intCountComputeUtilitySignal;

        SUMOTraCIScenarioManagerV2* myGlobalTraci;
        double dblAverageLightSpan;
        /*
         * 11/02/2013 LSP
         * Record the maximum target detection distance
         */
        simsignal_t recordStreetLightUtilitySignal;
        simsignal_t recordDimPercentageSignal;
        simsignal_t recordTotalUtilitySignal;
        simsignal_t recordRoadUserTypeSignal;
        double dblTotalUtility;
        double dblUtilityAvoid, dblUtilityProspectRear, dblUtilityProspectFront;
        cOutVector cVecRear, cVecFront, cVecAvoid;
        double dblTotalCollectedUtilitybyTimeStep;
        int intCollectUtilityByTimeStep;

        //void receiveSignal(cComponent *source, simsignal_t signalID, double l );
        void receiveSignal(cComponent *source, simsignal_t signalID, long boolSignal );
        bool debug; /**< whether to emit debug messages */
        int accidentCount; /**< number of accidents */


        cOutVector currentPosXVec; /**< vector plotting posx */
        cOutVector currentPosYVec; /**< vector plotting posy */
        cOutVector currentSpeedVec; /**< vector plotting speed */
        cOutVector currentAccelerationVec; /**< vector plotting acceleration */
        cOutVector currentCO2EmissionVec; /**< vector plotting current CO2 emission */


        Statistics statistics; /**< everything statistics-related */

        bool isPreInitialized; /**< true if preInitialize() has been called immediately before initialize() */

        std::string external_id; /**< updated by setExternalId() */

        simtime_t lastUpdate; /**< updated by nextPosition() */
        Coord nextPos; /**< updated by nextPosition() */
        std::string road_id; /**< updated by nextPosition() */
        std::string strRoute_Id;
        double speed; /**< updated by nextPosition() */
        double angle; /**< updated by nextPosition() */

        /** 06/02/2012 LSP
         * To add virtual view field
         */
        double dblViewDepht;
        double dblViewDepthConeNearRadius;
        double dblViewDepthConeFarRadius;
        bool drawRoadUserViewField;

        double dblLightIntensityPercentange;
        simtime_t lastUpdateViewFieldMaxDistance;
        int intVisibilityLevel;
        double dblMinVisibleDistanceBasedOnVL;

        std::vector<double> vCollectedPoleDistance;
        //std::map<double,double> mapCollectedPoleInfoAtFront;
        std::map<double,double> mapCollectedPoleInfoBrightness; //<PoleID, Brightness>
        std::map<double,double> mapCollectedPoleInfoDistance; //<Distance, PoleID>  - Why distance is in front - to automatically sort using Distance
        std::map<double,double> mapCollectedPoleInfoFrontView, mapCollectedPoleInfoRearView;
        double dblAvgStreetligthBeamWidth;
        double dblLightSpanDistance;

        std::list<Coord> visualFieldFront;
        std::list<Coord> visualFieldRear;

        cMessage* startAccidentMsg;
        cMessage* stopAccidentMsg;
        //mutable myTraCIScenarioManager* manager;
        mutable SUMOTraCIScenarioManagerV2* manager;
        double last_speed;

        virtual void fixIfHostGetsOutside(); /**< called after each read to check for (and handle) invalid positions */

        /**
         * Returns the amount of CO2 emissions in grams/second, calculated for an average Car
         * @param v speed in m/s
         * @param a acceleration in m/s^2
         * @returns emission in g/s
         */
        double calculateCO2emission(double v, double a) const;

        typedef std::vector<Coord> Coords;

    public:
       double getRoadUserGPS_TTFF() const
       {
           return dblGPS_TTFF;
       }
};

class SUMOTraCIMobilityV2Access
{
    public:
        SUMOTraCIMobilityV2* get(cModule* host) {
            SUMOTraCIMobilityV2* traci = FindModule<SUMOTraCIMobilityV2*>::findSubModule(host);
            ASSERT(traci);
            return traci;
        };
};

#endif
