//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#include "SUMOTraCIScenarioManagerLaunchdV2.h"

#include "mobility/SUMOTraCI/SUMOTraCIConstants.h"
#define CMD_FILE_SEND 0x75

#include <sstream>
#include <iostream>
#include <fstream>

#define MYDEBUG EV

Define_Module(SUMOTraCIScenarioManagerLaunchdV2);

SUMOTraCIScenarioManagerLaunchdV2::~SUMOTraCIScenarioManagerLaunchdV2()
{

}
void SUMOTraCIScenarioManagerLaunchdV2::initialize(int stage)
{
    if (stage != 1) {
        SUMOTraCIScenarioManagerV2::initialize(stage);
        return;
    }
    launchConfig = par("launchConfig").xmlValue();
    seed = par("seed");
    cXMLElementList basedir_nodes = launchConfig->getElementsByTagName("basedir");

    if (basedir_nodes.size() == 0) {
        // default basedir is where current network file was loaded from
        std::string basedir = cSimulation::getActiveSimulation()->getEnvir()->getConfig()->getConfigEntry("network").getBaseDirectory();
        cXMLElement* basedir_node = new cXMLElement("basedir", __FILE__, launchConfig);
        basedir_node->setAttribute("path", basedir.c_str());
        launchConfig->appendChild(basedir_node);
    }
    else if(basedir_nodes.size() == 1)
    {
        std::string basedir = cSimulation::getActiveSimulation()->getEnvir()->getConfig()->getConfigEntry("network").getBaseDirectory();// + (*pathAttr)->getAttribute("path");
        basedir.append(basedir_nodes.at(0)->getAttribute("path"));
        basedir_nodes.at(0)->setAttribute("path", basedir.c_str());
    }
    else
        error("SUMOTraCIScenarioManagerLaunchdV2::initialize: Multiple elements of basedir found.");

    cXMLElementList seed_nodes = launchConfig->getElementsByTagName("seed");
    if (seed_nodes.size() == 0) {
        if (seed == -1) {
            // default seed is current repetition
            const char* seed_s = cSimulation::getActiveSimulation()->getEnvir()->getConfigEx()->getVariable(CFGVAR_RUNNUMBER);
            seed = atoi(seed_s);
        }
        std::stringstream ss; ss << seed;
        cXMLElement* seed_node = new cXMLElement("seed", __FILE__, launchConfig);
        seed_node->setAttribute("value", ss.str().c_str());
        launchConfig->appendChild(seed_node);
    }
    SUMOTraCIScenarioManagerV2::initialize(stage);
}

void SUMOTraCIScenarioManagerLaunchdV2::finish()
{
    SUMOTraCIScenarioManagerV2::finish();
}

void SUMOTraCIScenarioManagerLaunchdV2::init_traci() {
    {
        std::pair<uint32_t, std::string> version = SUMOTraCIScenarioManagerV2::commandGetVersion();
        uint32_t apiVersion = version.first;
        std::string serverVersion = version.second;

        //ASSERT(apiVersion == 1);
        MYDEBUG << "TraCI launchd reports version \"" << serverVersion << "\"" << endl;
    }

    std::string contents = launchConfig->tostr(0);

    SUMOTraCIBufferV2 buf;
    buf << std::string("sumo-launchd.launch.xml") << contents;
    sendTraCIMessage(makeTraCICommand(CMD_FILE_SEND, buf));

    SUMOTraCIBufferV2 obuf(receiveTraCIMessage());
    uint8_t cmdLength; obuf >> cmdLength;
    uint8_t commandResp; obuf >> commandResp; if (commandResp != CMD_FILE_SEND) error("Expected response to command %d, but got one for command %d", CMD_FILE_SEND, commandResp);
    uint8_t result; obuf >> result;
    std::string description; obuf >> description;
    if (result != RTYPE_OK) {
        EV << "Warning: Received non-OK response from TraCI server to command " << CMD_FILE_SEND << ":" << description.c_str() << std::endl;
    }

    SUMOTraCIScenarioManagerV2::init_traci();
}


