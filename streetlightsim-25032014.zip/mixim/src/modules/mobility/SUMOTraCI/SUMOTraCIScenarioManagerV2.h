//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#ifndef __MIXIM_SUMOTRACISCENARIOMANAGERV2_H_
#define __MIXIM_SUMOTRACISCENARIOMANAGERV2_H_

#include <map>
#include <list>
#include <sstream>
#include <iomanip>

#include <omnetpp.h>

#include "Coord.h"
#include "BaseWorldUtility.h"
#include "BaseConnectionManager.h"
#include "FindModule.h"

#include <math.h>


/**
 * TODO - Generated class
 */
class SUMOTraCIScenarioManagerV2 : public cSimpleModule,  public cListener
{
    public:
        ~SUMOTraCIScenarioManagerV2();
        virtual int numInitStages() const { return std::max(cSimpleModule::numInitStages(), 2); }
        virtual void initialize(int stage);
        virtual void finish();
        virtual void handleMessage(cMessage *msg);
        virtual void handleSelfMsg(cMessage *msg);
        void receiveSignal(cComponent *source, simsignal_t signalID, long l );


        std::pair<uint32_t, std::string> commandGetVersion();
        void commandSetSpeedMode(std::string nodeId, int32_t bitset);
        void commandSetSpeed(std::string nodeId, double speed);
        void commandChangeRoute(std::string nodeId, std::string roadId, double travelTime);
        double commandDistanceRequest(Coord position1, Coord position2, bool returnDrivingDistance);
        void commandStopNode(std::string nodeId, std::string roadId, double pos, uint8_t laneid, double radius, double waittime);
        void commandSetTrafficLightProgram(std::string trafficLightId, std::string program);
        void commandSetTrafficLightPhaseIndex(std::string trafficLightId, int32_t index);
        std::list<std::string> commandGetPolygonIds();
        std::string commandGetPolygonTypeId(std::string polyId);
        std::list<Coord> commandGetPolygonShape(std::string polyId);
        void commandSetPolygonShape(std::string polyId, std::list<Coord> points);
        bool commandAddVehicle(std::string vehicleId, std::string vehicleTypeId, std::string routeId, std::string laneId, float emitPosition, float emitSpeed);

        enum roadUserInsertionMode {
            FIX_LOCATION = 0,
            RANDOM_LOCATION = 1,
        };
        roadUserInsertionMode RUInsertionMode;
        const std::map<std::string, cModule*>& getManagedHosts() {

            return hosts;
        }

        int getCurrentTotalActiveHost(){
            return intCurrentTotalActiveHost;
        }

        const std::map<std::string, cModule*>* getManagedHostsPointer() {
                    return &hosts;
                }

        const std::map<std::string, cModule*>* getManagedLamppostPointer()
        {
            return &poleHosts;
        }

    protected:
        //delay duration is for path discovery at network layer
        int intTrafficModeDelay;
        int intNetwDiscoveryDuration;

        /* 03/05/2012 LSP **/
        simsignal_t activeMobileNodeSignal;
        //simsignal_t noMobileNodeSignal;
        simsignal_t whichRouteTakenSignal;
        simsignal_t errorAddVehicleCountSignal;
        simsignal_t totalRoadUserByTimeStepSignal;

        simsignal_t totalMotoristSignal;
        simsignal_t totalCyclistSignal;
        simsignal_t totalPedestrianSignal;

        simsignal_t totalLamppostSignal;

        /* 24/06/2013 LSP */
        simsignal_t triggerTrafficModelSignal;
        bool boolTrafficModelDelayEnd;

        /*
         * For determine the end of the path discovery period
         */
        cMessage* msgTrafficModeDelayEnd;

        int intCollectTotalRoadUserByTimeStep;
        int intCurrentTotalActiveHost;
        /**
         * Coord equivalent for storing TraCI coordinates
         */

        /*
         * 22/04/2013 -LSP
         * To record total amount of pedestrian and other motorists (include cyclists)
         */
        int intTotalPedestrian;
        int intTotalCyclist;
        int intTotalMotorist;

        int trafficFromHour;

        int intTotalPedestrianByTimeStep;
        int intTotalCyclistByTimeStep;
        int intTotalMotoristByTimeStep;
        int intTestRoute;
        struct TraCICoord {
            TraCICoord() : x(0), y(0) {}
            TraCICoord(double x, double y) : x(x), y(y) {}
            double x;
            double y;
        };

        /**
         * Byte-buffer that stores values in TraCI byte-order
         */
        class SUMOTraCIBufferV2 {
            public:
            SUMOTraCIBufferV2() : buf() {
                    buf_index = 0;
                }

            SUMOTraCIBufferV2(std::string buf) : buf(buf) {
                    buf_index = 0;
                }

                template<typename T> T read() {
                    T buf_to_return;
                    unsigned char *p_buf_to_return = reinterpret_cast<unsigned char*>(&buf_to_return);

                    if (isBigEndian()) {
                        for (size_t i=0; i<sizeof(buf_to_return); ++i) {
                            if (eof()) throw cRuntimeError("Attempted to read past end of byte buffer");
                            p_buf_to_return[i] = buf[buf_index++];
                        }
                    } else {
                        for (size_t i=0; i<sizeof(buf_to_return); ++i) {
                            if (eof()) throw cRuntimeError("Attempted to read past end of byte buffer");
                            p_buf_to_return[sizeof(buf_to_return)-1-i] = buf[buf_index++];
                        }
                    }

                    return buf_to_return;
                }

                template<typename T> void write(T inv) {
                    unsigned char *p_buf_to_send = reinterpret_cast<unsigned char*>(&inv);

                    if (isBigEndian()) {
                        for (size_t i=0; i<sizeof(inv); ++i) {
                            buf += p_buf_to_send[i];
                        }
                    } else {
                        for (size_t i=0; i<sizeof(inv); ++i) {
                            buf += p_buf_to_send[sizeof(inv)-1-i];
                        }
                    }
                }

                template<typename T> T read(T& out) {
                    out = read<T>();
                    return out;
                }

                template<typename T> SUMOTraCIBufferV2& operator >>(T& out) {
                    out = read<T>();
                    return *this;
                }

                template<typename T> SUMOTraCIBufferV2& operator <<(const T& inv) {
                    write(inv);
                    return *this;
                }

                bool eof() const {
                    return buf_index == buf.length();
                }

                void set(std::string buf) {
                    this->buf = buf;
                    buf_index = 0;
                }

                void clear() {
                    set("");
                }

                std::string str() const {
                    return buf;
                }

                std::string hexStr() const {
                    std::stringstream ss;
                    for (std::string::const_iterator i = buf.begin() + buf_index; i != buf.end(); ++i) {
                        if (i != buf.begin()) ss << " ";
                        ss << std::hex << std::setw(2) << std::setfill('0') << (int)(uint8_t)*i;
                    }
                    return ss.str();
                }

            protected:
                bool isBigEndian() {
                    short a = 0x0102;
                    unsigned char *p_a = reinterpret_cast<unsigned char*>(&a);
                    return (p_a[0] == 0x01);
                }

                std::string buf;
                size_t buf_index;
        };

        bool debug; /**< whether to emit debug messages */
        simtime_t updateInterval; /**< time interval to update the host's position */
        std::string moduleType; /**< module type to be used in the simulation for each managed vehicle */
        std::string moduleName; /**< module name to be used in the simulation for each managed vehicle */
        std::string moduleDisplayString; /**< module displayString to be used in the simulation for each managed vehicle */

        std::string poleModuleDisplayString; /**< Pole module displayString to be used in the simulation for each managed street Lamp -- LSP 03/04/2012 */
        std::string poleModuleType; /**< Pole module type*/
        std::string poleModuleName; /**< The common name for pole*/
        std::string host;
        /*15/05/2012 LSP
         * Used to debug appearance of the additional vehicle after t time
         ***/
        uint32_t previousCount;

        int port;
        bool autoShutdown; /**< Shutdown module as soon as no more vehicles are in the simulation */
        int margin;
        std::list<std::string> roiRoads; /**< which roads (e.g. "hwy1 hwy2") are considered to consitute the region of interest, if not empty */
        std::list<std::pair<TraCICoord, TraCICoord> > roiRects; /**< which rectangles (e.g. "0,0-10,10 20,20-30,30) are considered to consitute the region of interest, if not empty */

        void* socketPtr;
        TraCICoord netbounds1; /* network boundaries as reported by TraCI (x1, y1) */
        TraCICoord netbounds2; /* network boundaries as reported by TraCI (x2, y2) */

        size_t nextNodeVectorIndex; /**< next OMNeT++ module vector index to use */
        size_t nextPoleVectorIndex; /** for next OMNett ++ pole module vector index to use -- 03/04/2012 -LSP*/

        std::map<std::string, cModule*> hosts; /**< vector of all hosts managed by us */
        std::map<std::string, cModule*> poleHosts; /**< vector of all Pole hosts managed by us -- 03/04/2012 - LSP */

        std::set<std::string> subscribedVehicles; /**< all vehicles we have already subscribed to */
        uint32_t activeVehicleCount; /**< number of vehicles reported as active by TraCI server */
        bool autoShutdownTriggered;
        cMessage* executeOneTimestepTrigger; /**< self-message scheduled for when to next call executeOneTimestep */

        BaseWorldUtility* world;
        BaseConnectionManager* cc;

        uint32_t getCurrentTimeMs(); /**< get current simulation time (in ms) */

        void executeOneTimestep(); /**< read and execute all commands for the next timestep */

        void connect();
        virtual void init_traci();

        void addModule(std::string nodeId, std::string type, std::string strRoadUserType, std::string name, std::string displayString, const Coord& position, std::string road_id = "", double speed = -1, double angle = -1, std::string route_Id = "");
        void addModulePole(std::string nodeId, std::string type, std::string name, std::string displayString, const Coord& position);
        cModule* getManagedModule(std::string nodeId); /**< returns a pointer to the managed module named moduleName, or 0 if no module can be found */
        void deleteModule(std::string nodeId);

        //LSP 20/04/2012 for delete the Pole module
        cModule* getManagedPoleModule(std::string nodeId);
        void deletePoleModule(std::string nodeId);
        /**
         * LSP 17/05/2012
         * load the network route into the simulation
         * */
        cXMLElement* xmlNetworkRoute;
        std::map<std::string, std::string> mapNetworkRoute, mapNetworkRouteType, mapVType;


        /*
         * LSP 21/05/2012
         * For generate different traffic based on average vehicle per hour
         * */
         //int intAvgVehPerHour;
        int intTrafficFlow;

        /*
         * LSP 22/04/2013
         * Used to define the proportion of pedestrian based on traffic flow
         */
        double dblPedestrianPercentange;
        double dblCyclistPercentange;
         /*
          * LSP 12/07/2012
          * To define constant vehicle constant speed
          */
        double intVehicleConstantSpeed;

        /*
         * LSP - 13/08/2012
         * To determine which test setting to be used in the model
         * 1 - based on traffic volume and traffic profile
         * 2 - based on constant speed
         */
        int intWhichTestSetting;

        void loadNetworkRoute(cXMLElement*  route_file);
        /*
         * LSP 17/05/2012
         * generateTraffic() - for testing purpose only!
         */
        void generateTraffic();
        void generateTrafficBasedOnTime();
        /*
         *  LSP 17/05/2012
         * For loading the traffic profile
         * */
        std::map<int,int> mapTrafficProfile;

        bool isTimeToAddVehicle;
        int timeToAddVehicleCount;
        int intPreCurTrafficProfileTimeStep;
        /*
         *  LSP 11/04/2013
         *  Used to cater AADT value
         */
        double dblTrafficRatioPerDay;

        /*
         * LSP 27/04/2013
         * Used to randomly generate traffic into simulation
         */
        int intTotalRandomGenerateTraffic;
        int intCountNoTrafficInjection;

        cXMLElement* xmlTrafficProfile;
        void loadTrafficProfile(cXMLElement* traffic_file);

        /*
         * LSP 12/07/2012
         * To hardcode the total number of vehicle in simulation
         * only for verification purpose
         */
       int intNFVehicleforVerification;
       double previoustimeToAddVehicle;
       double dblTimeBtwCars;



        /**
         * returns whether a given position lies within the simulation's region of interest.
         * Modules are destroyed and re-created as managed vehicles leave and re-enter the ROI
         */
        bool isInRegionOfInterest(const TraCICoord& position, std::string road_id, double speed, double angle);

        /**
         * sends a single command via TraCI, checks status response, returns additional responses
         */
        SUMOTraCIBufferV2 queryTraCI(uint8_t commandId, const SUMOTraCIBufferV2& buf = SUMOTraCIBufferV2());

        /**
         * sends a single command via TraCI, expects no reply, returns true if successful
         */
        SUMOTraCIScenarioManagerV2::SUMOTraCIBufferV2 queryTraCIOptional(uint8_t commandId, const SUMOTraCIBufferV2& buf, bool& success, std::string* errorMsg = 0);

        /**
         * returns byte-buffer containing a TraCI command with optional parameters
         */
        std::string makeTraCICommand(uint8_t commandId, SUMOTraCIBufferV2 buf = SUMOTraCIBufferV2());

        /**
         * sends a message via TraCI (after adding the header)
         */
        void sendTraCIMessage(std::string buf);

        /**
         * receives a message via TraCI (and strips the header)
         */
        std::string receiveTraCIMessage();

        /**
         * convert TraCI coordinates to OMNeT++ coordinates
         */
        Coord traci2omnet(TraCICoord coord) const;

        /**
         * convert OMNeT++ coordinates to TraCI coordinates
         */
        TraCICoord omnet2traci(Coord coord) const;

        /**
         * convert TraCI angle to OMNeT++ angle (in rad)
         */
        double traci2omnetAngle(double angle) const;

        /**
         * convert OMNeT++ angle (in rad) to TraCI angle
         */
        double omnet2traciAngle(double angle) const;

        void subscribeToVehicleVariables(std::string vehicleId);
        void unsubscribeFromVehicleVariables(std::string vehicleId);
        void processSimSubscription(std::string objectId, SUMOTraCIBufferV2& buf);
        void processVehicleSubscription(std::string objectId, SUMOTraCIBufferV2& buf);
        void processSubcriptionResult(SUMOTraCIBufferV2& buf);
};
template<> std::string SUMOTraCIScenarioManagerV2::SUMOTraCIBufferV2::read();
template<> void SUMOTraCIScenarioManagerV2::SUMOTraCIBufferV2::write(std::string inv);


class SUMOTraCIScenarioManagerV2Access
{
    public:
        SUMOTraCIScenarioManagerV2* get() {
            return FindModule<SUMOTraCIScenarioManagerV2*>::findGlobalModule();
        };
};

#endif
