//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 
#include <limits>
#include <iostream>
#include <sstream>
#include <math.h>
#include "StreetlightApplLayer.h"
#include "mobility/SUMOTraCI/SUMOTraCIMobilityV2.h"
#include "StreetlightApplLayer.h"
Define_Module(SUMOTraCIMobilityV2);

namespace {
    const double MY_INFINITY = (std::numeric_limits<double>::has_infinity ? std::numeric_limits<double>::infinity() : std::numeric_limits<double>::max());

    double roadIdAsDouble(std::string road_id) {
        std::istringstream iss(road_id);
        double d;
        if (!(iss >> d)) return MY_INFINITY;
        return d;
    }
}

void SUMOTraCIMobilityV2::Statistics::initialize()
{
    firstRoadNumber = MY_INFINITY;
    startTime = simTime();
    totalTime = 0;
    stopTime = 0;
    minSpeed = MY_INFINITY;
    maxSpeed = -MY_INFINITY;
    totalDistance = 0;
    totalCO2Emission = 0;
    /*
     * 11/02/2013 LSP
     * add totalUtility
     */
    totalUtility = 0;
    averageSpeed = 0;
    countCollectedSpeed = 0;
}

void SUMOTraCIMobilityV2::Statistics::watch(cSimpleModule& )
{
    WATCH(totalTime);
    WATCH(minSpeed);
    WATCH(maxSpeed);
    WATCH(totalDistance);
}

void SUMOTraCIMobilityV2::Statistics::recordScalars(cSimpleModule& module)
{
    if (firstRoadNumber != MY_INFINITY) module.recordScalar("firstRoadNumber", firstRoadNumber);
    module.recordScalar("startTime", startTime);
    module.recordScalar("totalTime", totalTime);
    module.recordScalar("stopTime", stopTime);
    module.recordScalar("duration", (stopTime-startTime));
    if (minSpeed != MY_INFINITY) module.recordScalar("minSpeed", minSpeed);
    if (maxSpeed != -MY_INFINITY) module.recordScalar("maxSpeed", maxSpeed);
    module.recordScalar("totalDistance", totalDistance);
    module.recordScalar("totalCO2Emission", totalCO2Emission);
    module.recordScalar("totalUtility",totalUtility);
    module.recordScalar("averageSpeed",averageSpeed);
}

void SUMOTraCIMobilityV2::initialize(int stage)
{
    if (stage == 0)
    {
        BaseMobility::initialize(stage);

        debug = par("debug");
        accidentCount = par("accidentCount");

        dblViewDepht = par("dblViewDepht");
        dblViewDepthConeNearRadius = par("dblViewDepthConeNearRadius");
        dblViewDepthConeFarRadius = par("dblViewDepthConeFarRadius");
        drawRoadUserViewField = par("drawRoadUserViewField");
        dblMinVisibleDistanceBasedOnVL = par("dblMinVisibleDistanceBasedOnVL").doubleValue();
        intCollectUtilityByTimeStep = par("collectUtilityByTimeStep");
        intUtilityCount = 0;

        dblTotalCollectedUtilitybyTimeStep = 0;

        intMaxTTFF = par("maxGPS_TTFF");
        dblGPS_TTFF = intuniform(1,intMaxTTFF,0 );

        /*
         * 11/03/2013 -LSP
         * Used to compute stopping distance for streetlight utility computation
         *
         * This model has been updated, stopping distance is not longger used in streetlight utility computation
         */

        dblDriverReactionDelay = par("dblDriverReactionDelay").doubleValue();
        dblFrictionCoefficient = par("dblFrictionCoefficient").doubleValue();
        dblGravity = par("dblGravity").doubleValue();

        /*
         * 01/08/2012
         * Following information is not used for StreetlightSim
         */

        //currentPosXVec.setName("posx");
        //currentPosYVec.setName("posy");
        //currentSpeedVec.setName("speed");
        //currentAccelerationVec.setName("acceleration");
        //currentCO2EmissionVec.setName("co2emission");
        statistics.initialize();
        statistics.watch(*this);

        ASSERT(isPreInitialized);
        isPreInitialized = false;

        move.setStart(Coord(nextPos.x, nextPos.y, move.getCurrentPosition().z)); // keep z position
        move.setDirectionByVector(Coord(cos(angle), -sin(angle)));
        move.setSpeed(speed);

        WATCH(road_id);
        WATCH(speed);
        WATCH(angle);

        startAccidentMsg = 0;
        stopAccidentMsg = 0;
        manager = 0;
        last_speed = -1;

        if (accidentCount > 0) {
            simtime_t accidentStart = par("accidentStart");
            startAccidentMsg = new cMessage("scheduledAccident");
            stopAccidentMsg = new cMessage("scheduledAccidentResolved");
            scheduleAt(simTime() + accidentStart, startAccidentMsg);
        }

        /*
         * 12/07/2012 LSP
         * To record actual signal after signalling
         */
        recordActualMobileNodeCoodinateSignal = registerSignal("recordActualMobileNodeCoodinate");
        simulation.getSystemModule()->subscribe(recordActualMobileNodeCoodinateSignal,this);
        mobileNodeCoodinate_X_Signal = registerSignal("AfterSignal_Pos_X");
        mobileNodeCoodinate_Y_Signal = registerSignal("AfterSignal_Pos_Y");

        /**
         * 06/02/2012 LSP
         * check for first draw of the view field
         */
        isFirstViewField = true;
        lastUpdateViewFieldMaxDistance = simTime();

        /*
         * 11/02/2013 LSP
         * To record the maximum target detection distance
         */
        recordStreetLightUtilitySignal = registerSignal("recordStreetLightUtility");
        recordDimPercentageSignal = registerSignal("recordDimPercentage");
        recordTotalUtilitySignal = registerSignal("recordTotalUtility");
        recordRoadUserTypeSignal = registerSignal("recordRoadUserType");
        dblTotalUtility = 0;

        dblAvgStreetligthBeamWidth = 0.0;

        /*
         * 07/05/2013 LSP
         * To trigger streetlight utility computation
         */
        //computeStreetlightUtilitySignal = registerSignal("computeStreetlightUtility");
        //simulation.getSystemModule()->subscribe(computeStreetlightUtilitySignal,this);
        //intCountComputeUtilitySignal = 0;

        dblComputeUtilityDuration = 1/par("computeUtilityDuration").doubleValue();
        dblAverageLightSpan = par("averageLightSpan");

        computeStreetlightUtilityMsg = new cMessage("computeStreetlightUtilityMsg");
        scheduleAt(simTime(), computeStreetlightUtilityMsg);
    }
    else if (stage == 1)
    {
        // don't call BaseMobility::initialize(stage) -- our parent will take care to call changePosition later

        /*
         * 05/02/2012 LSP
         * annotation initialisation
         */
        isNormalEraseViewField = false;
        annotations = AnnotationManagerAccess().getIfExists();
        viewFieldGroupIdFront = static_cast<std::ostringstream*>( &(std::ostringstream() << getId()))->str();
        viewFieldGroupIdFront.append("-Front");
        viewFieldGroupIdRear = static_cast<std::ostringstream*>( &(std::ostringstream() << getId()))->str();
        viewFieldGroupIdRear.append("-Rear");

        //ev<<"SUMOTraCIMobilityV2::initialize:viewFieldGroupIdFront:"<<viewFieldGroupIdFront<<endl;
        //ev<<"SUMOTraCIMobilityV2::initialize:viewFieldGroupIdRear:"<<viewFieldGroupIdRear<<endl;


        if (annotations && drawRoadUserViewField)
        {
            preViewerFront = NULL;
            viewerFront = NULL;
            preViewerRear = NULL;
            viewerRear = NULL;

            annotationGroupFront = annotations->createGroup( viewFieldGroupIdFront );
            annotationGroupRear = annotations->createGroup( viewFieldGroupIdFront );
        }
    }
    else
    {
        BaseMobility::initialize(stage);
    }
}

void SUMOTraCIMobilityV2::finish()
{
    statistics.averageSpeed = statistics.averageSpeed/statistics.countCollectedSpeed;

    statistics.stopTime = simTime();
    /*
     * 13/03/2013 - LSP
     * Only emit the utility if there are streetlights in the view field.
     */
    if (intUtilityCount > 0)
    {
        //statistics.totalUtility = statistics.totalUtility/intUtilityCount;
        //emit(recordTotalUtilitySignal, statistics.totalUtility);

        //only emit the remaining utility value based on period of it is recorded.
        int intRemainingStep = intUtilityCount % intCollectUtilityByTimeStep;
        statistics.totalUtility = statistics.totalUtility/(double)intUtilityCount;

        if(intRemainingStep > 0 && intCollectUtilityByTimeStep > 0)
            emit(recordTotalUtilitySignal,dblTotalCollectedUtilitybyTimeStep/intRemainingStep);

        /*
        if(this->intUserType == MOTORIST)
            emit(recordRoadUserTypeSignal,MOTORIST);
        if(this->intUserType == CYCLIST)
            emit(recordRoadUserTypeSignal,CYCLIST);
        if(this->intUserType == PEDESTRIAN)
            emit(recordRoadUserTypeSignal,PEDESTRIAN);
        */
        recordScalar("RoadUserType",this->intUserType);
    }
    else
        statistics.totalUtility = -1;

    statistics.recordScalars(*this);

    cancelAndDelete(startAccidentMsg);
    cancelAndDelete(stopAccidentMsg);

    recordScalar("RouteId", atoi(this->strRoute_Id.c_str()));
    isPreInitialized = false;

    /*
     * 12/07/2012 LSP
     * unsubscribe the signal after signalling
     */
    simulation.getSystemModule()->unsubscribe(recordActualMobileNodeCoodinateSignal,this);
    //simulation.getSystemModule()->unsubscribe(computeStreetlightUtilitySignal,this);

    if(annotations && drawRoadUserViewField)
    {
        /*
         * 08/03/2013 LSP
         * Try to create some dummy Polygon for visual field before deleting them
         * Why - Try to avoid runtime access which may caused by accessing NULL pointers.
         */
        //viewerFront  = annotations->drawPolygon(visualFieldFront, "red", annotationGroupFront);
        //viewerRear  = annotations->drawPolygon(visualFieldRear, "red", annotationGroupRear);
        annotations->erase(viewerFront) ;
        annotations->erase(viewerRear) ;
    }
}

void SUMOTraCIMobilityV2::receiveSignal(cComponent *source, simsignal_t signalID, long signalData )
{
    if(signalID ==recordActualMobileNodeCoodinateSignal)
    {
       /*
        * To record the actual mobile coordinate after everyone have move
        */
       emit(mobileNodeCoodinate_X_Signal,nextPos.x );
       emit(mobileNodeCoodinate_Y_Signal,nextPos.y);
    }
}

void SUMOTraCIMobilityV2::computeStreetlightUtilityOfPedestrianFront()
{
    {
        /*
         * Check the FIRST streetlight of the rear view to check whether its beam pattern
         * covers the rear utility
         */
        std::map<double,double>::iterator it = mapCollectedPoleInfoDistance.begin();
        std::map<double,double>::iterator itCheck;
        std::map<double, double>:: iterator itMapUtility;

        double dblLightSpanStartPoint = -1000;
        double dblLightSpanEndPoint = -1000;
        double dblLightSpanStartPoint2 = -1000;
        double dblLightSpanEndPoint2 = -1000;

        double dblLightSpanStartMaxPoint = 0;
        double dblLightSpanEndMaxPoint = 0;

        double dblLightBrightness = 0;
        //double dblMaxSSDBasedOnViewField = 0;
        //double dblViewFieldStartPoint = 1000;


        //to store the actual values used for utility computation
        std::map<double,double> mapStreetLightUtilityDistance;
        std::map<double,double> mapStreetLightUtilityBrightness;

        for(it=mapCollectedPoleInfoRearView.begin(); it != mapCollectedPoleInfoRearView.end(); it++)
        {
            double dblTmpLightSpanStartPoint = (it->first - (dblAvgStreetligthBeamWidth/2) );
            double dblTmpLightSpanEndtPoint = (dblAvgStreetligthBeamWidth/2) - it->first;


            if(dblTmpLightSpanStartPoint < 0 )
            {
                dblLightSpanStartPoint = 0;
                dblLightSpanEndPoint = dblTmpLightSpanEndtPoint;
            }

            if(mapCollectedPoleInfoBrightness.find(it->second) == mapCollectedPoleInfoBrightness.end())
                opp_warning("error : computeStreetlightUtilityOfPedestrianFront::calStreetLightUtilityOfRoadUser: Brightness");
            dblLightBrightness = mapCollectedPoleInfoBrightness.find(it->second)->second;

            if( dblLightSpanStartPoint < dblLightSpanStartMaxPoint)
                dblLightSpanStartMaxPoint = dblLightSpanStartPoint;
            if( dblLightSpanEndPoint > dblLightSpanEndMaxPoint)
                dblLightSpanEndMaxPoint = dblLightSpanEndPoint;


            if(dblLightSpanStartPoint != -1000 && dblLightSpanEndPoint != -1000)
            {
                mapStreetLightUtilityDistance.insert(std::pair<double, double> (dblLightSpanStartPoint,dblLightSpanEndPoint));
                mapStreetLightUtilityBrightness.insert(std::pair<double, double>(dblLightSpanStartPoint, dblLightBrightness));
            }

            if(dblLightSpanStartPoint2 != -1000 && dblLightSpanEndPoint2 != -1000)
            {
                mapStreetLightUtilityDistance.insert(std::pair<double, double> (dblLightSpanStartPoint2,dblLightSpanEndPoint2));
                mapStreetLightUtilityBrightness.insert(std::pair<double, double>(dblLightSpanStartPoint2, dblLightBrightness));
            }
            break;
        }

        for(it=mapCollectedPoleInfoFrontView.begin(); it != mapCollectedPoleInfoFrontView.end(); it++)
        {
            dblLightBrightness = mapCollectedPoleInfoBrightness.find(it->second)->second;

            if (mapStreetLightUtilityDistance.empty())
            {
                if(it->first - (dblAvgStreetligthBeamWidth/2) < 0)
                    dblLightSpanStartPoint = 0;
                else
                    if(it->first - (dblAvgStreetligthBeamWidth/2) < dblUtiltyDistance)
                        dblLightSpanStartPoint = (dblAvgStreetligthBeamWidth/2) - it->first;
                    else
                        dblLightSpanStartPoint = dblUtiltyDistance;

                if (it->first + (dblAvgStreetligthBeamWidth/2) > dblUtiltyDistance)
                    dblLightSpanEndPoint = dblUtiltyDistance;
                else
                    dblLightSpanEndPoint = it->first + (dblAvgStreetligthBeamWidth/2);
            }
            else
            {
              for(itMapUtility = mapStreetLightUtilityDistance.begin(); itMapUtility != mapStreetLightUtilityDistance.end(); itMapUtility++)
              {
                  //ev<<"(Comparing with utility list) Lamp["<<it->second<<"]'s brightness level is "<< mapCollectedPoleInfoBrightness.find(it->second)->second <<" vs "<<mapStreetLightUtilityBrightness.find(itMapUtility->first)->second<<endl;
                  //ev<<" mapStreetLightUtilityBrightness.size :"<< mapStreetLightUtilityBrightness.size()<<", itMapUtiltiiy->first : "<< itMapUtility->first<<endl;
                  if(itMapUtility->first == itMapUtility->second)
                      continue;

                  if(mapCollectedPoleInfoBrightness.find(it->second)->second > mapStreetLightUtilityBrightness.find(itMapUtility->first)->second)
                  {
                      /*
                       *  scenario (2)
                       */
                      if(it->first - (dblAvgStreetligthBeamWidth/2) >= itMapUtility->second && it->first - (dblAvgStreetligthBeamWidth/2) > itMapUtility->first &&
                          it->first + (dblAvgStreetligthBeamWidth/2) > itMapUtility->second && it->first + (dblAvgStreetligthBeamWidth/2) > itMapUtility->first)
                      {
                          if((itMapUtility) == mapStreetLightUtilityDistance.end() )
                          {
                              itMapUtility->second = it->first - (dblAvgStreetligthBeamWidth/2);
                          }

                          dblLightSpanStartPoint = it->first - (dblAvgStreetligthBeamWidth/2);

                          if (it->first + (dblAvgStreetligthBeamWidth/2) > dblUtiltyDistance)
                              dblLightSpanEndPoint = dblUtiltyDistance;
                          else
                              dblLightSpanEndPoint = it->first + (dblAvgStreetligthBeamWidth/2);

                          dblLightSpanStartPoint2 = -1000;
                          dblLightSpanEndPoint2 = -1000;
                      }

                      /*
                       * scenario (3)
                       */
                      if(it->first - (dblAvgStreetligthBeamWidth/2) < itMapUtility->second && it->first - (dblAvgStreetligthBeamWidth/2) >= itMapUtility->first &&
                              it->first + (dblAvgStreetligthBeamWidth/2) > itMapUtility->second && it->first + (dblAvgStreetligthBeamWidth/2) > itMapUtility->first)
                      {
                          itMapUtility->second=it->first - (dblAvgStreetligthBeamWidth/2);

                          dblLightSpanStartPoint = it->first - (dblAvgStreetligthBeamWidth/2);
                          if (it->first + (dblAvgStreetligthBeamWidth/2) > dblUtiltyDistance)
                              dblLightSpanEndPoint = dblUtiltyDistance;
                          else
                              dblLightSpanEndPoint = it->first + (dblAvgStreetligthBeamWidth/2);

                          dblLightSpanStartPoint2 = -1000;
                          dblLightSpanEndPoint2 = -1000;
                      }

                      /*
                       * scenario (4)
                       */
                      if(it->first -(dblAvgStreetligthBeamWidth/2) <= itMapUtility->first && it->first -(dblAvgStreetligthBeamWidth/2) < itMapUtility->second &&
                              it->first + (dblAvgStreetligthBeamWidth/2) > itMapUtility->first && it->first + (dblAvgStreetligthBeamWidth/2) >= itMapUtility->second)
                      {
                          /*
                           * After erase the map, the for loop will check it again
                           */
                          mapStreetLightUtilityDistance.erase(itMapUtility->first);
                          mapStreetLightUtilityBrightness.erase(itMapUtility->first);

                          if(it->first - (dblAvgStreetligthBeamWidth/2) < 0)
                              dblLightSpanStartPoint = 0;
                          else
                              dblLightSpanStartPoint = it->first - (dblAvgStreetligthBeamWidth/2);

                          if(it->first + (dblAvgStreetligthBeamWidth/2) > dblUtiltyDistance)
                              dblLightSpanEndPoint = dblUtiltyDistance;
                          else
                              dblLightSpanEndPoint= it->first + (dblAvgStreetligthBeamWidth/2) ;

                          dblLightSpanStartPoint2 = -1000;
                          dblLightSpanEndPoint2 = -1000;
                      }
                  }
                  else
                  {
                      /*
                       * scenario (5)
                       */
                      if(it->first - (dblAvgStreetligthBeamWidth/2) >= itMapUtility->second && it->first - (dblAvgStreetligthBeamWidth/2) > itMapUtility->first &&
                              it->first + (dblAvgStreetligthBeamWidth/2) > itMapUtility-> second && it->first + (dblAvgStreetligthBeamWidth/2) >= itMapUtility-> first)
                      {
                          dblLightSpanStartPoint = it->first - (dblAvgStreetligthBeamWidth/2);
                          if (it->first + (dblAvgStreetligthBeamWidth/2) > dblUtiltyDistance)
                              dblLightSpanEndPoint = dblUtiltyDistance;
                          else
                              dblLightSpanEndPoint = it->first + (dblAvgStreetligthBeamWidth/2);

                          dblLightSpanStartPoint2 = -1000;
                          dblLightSpanEndPoint2 = -1000;
                      }

                      /*
                       * scenario (6-1)
                       */
                      if(it->first - (dblAvgStreetligthBeamWidth/2) < itMapUtility->second && it->first - (dblAvgStreetligthBeamWidth/2)> itMapUtility->first &&
                             it->first + (dblAvgStreetligthBeamWidth/2) > itMapUtility->first &&  it->first + (dblAvgStreetligthBeamWidth/2) > itMapUtility-> second)
                      {
                         dblLightSpanStartPoint = itMapUtility->second;

                         if (it->first + (dblAvgStreetligthBeamWidth/2) > dblUtiltyDistance)
                             dblLightSpanEndPoint = dblUtiltyDistance;
                         else
                             dblLightSpanEndPoint = it->first + (dblAvgStreetligthBeamWidth/2);

                         dblLightSpanStartPoint2 = -1000;
                         dblLightSpanEndPoint2 = -1000;
                      }

                      /*
                       * scenario (6-2)
                       */
                      if(it->first - (dblAvgStreetligthBeamWidth/2) < itMapUtility->first && it->first - (dblAvgStreetligthBeamWidth/2)> itMapUtility->second &&
                              it->first + (dblAvgStreetligthBeamWidth/2) > itMapUtility-> first &&  it->first + (dblAvgStreetligthBeamWidth/2) < itMapUtility-> second)
                      {
                          dblLightSpanStartPoint = -1000;
                          dblLightSpanEndPoint = -1000;
                          dblLightSpanStartPoint2 = -1000;
                          dblLightSpanEndPoint2 = -1000;
                      }

                      /*
                       * scenario (7)
                       */
                      if(it->first - (dblAvgStreetligthBeamWidth/2) <= itMapUtility->first && it->first - (dblAvgStreetligthBeamWidth/2) <= itMapUtility->second &&
                              it->first + (dblAvgStreetligthBeamWidth/2) >= itMapUtility-> first && it->first + (dblAvgStreetligthBeamWidth/2) >= itMapUtility->second)
                      {
                          if (mapCollectedPoleInfoBrightness.find(it->second)->second == mapStreetLightUtilityBrightness.find(itMapUtility->first)->second)
                          {
                              dblLightSpanStartPoint = itMapUtility->second;
                              if (it->first + (dblAvgStreetligthBeamWidth/2) > dblUtiltyDistance)
                                  dblLightSpanEndPoint = dblUtiltyDistance;
                              else
                                  dblLightSpanEndPoint = it->first + (dblAvgStreetligthBeamWidth/2);

                              mapCollectedPoleInfoDistance.erase(itMapUtility->first);

                          }
                          else if (mapCollectedPoleInfoBrightness.find(it->second)->second < mapStreetLightUtilityBrightness.find(itMapUtility->first)->second)
                          {
                              dblLightSpanStartPoint = it->first - (dblAvgStreetligthBeamWidth/2);
                              dblLightSpanEndPoint = itMapUtility->first;
                              for(itCheck = mapStreetLightUtilityDistance.begin(); itCheck != mapStreetLightUtilityDistance.end(); itCheck++)
                              {
                                  //check for inclusion
                                  if(itCheck->first<=dblLightSpanStartPoint &&
                                          itCheck->second>= dblLightSpanEndPoint)
                                  {
                                      if(mapStreetLightUtilityBrightness.find(itCheck->first)->second > dblLightBrightness)
                                      {
                                          dblLightSpanStartPoint = -1000;
                                          dblLightSpanEndPoint = -1000;
                                      }
                                      else
                                      {

                                      }

                                      break;
                                  }
                              }

                              dblLightSpanStartPoint2 = itMapUtility->second;;
                              if (it->first + (dblAvgStreetligthBeamWidth/2) > dblUtiltyDistance)
                                  dblLightSpanEndPoint2 = dblUtiltyDistance;
                              else
                                  dblLightSpanEndPoint2 = it->first + (dblAvgStreetligthBeamWidth/2);
                          }
                      }
                  }
              }
            }
            if( dblLightSpanStartPoint < dblLightSpanStartMaxPoint)
                dblLightSpanStartMaxPoint = dblLightSpanStartPoint;
            if( dblLightSpanEndPoint > dblLightSpanEndMaxPoint)
                dblLightSpanEndMaxPoint = dblLightSpanEndPoint;

            if(dblLightSpanStartPoint != -1000 && dblLightSpanEndPoint != -1000)
            {
                mapStreetLightUtilityDistance.insert(std::pair<double, double> (dblLightSpanStartPoint,dblLightSpanEndPoint));
                mapStreetLightUtilityBrightness.insert(std::pair<double, double>(dblLightSpanStartPoint, dblLightBrightness));
                //ev<<"Debug : scenario (20-1) SUMOTraCIMobilityV2::computeStreetlightUtilityOfPedestrianFront. dblLightSpanStartPoint : "<< dblLightSpanStartPoint <<", dblLightSpanEndPoint : "<<dblLightSpanEndPoint<<", dblLightBrightness : "<<dblLightBrightness<< ", dblUtiltyDistance "<<dblUtiltyDistance<<endl;
            }

            if(dblLightSpanStartPoint2 != -1000 && dblLightSpanEndPoint2 != -1000)
            {
                mapStreetLightUtilityDistance.insert(std::pair<double, double> (dblLightSpanStartPoint2,dblLightSpanEndPoint2));
                mapStreetLightUtilityBrightness.insert(std::pair<double, double>(dblLightSpanStartPoint2, dblLightBrightness));
                //ev<<"Debug : scenario (20-2) SUMOTraCIMobilityV2::computeStreetlightUtilityOfPedestrianFront. dblLightSpanStartPoint : "<< dblLightSpanStartPoint <<", dblLightSpanEndPoint : "<<dblLightSpanEndPoint<<", dblLightBrightness : "<<dblLightBrightness<< ", dblUtiltyDistance "<<dblUtiltyDistance<<endl;
            }
        }

        /*
         * Streetlight utility for pedestrian.
         * The computation of streetlight utility for pedestrian is different from car.
         */

//        double dblUtilityProspectRearStartPoint = 0 ;
//        double dblUtilityProspectRearEndPoint = 0 ;
        double dblUtilityProspectFrontStartPoint = 0 ;
        double dblUtilityProspectFrontEndPoint = 0 ;
        double dblUtilityAvoidStartPoint = 0;
        double dblUtilityAvoidEndPoint = 0;

        dblTotalUtility = 0;
        for (it=mapStreetLightUtilityDistance.begin(); it!=mapStreetLightUtilityDistance.end(); it++)
        {
            //to remove those with same starting and ending position pair
            if(it->first == it->second)
            {
                mapStreetLightUtilityDistance.erase(it->first);
            }
        }
        dblLightSpanStartMaxPoint = 0;
        dblLightSpanEndMaxPoint = 0;

        /*
         * mapStreetLightUtilityDistance and mapStreetLightUtilityBrightness stores the necessary information for streetlight utility computation
         * for different road users.
         */

        for (it=mapStreetLightUtilityDistance.begin(); it!=mapStreetLightUtilityDistance.end(); it++)
        {
            if( it->first < dblLightSpanStartMaxPoint)
                dblLightSpanStartMaxPoint = it->first ;
            if( it->second > dblLightSpanEndMaxPoint)
                dblLightSpanEndMaxPoint = it->second;
            /*
             * Compute the street lighting utility for pedestrian to avoid obstacles, navigation and face recognition.
             */
            if(it->second > 0 &&  dblUtilityAvoidEndPoint <= 10)
            {
                if(it->first <= 0)
                    dblUtilityAvoidStartPoint = 0;
                else
                {
                    if (it->first < 10)
                        dblUtilityAvoidStartPoint = it->first;
                    if (it->first >= 10)
                        dblUtilityAvoidStartPoint = 10;
                }
                if(it->second >= 10)
                   dblUtilityAvoidEndPoint = 10;
                else
                   dblUtilityAvoidEndPoint = it->second;


                for(double i = dblUtilityAvoidStartPoint; i <= dblUtilityAvoidEndPoint; i+=1)
                {

                    double dblClipToMaxUtilityOfOne;
                    if(i + 1 > dblUtilityAvoidEndPoint)
                    {
                        dblClipToMaxUtilityOfOne = (mapStreetLightUtilityBrightness.find(it->first)->second)/(1-0.2*floor(fabs(dblUtilityAvoidEndPoint)/30)) > 1 ? 1 : (mapStreetLightUtilityBrightness.find(it->first)->second)/(1-0.2*floor(fabs(dblUtilityAvoidEndPoint)/30));
                        dblUtilityAvoid += dblClipToMaxUtilityOfOne*(dblUtilityAvoidEndPoint - i);
                    }
                    else
                    {

                        dblClipToMaxUtilityOfOne = (mapStreetLightUtilityBrightness.find(it->first)->second)/(1-0.2*floor(fabs(i)/30)) > 1 ? 1 :(mapStreetLightUtilityBrightness.find(it->first)->second)/(1-0.2*floor(fabs(i)/30));
                        dblUtilityAvoid += dblClipToMaxUtilityOfOne;
                    }
                }
            }

            if(it->first <= 0)
            {
                dblUtilityProspectFrontStartPoint = 0;
            }
            else
                dblUtilityProspectFrontStartPoint = it->first;

            dblUtilityProspectFrontEndPoint = it->second;

            for(double i = dblUtilityProspectFrontStartPoint; i <= dblUtilityProspectFrontEndPoint; i+=1)
            {
                double dblClipToMaxUtilityOfOne = 0;
                if(i + 1 > dblUtilityProspectFrontEndPoint)
                {

                    if(floor(fabs(i)/30) >= 5)
                        dblClipToMaxUtilityOfOne = 0;
                    else
                        dblClipToMaxUtilityOfOne = (mapStreetLightUtilityBrightness.find(it->first)->second)/(1-0.2*floor(fabs(i)/30)) > 1 ? 1 : (mapStreetLightUtilityBrightness.find(it->first)->second)/(1-0.2*floor(fabs(i)/30));

                    dblUtilityProspectFront += dblClipToMaxUtilityOfOne*(dblUtilityProspectFrontEndPoint - i);
                    //ev<<"Debug : scenario (22-1) SUMOTraCIMobilityV2::computeStreetlightUtilityOfPedestrianFront. dblUtilityProspectFront : "<< dblUtilityProspectFront<<endl;
                    //ev<<"   dblUtilityProspectFrontStartPoint : "<< dblUtilityProspectFrontStartPoint<<", dblUtilityProspectFrontEndPoint : "<< dblUtilityProspectFrontEndPoint<<endl;

                }
                else
                {
                    if(floor(fabs(i)/30) >= 5)
                    {
                        dblClipToMaxUtilityOfOne = 0;
                    }
                    else
                        dblClipToMaxUtilityOfOne = (mapStreetLightUtilityBrightness.find(it->first)->second)/(1-0.2*floor(fabs(i)/30)) > 1 ? 1 :(mapStreetLightUtilityBrightness.find(it->first)->second)/(1-0.2*floor(fabs(i)/30));

                    dblUtilityProspectFront += dblClipToMaxUtilityOfOne;
                }
            }
        }

        /*
         * with clipping
         * Use the furthest streetlight in the view field as the reference point for streetlight
         * utility computation
         */
        if(dblUtilityAvoidEndPoint > 0)
           dblUtilityAvoid /= dblUtilityAvoidEndPoint;
        else
           dblUtilityAvoid = 0;

        if(fabs(dblLightSpanEndMaxPoint) > 0)
            dblUtilityProspectFront /= dblLightSpanEndMaxPoint;
        else
            dblUtilityProspectFront = 0;
        /*
         * End with clipping
         */

        /*
         * without clipping
         */

        /*
          dblUtilityAvoid /= 10;
          dblUtilityProspectFront /= dblUtiltyDistance;
         */
        /*
         * End with clipping
         */
    }
}

void SUMOTraCIMobilityV2::computeStreetlightUtilityOfPedestrianRear()
{
    /*
     * Check the FIRST streetlight of the front view to check whether its beam pattern
     * covers the rear utility
     */
    std::map<double,double>::iterator it;
    std::map<double,double>::iterator itCheck;
    std::map<double, double>:: iterator itMapUtility;

    double dblLightSpanStartPoint = -1000;
    double dblLightSpanEndPoint = -1000;
    double dblLightSpanStartPoint2 = -1000;
    double dblLightSpanEndPoint2 = -1000;

    double dblLightSpanStartMaxPoint = 0;
    double dblLightSpanEndMaxPoint = 0;

    double dblLightBrightness = 0;
//    double dblMaxSSDBasedOnViewField = 0;
//    double dblViewFieldStartPoint = 1000;


      //to store the actual values used for utility computation
      std::map<double,double> mapStreetLightUtilityDistance;
      std::map<double,double> mapStreetLightUtilityBrightness;

    for(it=mapCollectedPoleInfoFrontView.begin(); it != mapCollectedPoleInfoFrontView.end(); it++)
    {
        double dblTmpLightSpanStartPoint = (it->first - (dblAvgStreetligthBeamWidth/2) );
        double dblTmpLightSpanEndtPoint = (dblAvgStreetligthBeamWidth/2) - it->first;


        if(dblTmpLightSpanStartPoint < 0 )
        {
            dblLightSpanStartPoint = 0;
            dblLightSpanEndPoint = dblTmpLightSpanEndtPoint;
        }

        if(mapCollectedPoleInfoBrightness.find(it->second) == mapCollectedPoleInfoBrightness.end())
            opp_warning("error : computeStreetlightUtilityOfPedestrianRear::calStreetLightUtilityOfRoadUser: Brightness");

        dblLightBrightness = mapCollectedPoleInfoBrightness.find(it->second)->second;

        if( dblLightSpanStartPoint < dblLightSpanStartMaxPoint)
            dblLightSpanStartMaxPoint = dblLightSpanStartPoint;
        if( dblLightSpanEndPoint > dblLightSpanEndMaxPoint)
            dblLightSpanEndMaxPoint = dblLightSpanEndPoint;


        if(dblLightSpanStartPoint != -1000 && dblLightSpanEndPoint != -1000)
        {
            mapStreetLightUtilityDistance.insert(std::pair<double, double> (dblLightSpanStartPoint,dblLightSpanEndPoint));
            mapStreetLightUtilityBrightness.insert(std::pair<double, double>(dblLightSpanStartPoint, dblLightBrightness));
        }

        if(dblLightSpanStartPoint2 != -1000 && dblLightSpanEndPoint2 != -1000)
        {
            mapStreetLightUtilityDistance.insert(std::pair<double, double> (dblLightSpanStartPoint2,dblLightSpanEndPoint2));
            mapStreetLightUtilityBrightness.insert(std::pair<double, double>(dblLightSpanStartPoint2, dblLightBrightness));
        }
        break;
    }

    for(it=mapCollectedPoleInfoRearView.begin(); it != mapCollectedPoleInfoRearView.end(); it++)
    {
        dblLightBrightness = mapCollectedPoleInfoBrightness.find(it->second)->second;

        if (mapStreetLightUtilityDistance.empty())
        {
            if(it->first - (dblAvgStreetligthBeamWidth/2) < 0)
                dblLightSpanStartPoint = 0;
            else
            {
                if(it->first - (dblAvgStreetligthBeamWidth/2) < dblUtiltyDistance)
                    dblLightSpanStartPoint = (dblAvgStreetligthBeamWidth/2) - it->first;
                else
                    dblLightSpanStartPoint = dblUtiltyDistance;
            }

            if (it->first + (dblAvgStreetligthBeamWidth/2) > dblUtiltyDistance)
                dblLightSpanEndPoint = dblUtiltyDistance;
            else
                dblLightSpanEndPoint = it->first + (dblAvgStreetligthBeamWidth/2);
        }
        else
        {
            for(itMapUtility = mapStreetLightUtilityDistance.begin(); itMapUtility != mapStreetLightUtilityDistance.end(); itMapUtility++)
            {
                //ev<<"(Comparing with utility list) Pedestrian / cyclist ID : "<<this->getParentModule()->getIndex() <<" : location :" <<it->first <<" ("<<itMapUtility->first <<", "<< itMapUtility->second << ") : Brightness : "<< mapStreetLightUtilityBrightness.find(itMapUtility->first)->second<<endl;
                if(itMapUtility->first == itMapUtility->second)
                    continue;

                if(mapCollectedPoleInfoBrightness.find(it->second)->second > mapStreetLightUtilityBrightness.find(itMapUtility->first)->second)
                {
                  /*
                   *  scenario (2)
                   */
                    if(it->first - (dblAvgStreetligthBeamWidth/2) >= itMapUtility->second && it->first - (dblAvgStreetligthBeamWidth/2) > itMapUtility->first &&
                            it->first + (dblAvgStreetligthBeamWidth/2) > itMapUtility->second && it->first + (dblAvgStreetligthBeamWidth/2) > itMapUtility->first)
                    {
                        if((itMapUtility) == mapStreetLightUtilityDistance.end() )
                        {
                            itMapUtility->second = it->first - (dblAvgStreetligthBeamWidth/2);
                        }

                        dblLightSpanStartPoint = it->first - (dblAvgStreetligthBeamWidth/2);

                        if (it->first + (dblAvgStreetligthBeamWidth/2) > dblUtiltyDistance)
                            dblLightSpanEndPoint = dblUtiltyDistance;
                        else
                            dblLightSpanEndPoint = it->first + (dblAvgStreetligthBeamWidth/2);

                        dblLightSpanStartPoint2 = -1000;
                        dblLightSpanEndPoint2 = -1000;
                  }

                  /*
                   * scenario (3)
                   */
                  if(it->first - (dblAvgStreetligthBeamWidth/2) < itMapUtility->second && it->first - (dblAvgStreetligthBeamWidth/2) >= itMapUtility->first &&
                          it->first + (dblAvgStreetligthBeamWidth/2) > itMapUtility->second && it->first + (dblAvgStreetligthBeamWidth/2) > itMapUtility->first)
                  {
                      itMapUtility->second=it->first - (dblAvgStreetligthBeamWidth/2);

                      dblLightSpanStartPoint = it->first - (dblAvgStreetligthBeamWidth/2);
                      if (it->first + (dblAvgStreetligthBeamWidth/2) > dblUtiltyDistance)
                          dblLightSpanEndPoint = dblUtiltyDistance;
                      else
                          dblLightSpanEndPoint = it->first + (dblAvgStreetligthBeamWidth/2);

                      dblLightSpanStartPoint2 = -1000;
                      dblLightSpanEndPoint2 = -1000;
                  }

                  /*
                   * scenario (4)
                   */
                  if(it->first -(dblAvgStreetligthBeamWidth/2) <= itMapUtility->first && it->first -(dblAvgStreetligthBeamWidth/2) < itMapUtility->second &&
                          it->first + (dblAvgStreetligthBeamWidth/2) > itMapUtility->first && it->first + (dblAvgStreetligthBeamWidth/2) >= itMapUtility->second)
                  {
                      /*
                       * After erase the map, the for loop will check it again
                       */
                      mapStreetLightUtilityDistance.erase(itMapUtility->first);
                      mapStreetLightUtilityBrightness.erase(itMapUtility->first);

                      if(it->first - (dblAvgStreetligthBeamWidth/2) < 0)
                           dblLightSpanStartPoint = 0;
                       else
                           dblLightSpanStartPoint = it->first - (dblAvgStreetligthBeamWidth/2);

                       if(it->first + (dblAvgStreetligthBeamWidth/2) > dblUtiltyDistance)
                           dblLightSpanEndPoint = dblUtiltyDistance;
                       else
                           dblLightSpanEndPoint= it->first + (dblAvgStreetligthBeamWidth/2) ;

                      dblLightSpanStartPoint2 = -1000;
                      dblLightSpanEndPoint2 = -1000;
                  }
              }
              else
              {
                  /*
                   * scenario (5)
                   */
                  if(it->first - (dblAvgStreetligthBeamWidth/2) >= itMapUtility->second && it->first - (dblAvgStreetligthBeamWidth/2) > itMapUtility->first &&
                          it->first + (dblAvgStreetligthBeamWidth/2) > itMapUtility-> second && it->first + (dblAvgStreetligthBeamWidth/2) >= itMapUtility-> first)
                  {
                      dblLightSpanStartPoint = it->first - (dblAvgStreetligthBeamWidth/2);
                      if (it->first + (dblAvgStreetligthBeamWidth/2) > dblUtiltyDistance)
                          dblLightSpanEndPoint = dblUtiltyDistance;
                      else
                          dblLightSpanEndPoint = it->first + (dblAvgStreetligthBeamWidth/2);

                      dblLightSpanStartPoint2 = -1000;
                      dblLightSpanEndPoint2 = -1000;
                  }

                  /*
                   * scenario (6-1)
                   */

                 if(it->first - (dblAvgStreetligthBeamWidth/2) < itMapUtility->second && it->first - (dblAvgStreetligthBeamWidth/2)> itMapUtility->first &&
                         it->first + (dblAvgStreetligthBeamWidth/2) > itMapUtility->first &&  it->first + (dblAvgStreetligthBeamWidth/2) > itMapUtility-> second)
                 {
                     dblLightSpanStartPoint = itMapUtility->second;

                     if (it->first + (dblAvgStreetligthBeamWidth/2) > dblUtiltyDistance)
                         dblLightSpanEndPoint = dblUtiltyDistance;
                     else
                         dblLightSpanEndPoint = it->first + (dblAvgStreetligthBeamWidth/2);

                     dblLightSpanStartPoint2 = -1000;
                     dblLightSpanEndPoint2 = -1000;
                 }

                 /*
                  * scenario (6-2)
                  */
                  if(it->first - (dblAvgStreetligthBeamWidth/2) < itMapUtility->first && it->first - (dblAvgStreetligthBeamWidth/2)> itMapUtility->second &&
                          it->first + (dblAvgStreetligthBeamWidth/2) > itMapUtility-> first &&  it->first + (dblAvgStreetligthBeamWidth/2) < itMapUtility-> second)
                  {
                      dblLightSpanStartPoint = -1000;
                      dblLightSpanEndPoint = -1000;
                      dblLightSpanStartPoint2 = -1000;
                      dblLightSpanEndPoint2 = -1000;
                  }
                 /*
                  * scenario (7)
                  */
                  if(it->first - (dblAvgStreetligthBeamWidth/2) <= itMapUtility->first && it->first - (dblAvgStreetligthBeamWidth/2) <= itMapUtility->second &&
                          it->first + (dblAvgStreetligthBeamWidth/2) >= itMapUtility-> first && it->first + (dblAvgStreetligthBeamWidth/2) >= itMapUtility->second)
                  {
                      if (mapCollectedPoleInfoBrightness.find(it->second)->second == mapStreetLightUtilityBrightness.find(itMapUtility->first)->second)
                      {
                          dblLightSpanStartPoint = itMapUtility->second;
                          if (it->first + (dblAvgStreetligthBeamWidth/2) > dblUtiltyDistance)
                              dblLightSpanEndPoint = dblUtiltyDistance;
                          else
                              dblLightSpanEndPoint = it->first + (dblAvgStreetligthBeamWidth/2);

                          mapCollectedPoleInfoRearView.erase(itMapUtility->first);
                      }
                      else if (mapCollectedPoleInfoBrightness.find(it->second)->second < mapStreetLightUtilityBrightness.find(itMapUtility->first)->second)
                      {
                          dblLightSpanStartPoint = it->first - (dblAvgStreetligthBeamWidth/2);
                          dblLightSpanEndPoint = itMapUtility->first;
                          for(itCheck = mapStreetLightUtilityDistance.begin(); itCheck != mapStreetLightUtilityDistance.end(); itCheck++)
                          {
                              //check for inclusion
                              if(itCheck->first<=dblLightSpanStartPoint &&
                                      itCheck->second>= dblLightSpanEndPoint)
                              {
                                  if(mapStreetLightUtilityBrightness.find(itCheck->first)->second > dblLightBrightness)
                                  {
                                      dblLightSpanStartPoint = -1000;
                                      dblLightSpanEndPoint = -1000;
                                  }
                                  else
                                  {

                                  }

                                  break;
                              }
                          }

                          dblLightSpanStartPoint2 = itMapUtility->second;;
                          if (it->first + (dblAvgStreetligthBeamWidth/2) > dblUtiltyDistance)
                              dblLightSpanEndPoint2 = dblUtiltyDistance;
                          else
                              dblLightSpanEndPoint2 = it->first + (dblAvgStreetligthBeamWidth/2);
                      }
                  }
              }
          }
        }
        if( dblLightSpanStartPoint < dblLightSpanStartMaxPoint)
            dblLightSpanStartMaxPoint = dblLightSpanStartPoint;
        if( dblLightSpanEndPoint > dblLightSpanEndMaxPoint)
            dblLightSpanEndMaxPoint = dblLightSpanEndPoint;


        if(dblLightSpanStartPoint != -1000 && dblLightSpanEndPoint != -1000)
        {
            mapStreetLightUtilityDistance.insert(std::pair<double, double> (dblLightSpanStartPoint,dblLightSpanEndPoint));
            mapStreetLightUtilityBrightness.insert(std::pair<double, double>(dblLightSpanStartPoint, dblLightBrightness));
        }

        if(dblLightSpanStartPoint2 != -1000 && dblLightSpanEndPoint2 != -1000)
        {
            mapStreetLightUtilityDistance.insert(std::pair<double, double> (dblLightSpanStartPoint2,dblLightSpanEndPoint2));
            mapStreetLightUtilityBrightness.insert(std::pair<double, double>(dblLightSpanStartPoint2, dblLightBrightness));
        }
    }

    double dblUtilityProspectRearStartPoint = 0 ;
    double dblUtilityProspectRearEndPoint = 0 ;
//    double dblUtilityProspectFrontStartPoint = 0 ;
//    double dblUtilityProspectFrontEndPoint = 0 ;

//    double dblUtilityAvoidStartPoint = 0;
//    double dblUtilityAvoidEndPoint = 0;


    dblTotalUtility = 0;
    for (it=mapStreetLightUtilityDistance.begin(); it!=mapStreetLightUtilityDistance.end(); it++)
    {
        //to remove those with same starting and ending position pair
        if(it->first == it->second)
        {
            mapStreetLightUtilityDistance.erase(it->first);
        }
    }
    dblLightSpanStartMaxPoint = 0;
    dblLightSpanEndMaxPoint = 0;

    /*
     * mapStreetLightUtilityDistance and mapStreetLightUtilityBrightness stores the necessary information for streetlight utility computation
     * for different road users.
     */
    for (it=mapStreetLightUtilityDistance.begin(); it!=mapStreetLightUtilityDistance.end(); it++)
    {
        ev<<"Debug : scenario (21) SUMOTraCIMobilityV2::computeStreetlightUtilityOfPedestrianRear. begin : "<< it->first<<", end : "<< it->second<<endl;


        if( it->first < dblLightSpanStartMaxPoint)
            dblLightSpanStartMaxPoint = it->first ;
        if( it->second > dblLightSpanEndMaxPoint)
            dblLightSpanEndMaxPoint = it->second;

        /*
         * Compute the street lighting utility for prospect rear.
         */

        if(it->first <= 0)
        {
            dblUtilityProspectRearStartPoint = 0;
        }
        else
            dblUtilityProspectRearStartPoint = it->first;

        dblUtilityProspectRearEndPoint = it->second;

        for(double i = dblUtilityProspectRearStartPoint; i <= dblUtilityProspectRearEndPoint; i+=1)
        {
            double dblClipToMaxUtilityOfOne = 0;;
            if(i + 1 > dblUtilityProspectRearEndPoint)
            {
                if(floor(fabs(i)/30) >= 5)
                {
                    dblClipToMaxUtilityOfOne = 0;
                }
                else
                {
                    dblClipToMaxUtilityOfOne = (mapStreetLightUtilityBrightness.find(it->first)->second)/(1-0.2*floor(fabs(i)/30)) > 1 ? 1 : (mapStreetLightUtilityBrightness.find(it->first)->second)/(1-0.2*floor(fabs(i)/30));
                }
                dblUtilityProspectRear += dblClipToMaxUtilityOfOne*(dblUtilityProspectRearEndPoint - i);
            }
            else
            {
                if(floor(fabs(i)/30) >= 5)
                {
                    dblClipToMaxUtilityOfOne = 0;
                }
                else
                    dblClipToMaxUtilityOfOne = (mapStreetLightUtilityBrightness.find(it->first)->second)/(1-0.2*floor(fabs(i)/30)) > 1 ? 1 :(mapStreetLightUtilityBrightness.find(it->first)->second)/(1-0.2*floor(fabs(i)/30));

                dblUtilityProspectRear += dblClipToMaxUtilityOfOne;
            }
        }
        //ev<<"dblUtilityProspectRear : "<< dblUtilityProspectRear<<", dblLightSpanEndMaxPoint : "<< dblLightSpanEndMaxPoint<<endl;
    }
    /*
     * with clipping
     */
    if(fabs(dblLightSpanEndMaxPoint) > 0)
    {
        dblUtilityProspectRear /= dblLightSpanEndMaxPoint;
    }
    else
        dblUtilityProspectRear = 0;
    /*
     * end with clipping
     */

    /*
     * without clipping
     */
    // dblUtilityProspectRear /= dblUtiltyDistance;
    /*
     * end without clipping
     */
}

void SUMOTraCIMobilityV2::calStreetLightUtilityOfPedestrian()
{

    dblUtilityAvoid = 0;
    dblUtilityProspectRear =  0;
    dblUtilityProspectFront = 0;

    computeStreetlightUtilityOfPedestrianFront();
    computeStreetlightUtilityOfPedestrianRear();


    intUtilityCount++;
    if(mapCollectedPoleInfoFrontView.size() > 0 && mapCollectedPoleInfoRearView.size() > 0)
    {

        dblTotalUtility = 0.45*dblUtilityAvoid + 0.55*(0.5*(dblUtilityProspectRear+dblUtilityProspectFront));
        statistics.totalUtility +=  dblTotalUtility;
        dblTotalCollectedUtilitybyTimeStep +=dblTotalUtility;
    }
    else if(mapCollectedPoleInfoFrontView.size() > 0 && mapCollectedPoleInfoRearView.size() == 0)
    {
        dblTotalUtility = 0.45*dblUtilityAvoid + 0.55*dblUtilityProspectFront;
        statistics.totalUtility +=  dblTotalUtility;
        dblTotalCollectedUtilitybyTimeStep +=dblTotalUtility;
    }
    else if(mapCollectedPoleInfoFrontView.size() == 0 && mapCollectedPoleInfoRearView.size() > 0)
    {
        dblTotalUtility = dblUtilityProspectRear;
        statistics.totalUtility +=  dblTotalUtility;
        dblTotalCollectedUtilitybyTimeStep += dblTotalUtility;
    }

    /*
    ev<<"Debug : SUMOTraCIMobilityV2::calStreetLightUtilityOfRoadUser: Pedestrian / cyclist  Total Utility : ID " <<  this->getParentModule()->getIndex() << " : Total Utility : " << statistics.totalUtility <<endl;
    ev<<"Debug : SUMOTraCIMobilityV2::calStreetLightUtilityOfRoadUser: Pedestrian / cyclist Total Utility : ID " <<  this->getParentModule()->getIndex() << " : Current Utility : "<<dblTotalUtility <<" : Total Utility : " << statistics.totalUtility << " : intUtilityCount : "<< intUtilityCount << " : Average : " <<  (intUtilityCount > 0 ? statistics.totalUtility/intUtilityCount : 0) <<endl;
    ev<<"Debug : SUMOTraCIMobilityV2::calStreetLightUtilityOfRoadUser: Pedestrian / cyclist  Total Utility : ID " <<  this->getParentModule()->getIndex() << " : dblUtilityAvoid  : " << dblUtilityAvoid << " : dblUtilityProspectRear : " << dblUtilityProspectRear << " : dblUtilityProspectFront : " << dblUtilityProspectFront<< endl;
     */

    if(intUtilityCount > 0 && intCollectUtilityByTimeStep > 0 && intUtilityCount % intCollectUtilityByTimeStep == 0)
    {
      //emit the data using signal
      emit(recordTotalUtilitySignal,(double)(dblTotalCollectedUtilitybyTimeStep/(double)intCollectUtilityByTimeStep));
      //reset the variable to 0 every user defined time step.
      dblTotalCollectedUtilitybyTimeStep = 0;

    }


    /*
     *Assign the newly received value for the new simulation time
     */
    mapCollectedPoleInfoDistance.clear();
    mapCollectedPoleInfoBrightness.clear();
    /*
     * LSP 28/08/2013 add new PoleInfo collection based on rear view and front view
     */
    mapCollectedPoleInfoFrontView.clear();
    mapCollectedPoleInfoRearView.clear();


}

void SUMOTraCIMobilityV2::collectStreetlightInfoBasedOnFoV()
{
    /*
     * Assign the newly received value for the new simulation time
     */
     mapCollectedPoleInfoDistance.clear();
     mapCollectedPoleInfoBrightness.clear();

     /*
     * LSP 28/08/2013 add new PoleInfo collection based on rear view and front view
     */
     mapCollectedPoleInfoFrontView.clear();
     mapCollectedPoleInfoRearView.clear();

     myGlobalTraci = FindModule<SUMOTraCIScenarioManagerV2*>::findGlobalModule();

     const std::map<std::string, cModule*>* ptrAllLamppost = myGlobalTraci->getManagedLamppostPointer();
     std::map<std::string, cModule*>::const_iterator it;

     for(it = (ptrAllLamppost)->begin(); it !=(ptrAllLamppost)->end(); it++ )
     {
         const StreetlightMobilityV2* ptrStreetlightMobility = FindModule<StreetlightMobilityV2*>::findSubModule(const_cast<cModule*>((*it).second));
         const StreetlightApplLayer* ptrApplLayer = FindModule<StreetlightApplLayer*>::findSubModule(const_cast<cModule*>((*it).second));
         const double dblCurrentBrightnessLevel = ptrApplLayer->getCurrentBrightnessLevel();

         /* For debugging purpose */
         switch( ptrApplLayer->getCurrentOppStatus())
         {
             case StreetlightApplLayer::LAMP_STATUS_OFF:
                 ev<<"   Operation status :LAMP_STATUS_OFF"<<endl;
                 break;
             case StreetlightApplLayer::LAMP_STATUS_ON:
                 ev<<"   Operation status :LAMP_STATUS_ON"<<endl;
                 break;
             case StreetlightApplLayer::LAMP_STATUS_ON_100:
                 ev<<"   Operation status :LAMP_STATUS_ON_100"<<endl;
                 break;
             case StreetlightApplLayer::LAMP_STATUS_ON_40 :
                 ev<<"   Operation status :LAMP_STATUS_ON_40"<<endl;
                 break;
             case StreetlightApplLayer::LAMP_STATUS_ON_70 :
                 ev<<"   Operation status :LAMP_STATUS_ON_70"<<endl;
                 break;
             case StreetlightApplLayer::LAMP_STATUS_ON_BY_DELAY :
                 ev<<"   Operation status :LAMP_STATUS_ON_BY_DELAY"<<endl;
                 break;
             case StreetlightApplLayer::LAMP_STATUS_ON_BY_RELAY :
                 ev<<"   Operation status :LAMP_STATUS_ON_BY_RELAY"<<endl;
                 break;
             case StreetlightApplLayer::LAMP_STATUS_ON_BY_SENSE :
                 ev<<"   Operation status :LAMP_STATUS_ON_BY_SENSE"<<endl;
                 break;
             default:
                 ev<<"   Operation status :ERROR"<<endl;
                 break;
         }
         double distBtwSensorAndRoadUser = sqrt((double)(pow((this->getCurrentPosition().x - ptrStreetlightMobility->getCurrentPosition().x),2)+ pow((this->getCurrentPosition().y - ptrStreetlightMobility->getCurrentPosition().y),2)));

        /*
         * reason of using " if(distanceBetweenCar <= maxPoleVisualDistance ) "
         * is to minimise the unnecessary iteration for those Poles that are not within the view distance
         */
         double maxViewDepth = 200 + dblAverageLightSpan;
         if(distBtwSensorAndRoadUser <= maxViewDepth)
         {
             const std::list <Coord>  viewFieldPolygonFront = this->getVisualFieldFront();
             const std::list <Coord>  viewFieldPolygonRear = this->getVisualFieldRear();

            /*
             * Determine weather this lamppost is within the front and rear view field of a road user
             * if YES, then its max light span is calculate and passes it to the road user for further
             * processing at SUMOTraCIMobilityV2 module.
             */
            /*
             * For front view field
             */
            Coord lastCoords =  *(visualFieldFront.rbegin());
            bool isPoleWithinViewField = false;
            /*
             * Check whether a streetlight is within the view field of a road user
             */
            for (std::list<Coord>::const_iterator i = visualFieldFront.begin(); i != visualFieldFront.end(); ++i)
            {
                Coord c1 = *i;
                Coord c2 = lastCoords;
                lastCoords = c1;

                if( ((c1.y > ptrStreetlightMobility->getCurrentPosition().y) != (c2.y > ptrStreetlightMobility->getCurrentPosition().y)) &&
                    (ptrStreetlightMobility->getCurrentPosition().x < (c2.x - c1.x) * (ptrStreetlightMobility->getCurrentPosition().y - c1.y)/ (c2.y - c1.y) + c1.x))
                {
                    //if number of crossing is odd then the Pole is within the view field polygon, meaning True!
                    isPoleWithinViewField = !isPoleWithinViewField;
                }
            }
            /*
             * Only consider lampposts with front view field and those not blocked by any obstacles
             */
            if(isPoleWithinViewField && (!isObstacleBtwPoleAndCar(it->second)))
            {
                collectStreetlightStatusV2(distBtwSensorAndRoadUser,dblCurrentBrightnessLevel , ptrApplLayer->getParentModule()->getIndex(), dblAverageLightSpan, false);
            }

            /*
             * for rear view field
             */
            lastCoords = *(visualFieldRear.rbegin());
            isPoleWithinViewField = false;
            for (std::list<Coord>::const_iterator i = visualFieldRear.begin(); i != visualFieldRear.end(); ++i)
            {
                Coord c1 = *i;
                Coord c2 = lastCoords;
                lastCoords = c1;
                if( ((c1.y > ptrStreetlightMobility->getCurrentPosition().y) != (c2.y > ptrStreetlightMobility->getCurrentPosition().y)) &&
                        (ptrStreetlightMobility->getCurrentPosition().x < (c2.x - c1.x) * (ptrStreetlightMobility->getCurrentPosition().y - c1.y)/ (c2.y - c1.y) + c1.x))
                {
                    //if number of crossing is odd then the Pole is within the view field polygon, meaning True!
                    isPoleWithinViewField = !isPoleWithinViewField;
                }
            }

            /*
             * Only consider lamppost with rear view field and those not blocked by any obstacles
             */
            if(isPoleWithinViewField && (!isObstacleBtwPoleAndCar(it->second)))
            {
                collectStreetlightStatusV2(distBtwSensorAndRoadUser, dblCurrentBrightnessLevel, ptrApplLayer->getParentModule()->getIndex(), dblAverageLightSpan, true);
            }
        }
    }
}
bool SUMOTraCIMobilityV2::isObstacleBtwPoleAndCar(const cModule* lamppost)
{
    ObstacleControl* obstaclesCtr = ObstacleControlAccess().getIfExists();
    std::vector<Obstacle> tempObstacle = obstaclesCtr->getObtacleList();

    const StreetlightMobilityV2* ptrStreetlightMobility = FindModule<StreetlightMobilityV2*>::findSubModule(const_cast<cModule*>(lamppost));

    for(unsigned int i = 0; i < tempObstacle.size(); i++)
    {
        Obstacle tempOb = tempObstacle.at(i);
        Coords tempCoords= tempOb.getShape();
        for(unsigned int j=0; j < tempCoords.size()-1; j++)
        {
            if(isLineSegmentIntersectedV2(this->getCurrentPosition(),ptrStreetlightMobility->getCurrentPosition(),tempCoords.at(j),tempCoords.at(j+1)) )
            {
                return true;
                break;
            }
        }
    }
    return false;
}

bool SUMOTraCIMobilityV2::isLineSegmentIntersectedV2(Coord obj, Coord pole,
                                                        Coord wallPointA, Coord wallPointB)
{
    /*
     * Return false if either of the lines have zero length
     */

    if((obj.x == pole.x && obj.y == pole.y )|| (wallPointA.x == wallPointB.x && wallPointA.y == wallPointB.y))
        return false;

    double ax = pole.x - obj.x;
    double ay = pole.y - obj.y;
    double bx = wallPointA.x - wallPointB.x;
    double by = wallPointA.y - wallPointB.y;
    double cx = obj.x - wallPointA.x;
    double cy = obj.y - wallPointA.y;

   double alphaNumerator = by*cx - bx*cy;
   double commonDenominator = ay*bx - ax*by;
   if(commonDenominator >0)
   {
       if(alphaNumerator < 0 || alphaNumerator > commonDenominator )
       {
           return false;
       }
   }
   else if (commonDenominator < 0)
   {
       if(alphaNumerator > 0 || alphaNumerator < commonDenominator)
       {
               return false;
       }
   }
   double betaNumerator = ax*cy - ay*cx;
   if(commonDenominator > 0)
   {
       if(betaNumerator < 0 || betaNumerator > commonDenominator)
       {
               return false;
       }
   }
   else if (commonDenominator < 0)
   {
       if(betaNumerator > 0|| betaNumerator < commonDenominator)
       {
               return false;
       }
   }

   if(commonDenominator == 0)
   {
      double y3LessY1 = wallPointA.y - obj.y;
      double collinearityTestForP3 = obj.x*(pole.y - wallPointA.y) + pole.x*(y3LessY1) + wallPointA.x*(obj.y -pole.y);

      if(collinearityTestForP3 == 0)
      {
          if(((obj.x >= wallPointA.x) && (obj.x <= wallPointB.x)) || ((obj.x <= wallPointA.x) && (obj.x >= wallPointB.x)) ||
                  ((pole.x >= wallPointA.x) && (pole.x <= wallPointB.x)) || ((pole.x <= wallPointA.x) && (pole.x >= wallPointB.x)) ||
                 ((wallPointA.x >= obj.x) && (wallPointA.x <= pole.x)) || ((wallPointA.x <= obj.x) && (wallPointA.x >= pole.x)))
          {
              if((obj.y >= wallPointA.y && obj.y <= wallPointB.y) || (obj.y <= wallPointA.y && obj.y >= wallPointB.y) ||
                                   (pole.y >= wallPointA.y && pole.y <= wallPointB.y ) || (pole.y <= wallPointA.y && pole.y >= wallPointB.y) ||
                                  ( wallPointA.y >= obj.y && wallPointA.y <= pole.y) || (wallPointA.y <= obj.y && wallPointA.y >= pole.y))
              {
                  return true;
              }
          }
      }
      return false;
   }
   return true;
}

void SUMOTraCIMobilityV2::calStreetLightUtilityOfDriver()
{

    if(dblAvgStreetligthBeamWidth < 0)
      return;

   std::map<double,double>::iterator it = mapCollectedPoleInfoDistance.begin();
   std::map<double,double>::iterator itCheck;
   std::map<double, double>:: iterator itMapUtility;

   /*
    * 08/03/2013 - LSP
    * for testing and implementation only, stopping distance is assumed to be 70 m
    * for real scenario, SSD needs to be computed at every time step because SSD is function to speed
    * and speed of a vehicle changes over the time.
    */
   double dblLightSpanStartPoint = -1000;
   double dblLightSpanEndPoint = -1000;
   double dblLightSpanStartPoint2 = -1000;
   double dblLightSpanEndPoint2 = -1000;

   double dblLightSpanStartMaxPoint = 0;
   double dblLightSpanEndMaxPoint = 0;

   double dblLightBrightness = 0;
   double dblMaxSSDBasedOnViewField = 0;
//   double dblViewFieldStartPoint = 1000;


   //to store the actual values used for utility computation
   std::map<double,double> mapStreetLightUtilityDistance;
   std::map<double,double> mapStreetLightUtilityBrightness;

    /*
     * Streetlight utility for motorist based on stopping distance is not in use at the moment
     * Instead, a constant 100 m is used in streetlight utility computation
     */

   /*
    for (it=mapCollectedPoleInfoDistance.begin(); it!=mapCollectedPoleInfoDistance.end(); it++)
    {
           if(it->first + (dblAvgStreetligthBeamWidth/2 ) < 0 )
           {
               mapCollectedPoleInfoDistance.erase(it->first);
           }
           if(it->first  - (dblAvgStreetligthBeamWidth/2 ) > SSD)
           {
               mapCollectedPoleInfoDistance.erase(it->first);
           }
    }
    */

   /*
    * Processing the streetlight at the rear view and check whether streetlight's beam
    * pattern covers the front view or not
    *
    * Only consider the nearest streetlight at the rear.
    */
   dblLightSpanStartPoint = 0;
   for(it=mapCollectedPoleInfoRearView.begin(); it != mapCollectedPoleInfoRearView.end(); it++)
   {
      double dblTmpLightSpanEndtPoint = (dblAvgStreetligthBeamWidth/2) - it->first;
      if(dblTmpLightSpanEndtPoint > 0 )
      {
          dblLightSpanStartPoint = 0;
          dblLightSpanEndPoint = dblTmpLightSpanEndtPoint;
      }

      if(mapCollectedPoleInfoBrightness.find(it->second) == mapCollectedPoleInfoBrightness.end())
          opp_warning("error : SUMOTraCIMobilityV2::calStreetLightUtilityOfRoadUser: Brightness");

      dblLightBrightness = mapCollectedPoleInfoBrightness.find(it->second)->second;
      if( dblLightSpanStartPoint < dblLightSpanStartMaxPoint)
         dblLightSpanStartMaxPoint = dblLightSpanStartPoint;
      if( dblLightSpanEndPoint > dblLightSpanEndMaxPoint)
         dblLightSpanEndMaxPoint = dblLightSpanEndPoint;

     if(dblLightSpanStartPoint != -1000 && dblLightSpanEndPoint != -1000)
     {
         mapStreetLightUtilityDistance.insert(std::pair<double, double> (dblLightSpanStartPoint,dblLightSpanEndPoint));
         mapStreetLightUtilityBrightness.insert(std::pair<double, double>(dblLightSpanStartPoint, dblLightBrightness));
     }

     if(dblLightSpanStartPoint2 != -1000 && dblLightSpanEndPoint2 != -1000)
     {
         mapStreetLightUtilityDistance.insert(std::pair<double, double> (dblLightSpanStartPoint2,dblLightSpanEndPoint2));
         mapStreetLightUtilityBrightness.insert(std::pair<double, double>(dblLightSpanStartPoint2, dblLightBrightness));
     }
     break;
   }

   /*
    * Processing the streetlights lay in front of the road user
    */
   for(it=mapCollectedPoleInfoFrontView.begin(); it != mapCollectedPoleInfoFrontView.end(); it++)
   {
       dblLightBrightness = mapCollectedPoleInfoBrightness.find(it->second)->second;
       if (mapStreetLightUtilityDistance.empty())
       {
           if(it->first - (dblAvgStreetligthBeamWidth/2) < 0)
              dblLightSpanStartPoint = 0;
           else
               if(it->first - (dblAvgStreetligthBeamWidth/2) < dblUtiltyDistance)
               {
                   dblLightSpanStartPoint = it->first - (dblAvgStreetligthBeamWidth/2);
               }
               else
                   dblLightSpanStartPoint = dblUtiltyDistance;

           if (it->first + (dblAvgStreetligthBeamWidth/2) > dblUtiltyDistance)
               dblLightSpanEndPoint = dblUtiltyDistance;
           else
               dblLightSpanEndPoint = it->first + (dblAvgStreetligthBeamWidth/2);
       }
       else
       {
           for(itMapUtility = mapStreetLightUtilityDistance.begin(); itMapUtility != mapStreetLightUtilityDistance.end(); itMapUtility++)
           {
               /*
                * Skip those entries with same start point and end point
                */
               double dblCurrentListStartPoint = it->first - (dblAvgStreetligthBeamWidth/2) < 0?0:it->first- (dblAvgStreetligthBeamWidth/2);
               dblCurrentListStartPoint = dblCurrentListStartPoint > dblUtiltyDistance?dblUtiltyDistance:dblCurrentListStartPoint;

               /*
                * For debugging purpose
                */
               /*
               ev<<"SUMOTraCIMobilityV2::computeStreetlightUtility: Driver : debug (3-2) : dblCurrentListStartPoint : "<<dblCurrentListStartPoint<<endl;
               ev<<"    collected brigtness : "<< mapCollectedPoleInfoBrightness.find(it->second)->second<<endl;
               ev<<"    processed brigtness : "<< mapStreetLightUtilityBrightness.find(itMapUtility->first)->second << endl;
               ev<<"    itMapUtility->first : "<< itMapUtility->first <<", itMapUtility->second : "<<itMapUtility->second<<endl;
               */

               if(itMapUtility->first == itMapUtility->second)
                   continue;

               if(mapCollectedPoleInfoBrightness.find(it->second)->second > mapStreetLightUtilityBrightness.find(itMapUtility->first)->second)
               {

                  //scenario (2)
                   if(dblCurrentListStartPoint >= itMapUtility->second && dblCurrentListStartPoint > itMapUtility->first &&
                           it->first + (dblAvgStreetligthBeamWidth/2) > itMapUtility->second && it->first + (dblAvgStreetligthBeamWidth/2) > itMapUtility->first)
                   {
                       if((itMapUtility) == mapStreetLightUtilityDistance.end() )
                       {
                           itMapUtility->second = dblCurrentListStartPoint;
                       }

                       dblLightSpanStartPoint = dblCurrentListStartPoint;

                       if (it->first + (dblAvgStreetligthBeamWidth/2) > dblUtiltyDistance)
                           dblLightSpanEndPoint = dblUtiltyDistance;
                       else
                           dblLightSpanEndPoint = it->first + (dblAvgStreetligthBeamWidth/2);

                       dblLightSpanStartPoint2 = -1000;
                       dblLightSpanEndPoint2 = -1000;
                   }

                   //scenario (3)
                   if(dblCurrentListStartPoint < itMapUtility->second && dblCurrentListStartPoint >= itMapUtility->first &&
                           it->first + (dblAvgStreetligthBeamWidth/2) > itMapUtility->second && it->first + (dblAvgStreetligthBeamWidth/2) > itMapUtility->first)
                   {

                       itMapUtility->second=dblCurrentListStartPoint;

                       if(itMapUtility->second == itMapUtility->first)
                       {
                           mapStreetLightUtilityDistance.erase(itMapUtility->first);
                           mapStreetLightUtilityBrightness.erase(itMapUtility->first);
                       }
                       else
                           itMapUtility->second=dblCurrentListStartPoint;

                       dblLightSpanStartPoint = dblCurrentListStartPoint;
                       if (it->first + (dblAvgStreetligthBeamWidth/2) > dblUtiltyDistance)
                           dblLightSpanEndPoint = dblUtiltyDistance;
                       else
                           dblLightSpanEndPoint = it->first + (dblAvgStreetligthBeamWidth/2);

                       dblLightSpanStartPoint2 = -1000;
                       dblLightSpanEndPoint2 = -1000;
                   }

                   //scenario (4)
                   if(dblCurrentListStartPoint <= itMapUtility->first && dblCurrentListStartPoint < itMapUtility->second &&
                           it->first + (dblAvgStreetligthBeamWidth/2) > itMapUtility->first && it->first + (dblAvgStreetligthBeamWidth/2) >= itMapUtility->second)
                   {
                       /*
                        * After erase the map, the for loop will check it again
                        */
                       mapStreetLightUtilityDistance.erase(itMapUtility->first);
                       mapStreetLightUtilityBrightness.erase(itMapUtility->first);

                       if(it->first - (dblAvgStreetligthBeamWidth/2) < 0)
                         dblLightSpanStartPoint = 0;
                       else
                         dblLightSpanStartPoint = it->first - (dblAvgStreetligthBeamWidth/2);

                       if(it->first + (dblAvgStreetligthBeamWidth/2) > dblUtiltyDistance)
                           dblLightSpanEndPoint = dblUtiltyDistance;
                       else
                           dblLightSpanEndPoint= it->first + (dblAvgStreetligthBeamWidth/2) ;

                       dblLightSpanStartPoint2 = -1000;
                       dblLightSpanEndPoint2 = -1000;
                   }
               }
               else
               {
                   //scenario (5)
                   if(dblCurrentListStartPoint >= itMapUtility->second && dblCurrentListStartPoint > itMapUtility->first &&
                           it->first + (dblAvgStreetligthBeamWidth/2) > itMapUtility-> second && it->first + (dblAvgStreetligthBeamWidth/2) >= itMapUtility-> first)
                   {
                       dblLightSpanStartPoint = dblCurrentListStartPoint;
                       if (it->first + (dblAvgStreetligthBeamWidth/2) > dblUtiltyDistance)
                           dblLightSpanEndPoint = dblUtiltyDistance;
                       else
                           dblLightSpanEndPoint = it->first + (dblAvgStreetligthBeamWidth/2);

                       dblLightSpanStartPoint2 = -1000;
                       dblLightSpanEndPoint2 = -1000;
                   }

                   //scenario (6-1)
                  if(dblCurrentListStartPoint < itMapUtility->second && dblCurrentListStartPoint > itMapUtility->first &&
                          it->first + (dblAvgStreetligthBeamWidth/2) > itMapUtility->first &&  it->first + (dblAvgStreetligthBeamWidth/2) > itMapUtility-> second)
                  {
                      ev<<"SUMOTraCIMobilityV2::calStreetLightUtilityOfDriver: Driver : debug (10)"<<endl;

                      dblLightSpanStartPoint = itMapUtility->second;

                      if (it->first + (dblAvgStreetligthBeamWidth/2) > dblUtiltyDistance)
                          dblLightSpanEndPoint = dblUtiltyDistance;
                      else
                          dblLightSpanEndPoint = it->first + (dblAvgStreetligthBeamWidth/2);

                      dblLightSpanStartPoint2 = -1000;
                      dblLightSpanEndPoint2 = -1000;
                  }

                  //scenario (6-2)
                   if(dblCurrentListStartPoint < itMapUtility->first && dblCurrentListStartPoint > itMapUtility->second &&
                           it->first + (dblAvgStreetligthBeamWidth/2) > itMapUtility-> first &&  it->first + (dblAvgStreetligthBeamWidth/2) < itMapUtility-> second)
                   {
                       dblLightSpanStartPoint = -1000;
                       dblLightSpanEndPoint = -1000;
                       dblLightSpanStartPoint2 = -1000;
                       dblLightSpanEndPoint2 = -1000;
                   }

                   //scenario (7)
                   if(dblCurrentListStartPoint <= itMapUtility->first && dblCurrentListStartPoint <= itMapUtility->second &&
                           it->first + (dblAvgStreetligthBeamWidth/2) >= itMapUtility-> first && it->first + (dblAvgStreetligthBeamWidth/2) >= itMapUtility->second)
                   {

                       if (mapCollectedPoleInfoBrightness.find(it->second)->second == mapStreetLightUtilityBrightness.find(itMapUtility->first)->second)
                       {
                           dblLightSpanStartPoint = itMapUtility->second;

                           if (it->first + (dblAvgStreetligthBeamWidth/2) > dblUtiltyDistance)
                               dblLightSpanEndPoint = dblUtiltyDistance;
                           else
                               dblLightSpanEndPoint = it->first + (dblAvgStreetligthBeamWidth/2);

                           mapCollectedPoleInfoDistance.erase(itMapUtility->first);
                       }
                       else if (mapCollectedPoleInfoBrightness.find(it->second)->second < mapStreetLightUtilityBrightness.find(itMapUtility->first)->second)
                       {
                           dblLightSpanStartPoint = dblCurrentListStartPoint;
                           dblLightSpanEndPoint = itMapUtility->first;

                           for(itCheck = mapStreetLightUtilityDistance.begin(); itCheck != mapStreetLightUtilityDistance.end(); itCheck++)
                           {
                               //check for inclusion
                               if(itCheck->first<=dblLightSpanStartPoint &&
                                       itCheck->second>= dblLightSpanEndPoint)
                               {
                                   if(mapStreetLightUtilityBrightness.find(itCheck->first)->second > dblLightBrightness)
                                   {
                                       dblLightSpanStartPoint = -1000;
                                       dblLightSpanEndPoint = -1000;
                                   }
                                   else
                                   {

                                   }

                                   break;
                               }
                           }

                           dblLightSpanStartPoint2 = itMapUtility->second;;
                           if (it->first + (dblAvgStreetligthBeamWidth/2) > dblUtiltyDistance)
                               dblLightSpanEndPoint2 = dblUtiltyDistance;
                           else
                               dblLightSpanEndPoint2 = it->first + (dblAvgStreetligthBeamWidth/2);
                       }
                   }
               }
           }
       }

       if( dblLightSpanStartPoint < dblLightSpanStartMaxPoint)
           dblLightSpanStartMaxPoint = dblLightSpanStartPoint;
       if( dblLightSpanEndPoint > dblLightSpanEndMaxPoint)
           dblLightSpanEndMaxPoint = dblLightSpanEndPoint;

       if(dblLightSpanStartPoint != -1000 && dblLightSpanEndPoint != -1000)
       {
           mapStreetLightUtilityDistance.insert(std::pair<double, double> (dblLightSpanStartPoint,dblLightSpanEndPoint));
           mapStreetLightUtilityBrightness.insert(std::pair<double, double>(dblLightSpanStartPoint, dblLightBrightness));
       }

       if(dblLightSpanStartPoint2 != -1000 && dblLightSpanEndPoint2 != -1000)
       {
           mapStreetLightUtilityDistance.insert(std::pair<double, double> (dblLightSpanStartPoint2,dblLightSpanEndPoint2));
           mapStreetLightUtilityBrightness.insert(std::pair<double, double>(dblLightSpanStartPoint2, dblLightBrightness));
       }
   }

   dblTotalUtility = 0;
   for (it=mapStreetLightUtilityDistance.begin(); it!=mapStreetLightUtilityDistance.end(); it++)
   {
       //to remove those with same starting and ending position pair
       if(it->first == it->second)
       {
           mapStreetLightUtilityDistance.erase(it->first);
       }
   }

   dblLightSpanStartMaxPoint = 0;
   dblLightSpanEndMaxPoint = 0;
   /*
    * mapStreetLightUtilityDistance and mapStreetLightUtilityBrightness stores the necessary information for streetlight utility computation
    * for different road users.
    */
   for (it=mapStreetLightUtilityDistance.begin(); it!=mapStreetLightUtilityDistance.end(); it++)
   {
       if( it->first < dblLightSpanStartMaxPoint)
           dblLightSpanStartMaxPoint = it->first ;
       if( it->second > dblLightSpanEndMaxPoint)
           dblLightSpanEndMaxPoint = it->second;

       dblTotalUtility +=(it->second - it->first)*mapStreetLightUtilityBrightness.find(it->first)->second;
       dblMaxSSDBasedOnViewField = it->second ;
   }

   intUtilityCount++;
   if((mapCollectedPoleInfoFrontView.size() > 0 || mapCollectedPoleInfoRearView.size() > 0) && dblMaxSSDBasedOnViewField > 0)
   {
       /*
        * with clipping
        */
       statistics.totalUtility += (dblTotalUtility/dblMaxSSDBasedOnViewField > 1?1:dblTotalUtility/dblMaxSSDBasedOnViewField);
       dblTotalCollectedUtilitybyTimeStep +=((dblTotalUtility/dblMaxSSDBasedOnViewField > 1?1:dblTotalUtility/dblMaxSSDBasedOnViewField));
       /*
        * end with clipping
        */

       /*
        * Without clipping
        */
//       statistics.totalUtility += (dblTotalUtility/dblMaxSSDBasedOnViewField > 1?1:dblTotalUtility/dblUtiltyDistance);
//       dblTotalCollectedUtilitybyTimeStep +=((dblTotalUtility/dblMaxSSDBasedOnViewField > 1?1:dblTotalUtility/dblUtiltyDistance));
       /*
        * end without clipping
        */
   }

   /**
    * Need to emit the lighting condition to log file for further processing just before
    * the reset
    *
    * Only emit if there is pole within the view field else divide by 0 error will occur.
    */
   if(intUtilityCount > 0 && intCollectUtilityByTimeStep > 0 && intUtilityCount % intCollectUtilityByTimeStep == 0)
   {
       //emit the data using signal
       emit(recordTotalUtilitySignal,(double)(dblTotalCollectedUtilitybyTimeStep/(double)intCollectUtilityByTimeStep));
       //reset the variable to 0 every user defined time step.
       dblTotalCollectedUtilitybyTimeStep = 0;
   }

   /*
    * Assign the newly received value for the new simulation time
    */
    mapCollectedPoleInfoDistance.clear();
    mapCollectedPoleInfoBrightness.clear();

    /*
    * LSP 28/08/2013 add new PoleInfo collection based on rear view and front view
    */
    mapCollectedPoleInfoFrontView.clear();
    mapCollectedPoleInfoRearView.clear();
}

void SUMOTraCIMobilityV2::collectStreetlightStatusV2(double distance, double brightnessLevel, int PoleID, double lightSpanDistance, bool isRear)
{


       dblAvgStreetligthBeamWidth = lightSpanDistance;
       if(isRear)
       {
           mapCollectedPoleInfoRearView.insert(std::pair<double, double>(distance, PoleID));
           mapCollectedPoleInfoBrightness.insert(std::pair<double, double>(PoleID, brightnessLevel));
       }
       else
       {
           mapCollectedPoleInfoFrontView.insert(std::pair<double, double>(distance, PoleID));
           mapCollectedPoleInfoBrightness.insert(std::pair<double, double>(PoleID, brightnessLevel));
       }
}

void SUMOTraCIMobilityV2::handleSelfMsg(cMessage *msg)
{
    if(msg == computeStreetlightUtilityMsg)
    {
        collectStreetlightInfoBasedOnFoV();

        switch (this->intUserType)
        {
            case MOTORIST:
                calStreetLightUtilityOfDriver();
                break;
            case PEDESTRIAN:
                calStreetLightUtilityOfPedestrian();
                break;
            default:
                opp_error("SUMOTraCIMobilityV2::handleSelfMsg:Unknow road user (%d) type for streetlight utility calculation!!!", this->intUserType);
                break;
        }
        scheduleAt(simTime() + dblComputeUtilityDuration, computeStreetlightUtilityMsg);
    }
    if (msg == startAccidentMsg) {
        commandSetSpeed(0);
        simtime_t accidentDuration = par("accidentDuration");
        scheduleAt(simTime() + accidentDuration, stopAccidentMsg);
        accidentCount--;
    }
    else if (msg == stopAccidentMsg) {
        commandSetSpeed(-1);
        if (accidentCount > 0) {
            simtime_t accidentInterval = par("accidentInterval");
            scheduleAt(simTime() + accidentInterval, startAccidentMsg);
        }
    }
}

void SUMOTraCIMobilityV2::preInitializePole(std::string external_id, const Coord& position)
{
    this->external_id = external_id;
    this->lastUpdate = 0;
    this->nextPos = position;
    this->road_id = "";
    this->speed = 0.0;
    this->angle = 0.0;
    move.setStart(Coord(position.x, position.y, move.getCurrentPosition().z)); // keep z position
    move.setDirectionByVector(Coord(cos(angle), -sin(angle)));
    move.setSpeed(speed);

    isPreInitialized = true;

}

void SUMOTraCIMobilityV2::preInitialize(std::string external_id, std::string strRoadUserType, const Coord& position, std::string road_id, double speed, double angle, std::string route_Id)
{
    this->external_id = external_id;
    this->lastUpdate = 0;
    this->nextPos = position;
    this->road_id = road_id;
    this->speed = speed;
    this->angle = angle;

    this->strRoute_Id = route_Id;
    if (strRoadUserType =="motorist")
    {
        this->intUserType = MOTORIST;
        dblUtiltyDistance = par("motoristUtiltyDistance");
    }
    if (strRoadUserType =="cyclist")
    {
        this->intUserType = CYCLIST;
        dblUtiltyDistance = par("pedestrianUtiltyDistance");
    }
    if (strRoadUserType =="pedestrian")
    {
        this->intUserType = PEDESTRIAN;
        dblUtiltyDistance = par("pedestrianUtiltyDistance");
    }

    move.setStart(Coord(position.x, position.y, move.getCurrentPosition().z)); // keep z position
    move.setDirectionByVector(Coord(cos(angle), -sin(angle)));
    move.setSpeed(speed);


     if(speed > -1)
     {
         SSD = speed*dblDriverReactionDelay + (speed*speed)/(2*dblGravity*dblFrictionCoefficient);
     }
     else
         SSD = 0;

    isPreInitialized = true;
}

double SUMOTraCIMobilityV2::getSSD() const
{
    if(speed > -1)
    {
        return  speed*dblDriverReactionDelay + (speed*speed)/(2*dblGravity*dblFrictionCoefficient);
    }
    else
        return  0;
}

void SUMOTraCIMobilityV2::nextPosition(const Coord& position, std::string road_id, double speed, double angle)
{
    if (debug) EV << "Vehicle Id: "<<this->getId() << ": nextPosition " << position.x << " " << position.y << " " << road_id << " " << speed << " " << angle << std::endl;
    isPreInitialized = false;
    nextPos = position;
    this->road_id = road_id;
    this->speed = speed;
    this->angle = angle;

    Coord testPosNormalLeft, testPosNormalRight, testPosBottomLeft, testPosBottomRight;

    //coordinates used for cone-alike  view field
    Coord testPosNormalViewDepthCone, testPosNormalViewDepthConeBottomLeft, testPosNormalViewDepthConeBottomRight, testPosNormalViewDepthConeTopRight, testPosNormalViewDepthConeTopLeft;

    Coord testPosOrigin = position;

    testPosNormalViewDepthCone = position;

    //For constructing the cone-alike rear view field front
    testPosNormalViewDepthCone.y += dblViewDepht *cos(M_PI/2 + angle) ;
    testPosNormalViewDepthCone.x += dblViewDepht *sin(M_PI/2 + angle);

    testPosNormalViewDepthConeBottomLeft = testPosNormalViewDepthCone;
    testPosNormalViewDepthConeBottomLeft.x += dblViewDepthConeNearRadius*sin(M_PI + angle);
    testPosNormalViewDepthConeBottomLeft.y += dblViewDepthConeNearRadius*cos(M_PI + angle);

    testPosNormalViewDepthConeBottomRight = testPosNormalViewDepthCone;
    testPosNormalViewDepthConeBottomRight.x -= dblViewDepthConeNearRadius*sin(M_PI + angle);
    testPosNormalViewDepthConeBottomRight.y -= dblViewDepthConeNearRadius*cos(M_PI + angle);

    testPosNormalViewDepthConeTopLeft = position;
    testPosNormalViewDepthConeTopLeft.x += dblViewDepthConeFarRadius*sin(M_PI+angle);
    testPosNormalViewDepthConeTopLeft.y += dblViewDepthConeFarRadius*cos(M_PI+angle);

    testPosNormalViewDepthConeTopRight = position;
    testPosNormalViewDepthConeTopRight.x -= dblViewDepthConeFarRadius*sin(M_PI+angle);
    testPosNormalViewDepthConeTopRight.y -= dblViewDepthConeFarRadius*cos(M_PI+angle);

    visualFieldFront.clear();
    visualFieldFront.push_back(testPosNormalViewDepthConeTopRight);
    visualFieldFront.push_back(testPosNormalViewDepthConeBottomRight);
    visualFieldFront.push_back(testPosNormalViewDepthConeBottomLeft);
    visualFieldFront.push_back(testPosNormalViewDepthConeTopLeft);
    visualFieldFront.push_back(testPosNormalViewDepthConeTopRight);

    //For constructing the cone-alike rear view field
    testPosNormalViewDepthCone = position;
    testPosNormalViewDepthCone.y -= dblViewDepht *cos(M_PI/2 + angle) ;
    testPosNormalViewDepthCone.x -= dblViewDepht *sin(M_PI/2 + angle);

    testPosNormalViewDepthConeBottomLeft = testPosNormalViewDepthCone;
    testPosNormalViewDepthConeBottomLeft.x += dblViewDepthConeNearRadius*sin(M_PI + angle);
    testPosNormalViewDepthConeBottomLeft.y += dblViewDepthConeNearRadius*cos(M_PI + angle);

    testPosNormalViewDepthConeBottomRight = testPosNormalViewDepthCone;
    testPosNormalViewDepthConeBottomRight.x -= dblViewDepthConeNearRadius*sin(M_PI + angle);
    testPosNormalViewDepthConeBottomRight.y -= dblViewDepthConeNearRadius*cos(M_PI + angle);

    testPosNormalViewDepthConeTopLeft = position;
    testPosNormalViewDepthConeTopLeft.x += dblViewDepthConeFarRadius*sin(M_PI+angle);
    testPosNormalViewDepthConeTopLeft.y += dblViewDepthConeFarRadius*cos(M_PI+angle);

    testPosNormalViewDepthConeTopRight = position;
    testPosNormalViewDepthConeTopRight.x -= dblViewDepthConeFarRadius*sin(M_PI+angle);
    testPosNormalViewDepthConeTopRight.y -= dblViewDepthConeFarRadius*cos(M_PI+angle);

    visualFieldRear.clear();
    visualFieldRear.push_back(testPosNormalViewDepthConeTopRight);
    visualFieldRear.push_back(testPosNormalViewDepthConeBottomRight);
    visualFieldRear.push_back(testPosNormalViewDepthConeBottomLeft);
    visualFieldRear.push_back(testPosNormalViewDepthConeTopLeft);
    visualFieldRear.push_back(testPosNormalViewDepthConeTopRight);

    if (annotations && drawRoadUserViewField)
    {
        viewerFront  = annotations->drawPolygon(visualFieldFront, "blue", annotationGroupFront);
        viewerRear  = annotations->drawPolygon(visualFieldRear, "blue", annotationGroupRear);


        if(isFirstViewField)
            isFirstViewField = false;
        else
        {
            annotations->erase(preViewerFront);
            annotations->erase(preViewerRear);
        }
        preViewerFront = viewerFront;
        preViewerRear = viewerRear;
    }

    //07/06/2012 LSP - try to make sure the view field polygon is ready before the signal is emitted.
    changePosition();
}

void SUMOTraCIMobilityV2::changePosition()
{
    Enter_Method("changePosition()");
    // ensure we're not called twice in one time step
    ASSERT(lastUpdate != simTime());


    // keep statistics (for current step)

    //01/08/2012 LSP - to reduce the data file size
    //currentPosXVec.record(move.getStartPos().x);
    //currentPosYVec.record(move.getStartPos().y);

    // keep statistics (relative to last step)
    if (statistics.startTime != simTime()) {
        simtime_t updateInterval = simTime() - this->lastUpdate;
        this->lastUpdate = simTime();
        double distance = move.getStartPos().distance(Coord(nextPos.x, nextPos.y, move.getCurrentPosition().z));
        statistics.totalDistance += distance;
        statistics.totalTime += updateInterval;
        if (speed != -1) {
            SSD = speed*dblDriverReactionDelay + (speed*speed)/(2*dblGravity*dblFrictionCoefficient);

            statistics.minSpeed = std::min(statistics.minSpeed, speed);
            statistics.maxSpeed = std::max(statistics.maxSpeed, speed);
            statistics.averageSpeed += speed;
            statistics.countCollectedSpeed++;

            //currentSpeedVec.record(speed);
            if (last_speed != -1) {
                double acceleration = (speed - last_speed) / updateInterval;
                double co2emission = calculateCO2emission(speed, acceleration);
                //01/08/2012 - to reduce the data file size
                //currentAccelerationVec.record(acceleration);
                //currentCO2EmissionVec.record(co2emission);
                statistics.totalCO2Emission+=co2emission * updateInterval.dbl();
            }
            last_speed = speed;
        } else {
            SSD = 0;
            last_speed = -1;
            speed = -1;
        }
    }

    move.setStart(Coord(nextPos.x, nextPos.y, move.getCurrentPosition().z)); // keep z position
    move.setDirectionByVector(Coord(cos(angle), -sin(angle)));
    move.setSpeed(speed);
    if (ev.isGUI()) updateDisplayString();
    fixIfHostGetsOutside();
    updatePosition();
}

void SUMOTraCIMobilityV2::updateDisplayString() {
    ASSERT(-M_PI <= angle);
    ASSERT(angle < M_PI);

    getParentModule()->getDisplayString().setTagArg("b", 2, "rect");
    getParentModule()->getDisplayString().setTagArg("b", 3, "red");
    getParentModule()->getDisplayString().setTagArg("b", 4, "red");
    getParentModule()->getDisplayString().setTagArg("b", 5, "0");

    EV<<" SUMOTraCIMobilityV2::updateDisplayString():getDisplayString(): car("<<getParentModule()->getIndex()<< ") : angle "<<angle<<endl;

    if (angle < -M_PI + 0.5 * M_PI_4 * 1) {
        getParentModule()->getDisplayString().setTagArg("t", 0, "\u2190");
        getParentModule()->getDisplayString().setTagArg("b", 0, "4");
        getParentModule()->getDisplayString().setTagArg("b", 1, "2");
    }
    else if (angle < -M_PI + 0.5 * M_PI_4 * 3) {
        getParentModule()->getDisplayString().setTagArg("t", 0, "\u2199");
        getParentModule()->getDisplayString().setTagArg("b", 0, "3");
        getParentModule()->getDisplayString().setTagArg("b", 1, "3");
    }
    else if (angle < -M_PI + 0.5 * M_PI_4 * 5) {
        getParentModule()->getDisplayString().setTagArg("t", 0, "\u2193");
        getParentModule()->getDisplayString().setTagArg("b", 0, "2");
        getParentModule()->getDisplayString().setTagArg("b", 1, "4");
    }
    else if (angle < -M_PI + 0.5 * M_PI_4 * 7) {
        getParentModule()->getDisplayString().setTagArg("t", 0, "\u2198");
        getParentModule()->getDisplayString().setTagArg("b", 0, "3");
        getParentModule()->getDisplayString().setTagArg("b", 1, "3");
    }
    else if (angle < -M_PI + 0.5 * M_PI_4 * 9) {
        getParentModule()->getDisplayString().setTagArg("t", 0, "\u2192");
        getParentModule()->getDisplayString().setTagArg("b", 0, "4");
        getParentModule()->getDisplayString().setTagArg("b", 1, "2");
    }
    else if (angle < -M_PI + 0.5 * M_PI_4 * 11) {
        getParentModule()->getDisplayString().setTagArg("t", 0, "\u2197");
        getParentModule()->getDisplayString().setTagArg("b", 0, "3");
        getParentModule()->getDisplayString().setTagArg("b", 1, "3");
    }
    else if (angle < -M_PI + 0.5 * M_PI_4 * 13) {
        getParentModule()->getDisplayString().setTagArg("t", 0, "\u2191");
        getParentModule()->getDisplayString().setTagArg("b", 0, "2");
        getParentModule()->getDisplayString().setTagArg("b", 1, "4");
    }
    else if (angle < -M_PI + 0.5 * M_PI_4 * 15) {
        getParentModule()->getDisplayString().setTagArg("t", 0, "\u2196");
        getParentModule()->getDisplayString().setTagArg("b", 0, "3");
        getParentModule()->getDisplayString().setTagArg("b", 1, "3");
    }
    else {
        getParentModule()->getDisplayString().setTagArg("t", 0, "\u2190");
        getParentModule()->getDisplayString().setTagArg("b", 0, "4");
        getParentModule()->getDisplayString().setTagArg("b", 1, "2");
    }
}

void SUMOTraCIMobilityV2::fixIfHostGetsOutside()
{
    Coord dummy = move.getStartPos();
    double dum;

    handleIfOutside( RAISEERROR, dummy, dummy, dummy, dum);
}

double SUMOTraCIMobilityV2::calculateCO2emission(double v, double a) const {
    // Calculate CO2 emission parameters according to:
    // Cappiello, A. and Chabini, I. and Nam, E.K. and Lue, A. and Abou Zeid, M., "A statistical model of vehicle emissions and fuel consumption," IEEE 5th International Conference on Intelligent Transportation Systems (IEEE ITSC), pp. 801-809, 2002

    double A = 1000 * 0.1326; // W/m/s
    double B = 1000 * 2.7384e-03; // W/(m/s)^2
    double C = 1000 * 1.0843e-03; // W/(m/s)^3
    double M = 1325.0; // kg

    // power in W
    double P_tract = A*v + B*v*v + C*v*v*v + M*a*v; // for sloped roads: +M*g*sin_theta*v

    /*
    // "Category 7 vehicle" (e.g. a '92 Suzuki Swift)
    double alpha = 1.01;
    double beta = 0.0162;
    double delta = 1.90e-06;
    double zeta = 0.252;
    double alpha1 = 0.985;
    */

    // "Category 9 vehicle" (e.g. a '94 Dodge Spirit)
    double alpha = 1.11;
    double beta = 0.0134;
    double delta = 1.98e-06;
    double zeta = 0.241;
    double alpha1 = 0.973;

    if (P_tract <= 0) return alpha1;
    return alpha + beta*v*3.6 + delta*v*v*v*(3.6*3.6*3.6) + zeta*a*v;
}

