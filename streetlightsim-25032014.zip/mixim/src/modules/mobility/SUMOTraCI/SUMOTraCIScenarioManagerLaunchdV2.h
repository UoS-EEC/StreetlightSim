//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#ifndef __MIXIM_SUMOTRACISCENARIOMANAGERLAUNCHDV2_H_
#define __MIXIM_SUMOTRACISCENARIOMANAGERLAUNCHDV2_H_

#include <omnetpp.h>

/**
 * TODO - Generated class
 */

#include "mobility/SUMOTraCI/SUMOTraCIScenarioManagerV2.h"

/**
 * A TraCIScenarioManager that interacts with sumo-launchd
 *
 * @author Christoph Sommer
 */
class SUMOTraCIScenarioManagerLaunchdV2 : public SUMOTraCIScenarioManagerV2
{
    public:

        virtual ~SUMOTraCIScenarioManagerLaunchdV2();
        virtual void initialize(int stage);
        virtual void finish();

    protected:

        cXMLElement* launchConfig; /**< launch configuration to send to sumo-launchd */
        int seed; /**< seed value to set in launch configuration, if missing (-1: current run number) */

        virtual void init_traci();
};

class SUMOTraCIScenarioManagerLaunchdV2Access
{
    public:
    SUMOTraCIScenarioManagerLaunchdV2* get() {
            return FindModule<SUMOTraCIScenarioManagerLaunchdV2*>::findGlobalModule();
        };
};

#endif
