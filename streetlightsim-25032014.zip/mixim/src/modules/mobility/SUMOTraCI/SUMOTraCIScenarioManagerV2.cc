//
// Copyright (C) 2006-2011 Christoph Sommer <christoph.sommer@uibk.ac.at>
//
// Documentation for these modules is at http://veins.car2x.org/
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

#include <fstream>
#include <vector>
#include <algorithm>
#include <stdexcept>

#define WANT_WINSOCK2
#include <platdep/sockets.h>
#if defined(_WIN32) || defined(__WIN32__) || defined(WIN32) || defined(__CYGWIN__) || defined(_WIN64)
#include <ws2tcpip.h>
#else
#include <netinet/tcp.h>
#include <netdb.h>
#include <arpa/inet.h>
#endif


#define MYSOCKET (*(SOCKET*)socketPtr)

#define MYDEBUG EV

#define HOURTIME 3600

#include "mobility/SUMOTraCI/SUMOTraCIScenarioManagerV2.h"
#include "mobility/SUMOTraCI/SUMOTraCIConstants.h"
#include "mobility/SUMOTraCI/SUMOTraCIMobilityV2.h"
#include "obstacle/ObstacleControl.h"
#include "mobility/Streetlight/StreetlightMobilityV2.h"

#include "time.h"
#include "StreetlightApplLayer.h"

Define_Module(SUMOTraCIScenarioManagerV2);

SUMOTraCIScenarioManagerV2::~SUMOTraCIScenarioManagerV2() {
    cancelAndDelete(executeOneTimestepTrigger);
    cancelAndDelete(msgTrafficModeDelayEnd);
}

void SUMOTraCIScenarioManagerV2::initialize(int stage) {
    cSimpleModule::initialize(stage);
    if (stage != 1) {
        return;
    }

    debug = par("debug");
    updateInterval = par("updateInterval");


    moduleType = par("moduleType").stdstringValue();
    moduleName = par("moduleName").stdstringValue();
    moduleDisplayString = par("moduleDisplayString").stdstringValue();

    poleModuleDisplayString = par("poleModuleDisplayString").stdstringValue();
    poleModuleType = par("poleModuleType").stdstringValue();
    poleModuleName = par("poleModuleName").stdstringValue();

    host = par("host").stdstringValue();
    port = par("port");
    autoShutdown = par("autoShutdown");
    margin = par("margin");
    std::string roiRoads_s = par("roiRoads");
    std::string roiRects_s = par("roiRects");

    /*
     * to record the total number of vehicle generate by time step
     */

    intCollectTotalRoadUserByTimeStep = par("collectTotalRoadUserByTimeStep");

    /*
     * Road user insertion mode
     */
    if(strcmp(par("roadTrafficInsertionMode").stringValue(), "fix_loc") == 0)
    {
        RUInsertionMode = FIX_LOCATION;
    }
    else if(strcmp(par("roadTrafficInsertionMode").stringValue(), "rand_loc") == 0)
    {
        RUInsertionMode = RANDOM_LOCATION;
    }
    else
        error("SUMOTraCIScenarioManagerV2::initialize: Road traffic insertion mode error.  Check NED file and omnetpp.ini file");

    /*
    * To specify the duration of path discovery period
    */
    intTrafficModeDelay = par("intTrafficModeDelay");
    intNetwDiscoveryDuration = par("intNetwDiscoveryDuration");
    boolTrafficModelDelayEnd = false;

    if(intNetwDiscoveryDuration > intTrafficModeDelay)
    {
        error("SUMOTraCIScenarioManagerV2::initialize: Network discovery duration is larger than traffic delay duration.  Check NED and omnetpp.ini setting");
    }
    //opp_warning(" SUMOTraCIScenarioManagerV2::initialize : intTrafficModeDelay : %d",intTrafficModeDelay);

    msgTrafficModeDelayEnd = new cMessage("msgTrafficModeDelayEnd");
    scheduleAt(intTrafficModeDelay,msgTrafficModeDelayEnd);
    triggerTrafficModelSignal = registerSignal("triggerTrafficModel");
    simulation.getSystemModule()->subscribe(triggerTrafficModelSignal,this);
    //simulation.getSystemModule()->subscribe(triggerTrafficModelSignal,this);

    // parse roiRoads
    roiRoads.clear();
    std::istringstream roiRoads_i(roiRoads_s);
    std::string road;
    while (std::getline(roiRoads_i, road, ' ')) {
        roiRoads.push_back(road);
    }

    // parse roiRects
    roiRects.clear();
    std::istringstream roiRects_i(roiRects_s);
    std::string rect;
    while (std::getline(roiRects_i, rect, ' ')) {
        std::istringstream rect_i(rect);
        double x1; rect_i >> x1; ASSERT(rect_i);
        char c1; rect_i >> c1; ASSERT(rect_i);
        double y1; rect_i >> y1; ASSERT(rect_i);
        char c2; rect_i >> c2; ASSERT(rect_i);
        double x2; rect_i >> x2; ASSERT(rect_i);
        char c3; rect_i >> c3; ASSERT(rect_i);
        double y2; rect_i >> y2; ASSERT(rect_i);
        roiRects.push_back(std::pair<TraCICoord, TraCICoord>(TraCICoord(x1, y1), TraCICoord(x2, y2)));
    }

    nextNodeVectorIndex = 0;
    nextPoleVectorIndex = 0;  //03/04/2012 LSP

    intCurrentTotalActiveHost = 0;

    hosts.clear();
    poleHosts.clear();

    subscribedVehicles.clear();
    activeVehicleCount = 0;
    autoShutdownTriggered = false;

    executeOneTimestepTrigger = new cMessage("step");

    world = FindModule<BaseWorldUtility*>::findGlobalModule();
    if (world == NULL) error("Could not find BaseWorldUtility module");

    /*
     * 28-03-2012 LSP
     * Veins uses ConnectionManager to establish network connection between vehicle.
     * This is not required for StreetlightSim.
     *

    cc = FindModule<BaseConnectionManager*>::findGlobalModule();
    if (cc == NULL) error("Could not find BaseConnectionManager module");

     */


    /*
     * LSP
     * loading traffic route into the StreetlightSim.
     * The Traffic route is generated by SUMO Tools.
     */

    xmlNetworkRoute = par("route_file").xmlValue();
    if (xmlNetworkRoute != NULL)
        loadNetworkRoute(xmlNetworkRoute);

    MYDEBUG << "SUMOTraCIScenarioManagerV2 connecting to TraCI server" << endl;

    socketPtr = 0;
    connect();
    init_traci();

    /* 03/05/2012 LSP to register active mobile node as per simulation time **/
    activeMobileNodeSignal = registerSignal("activeMobileNode");



    whichRouteTakenSignal = registerSignal("whichRouteTaken");
    //noMobileNodeSignal = registerSignal("noMobileNode");
    errorAddVehicleCountSignal = registerSignal("errorAddVehicleCount");

    totalRoadUserByTimeStepSignal = registerSignal("totalRoadUserByTimeStep");
    totalLamppostSignal = registerSignal("totalLamppost");

    totalMotoristSignal = registerSignal("totalMotorist");
    totalCyclistSignal = registerSignal("totalCyclist");
    totalPedestrianSignal = registerSignal("totalPedestrian");

    //To determine which test setting is used.
    intWhichTestSetting = par("testSetting");

    //for different traffic volume based on average vehicle per hour.
    intTrafficFlow = par ("trafficFlow");

    //To define constant vehicle speed
    intVehicleConstantSpeed = par("vehicleSpeed").doubleValue();

    //To hardcode the total vehicle in the simulation
    intNFVehicleforVerification = par("totalNumRoadUser");

    previoustimeToAddVehicle = simTime().dbl();
    dblTimeBtwCars = par("timeBtwCars");

    /*
     * 24/08/2013 - LSP
     * To define which traffic hour should the simulation starts
     * If trafficFromHour >  -1 then simulation will start injecting the traffic
     * according to the hour specified by trafficFromHour.
     */
    trafficFromHour = par("trafficFromHour");

    isTimeToAddVehicle = false;
    timeToAddVehicleCount = 0;
    intPreCurTrafficProfileTimeStep = 0;
    
    /*
     * LSP - 22/04/2013
     * Get pedestrian percentage
     */
    dblPedestrianPercentange = par("pedestrianPercentange").doubleValue();

    /*
     * Cyclist percentage is not in use at the moment. For future use
     */
    dblCyclistPercentange = par("cyclistPercentange").doubleValue();

    /*
     *LSP - 18/09/2013
     *if intTestRoute > 0 then the simulation is forced to use specified routeID
     */
    intTestRoute = par("evalRouteId");

    /*
     * Load the traffic profile
     */
    xmlTrafficProfile = par("traffic_profile").xmlValue();
    if(xmlTrafficProfile != NULL)
    {
       dblTrafficRatioPerDay = atof(xmlTrafficProfile->getAttribute("ratio"));
       loadTrafficProfile(xmlTrafficProfile);
    }

    intTotalPedestrian = 0;
    intTotalCyclist = 0;
    intTotalMotorist = 0;

    intTotalPedestrianByTimeStep = 0;
    intTotalCyclistByTimeStep = 0;
    intTotalMotoristByTimeStep = 0;


    time_t rawtime;
    struct tm * timeinfo;

    time(&rawtime);
    timeinfo = localtime(&rawtime);

    /*
     * LSP - 27/04/2012
     * Random generate traffic for setting 3
     */
    intTotalRandomGenerateTraffic = 0;
    intCountNoTrafficInjection =0;

}

void SUMOTraCIScenarioManagerV2::receiveSignal(cComponent *source, simsignal_t signalID, long l )
{
    if (signalID == triggerTrafficModelSignal)
    {
        /*
         * once receive the signal, the traffic model will start to execute.
         * the 10 seconds delay is for the network discovery process to settle, i.e. to ensure all the
         * network discovery messages are discarded from the network.
         *
         * Only for street lighting scheme = ADAPTIVE where WSN is used.
         */
        //scheduleAt(simTime()+10, executeOneTimestepTrigger);
        scheduleAt(simTime(), executeOneTimestepTrigger);
    }
}

std::string SUMOTraCIScenarioManagerV2::receiveTraCIMessage() {
    if (!socketPtr) error("Connection to TraCI server lost");

    uint32_t msgLength;
    {
        char buf2[sizeof(uint32_t)];
        uint32_t bytesRead = 0;
        while (bytesRead < sizeof(uint32_t)) {
            int receivedBytes = ::recv(MYSOCKET, reinterpret_cast<char*>(&buf2) + bytesRead, sizeof(uint32_t) - bytesRead, 0);
            if (receivedBytes > 0) {
                bytesRead += receivedBytes;
            } else if (receivedBytes == 0) {
                error("Connection to TraCI server closed unexpectedly. Check your server's log");
            } else {
                if (sock_errno() == EINTR) continue;
                if (sock_errno() == EAGAIN) continue;
                error("Connection to TraCI server lost. Check your server's log. Error message: %d: %s", sock_errno(), strerror(sock_errno()));
            }
        }
        SUMOTraCIBufferV2(std::string(buf2, sizeof(uint32_t))) >> msgLength;
    }

    uint32_t bufLength = msgLength - sizeof(msgLength);
    char buf[bufLength];
    {
        MYDEBUG << "Reading TraCI message of " << bufLength << " bytes" << endl;
        uint32_t bytesRead = 0;
        while (bytesRead < bufLength) {
            int receivedBytes = ::recv(MYSOCKET, reinterpret_cast<char*>(&buf) + bytesRead, bufLength - bytesRead, 0);
            if (receivedBytes > 0) {
                bytesRead += receivedBytes;
            } else if (receivedBytes == 0) {
                error("Connection to TraCI server closed unexpectedly. Check your server's log");
            } else {
                if (sock_errno() == EINTR) continue;
                if (sock_errno() == EAGAIN) continue;
                error("Connection to TraCI server lost. Check your server's log. Error message: %d: %s", sock_errno(), strerror(sock_errno()));
            }
        }
    }
    return std::string(buf, bufLength);
}

void SUMOTraCIScenarioManagerV2::loadTrafficProfile(cXMLElement* traffic_profile)
{

    cXMLElementList trafficProfileChild = traffic_profile->getChildrenByTagName("timestep");
    for(cXMLElementList::iterator step = trafficProfileChild.begin(); step != trafficProfileChild.end(); step++)
    {
        /*
         * LSP 11/04/2013
         * Updated to cater AADT
         *
         * Original statement is
         * mapTrafficProfile[atoi((*step)->getAttribute("id"))] = intTrafficFlow * (atoi((*step)->getAttribute("vol")))/100;
         */

        /*
         * Why 2 * intTrafficFlow * dblTrafficRatioWeekdayToWeekend ?
         * 2 represents three different days in a week.  There are (1) weekday, and (2) weekend
         * intTrafficFlow = annual average daily flow (AADT) or number of vehicle per day
         * dblTrafficRationWeekdayToWeekend is weight of traffic flow of the day.  Why - (AADT) only represent daily average thus it cannot represent the traffic flow
         * weight of the day.  Based on DoT statistic data, weekday have higher traffic flow weight compared to Sunday and Saturday.
         *
         * (atoi((*step)->getAttribute("vol")))/100 is ratio of normalized traffic flow distribution by time of the day
         */
        float fltTrafficPerTime = 2*intTrafficFlow * dblTrafficRatioPerDay * (atof((*step)->getAttribute("vol")));
        mapTrafficProfile[atoi((*step)->getAttribute("id"))] = floor(fltTrafficPerTime + 0.5);
    }

    /*
     * For debugging purpose
     * - print the content of the traffic profile XML
     */

    /*
    ev<<"SUMOTraCIScenarioManagerV2 : dblTrafficRatioPerDay : " << dblTrafficRatioPerDay<<endl;
    std::map<int, int> :: iterator pos;

    for(pos = mapTrafficProfile.begin(); pos != mapTrafficProfile.end(); ++pos)
    {
        ev<<"timestep id = " <<pos->first << " vol = " <<pos->second<<endl;
    }
    */
}

void SUMOTraCIScenarioManagerV2::loadNetworkRoute(cXMLElement* route_file)
{

    cXMLElementList routeFileChild = route_file->getChildrenByTagName("route");
    for(cXMLElementList::iterator step = routeFileChild.begin(); step != routeFileChild.end(); step++)
    {

        std::string::size_type pos = 0;

        std::string edges;
        std::string edgeType;

        if((*step)->getAttribute("edges") != NULL && (*step)->getAttribute("pathType") != NULL)
        {
            edges = (*step)->getAttribute("edges");
            edgeType = (*step)->getAttribute("pathType");
        }
        else
        {
            opp_error("SUMOTraCIScenarioManagerV2::loadNetworkRoute: incorrect format found in <rou.xml>");
        }

        pos = edges.find_first_of(" ");
        std::string substring(edges.substr(0, pos));

        /* format of street lane is edge with _0 or _1 depending on number of lane available for the edge */
        substring += std::string("_0");

        /* store the route information in the map */
        mapNetworkRoute[(*step)->getAttribute("id")] = substring;
        mapNetworkRouteType[(*step)->getAttribute("id")] = edgeType;
    }

    /*
     * For debugging purpose only
     * Print the available traffic routes and their types (for the pedestrian and motorist only).
     */
    /*
    std::map<std::string, std::string> :: iterator pos;
    for(pos = mapNetworkRoute.begin(); pos != mapNetworkRoute.end(); ++pos)
    {
        ev<<"route id = " <<pos->first << " edges = " <<pos->second<<endl;
    }

    for(pos = mapNetworkRouteType.begin(); pos != mapNetworkRouteType.end(); ++pos)
    {
        ev<<"route id = " <<pos->first << " pathType = " <<pos->second<<endl;
    }
    */

    /* load the road user types from the file */
    cXMLElementList vTypeChild = route_file->getChildrenByTagName("vtype");
    for(cXMLElementList::iterator step = vTypeChild.begin(); step != vTypeChild.end(); step++)
    {
        mapVType[(*step)->getAttribute("id")] = (*step)->getAttribute("maxSpeed");
    }
    /* For debugging purpose only
     * print the available road user types
     */
    /*
    for(pos = mapVType.begin(); pos != mapVType.end(); ++pos)
    {
           ev<<"vType id = " <<pos->first << " maxSpeed = " <<pos->second<<endl;
    }
    opp_warning("SUMOTraCIScenarioManagerV2::loadNetworkRoute");
    */
}

void SUMOTraCIScenarioManagerV2::sendTraCIMessage(std::string buf) {
    if (!socketPtr) error("Connection to TraCI server lost");

    {
        uint32_t msgLength = sizeof(uint32_t) + buf.length();
        SUMOTraCIBufferV2 buf2 = SUMOTraCIBufferV2();
        buf2 << msgLength;
        uint32_t bytesWritten = 0;
        while (bytesWritten < sizeof(uint32_t)) {
            size_t sentBytes = ::send(MYSOCKET, buf2.str().c_str() + bytesWritten, sizeof(uint32_t) - bytesWritten, 0);
            if (sentBytes > 0) {
                bytesWritten += sentBytes;
            } else {
                if (sock_errno() == EINTR) continue;
                if (sock_errno() == EAGAIN) continue;
                error("Connection to TraCI server lost. Check your server's log. Error message: %d: %s", sock_errno(), strerror(sock_errno()));
            }
        }
    }

    {
        //MYDEBUG << "Writing TraCI message of " << buf.length() << " bytes" << endl;
        uint32_t bytesWritten = 0;
        while (bytesWritten < buf.length()) {
            size_t sentBytes = ::send(MYSOCKET, buf.c_str() + bytesWritten, buf.length() - bytesWritten, 0);
            if (sentBytes > 0) {
                bytesWritten += sentBytes;
            } else {
                if (sock_errno() == EINTR) continue;
                if (sock_errno() == EAGAIN) continue;
                error("Connection to TraCI server lost. Check your server's log. Error message: %d: %s", sock_errno(), strerror(sock_errno()));
            }
        }
    }
}

std::string SUMOTraCIScenarioManagerV2::makeTraCICommand(uint8_t commandId, SUMOTraCIBufferV2 buf) {
    if (sizeof(uint8_t) + sizeof(uint8_t) + buf.str().length() > 0xFF) {
        ev<< "SUMOTraCIScenarioManagerV2::makeTraCICommand:1"<<endl;
        uint32_t len = sizeof(uint8_t) + sizeof(uint32_t) + sizeof(uint8_t) + buf.str().length();
        return (SUMOTraCIBufferV2() << static_cast<uint8_t>(0) << len << commandId).str() + buf.str();
    }
    uint8_t len = sizeof(uint8_t) + sizeof(uint8_t) + buf.str().length();
    ev<< "SUMOTraCIScenarioManagerV2::makeTraCICommand:2"<<endl;
    return (SUMOTraCIBufferV2() << len << commandId).str() + buf.str();
}

SUMOTraCIScenarioManagerV2::SUMOTraCIBufferV2 SUMOTraCIScenarioManagerV2::queryTraCI(uint8_t commandId, const SUMOTraCIBufferV2& buf) {
    sendTraCIMessage(makeTraCICommand(commandId, buf));

    SUMOTraCIBufferV2 obuf(receiveTraCIMessage());
    uint8_t cmdLength; obuf >> cmdLength;
    uint8_t commandResp; obuf >> commandResp;
    ASSERT(commandResp == commandId);
    uint8_t result; obuf >> result;
    std::string description; obuf >> description;
    if (result == RTYPE_NOTIMPLEMENTED) error("TraCI server reported command 0x%2x not implemented (\"%s\"). Might need newer version.", commandId, description.c_str());
    if (result == RTYPE_ERR) error("TraCI server reported error executing command 0x%2x (\"%s\").", commandId, description.c_str());
    ASSERT(result == RTYPE_OK);
    return obuf;
}

SUMOTraCIScenarioManagerV2::SUMOTraCIBufferV2 SUMOTraCIScenarioManagerV2::queryTraCIOptional(uint8_t commandId, const SUMOTraCIBufferV2& buf, bool& success, std::string* errorMsg) {
    sendTraCIMessage(makeTraCICommand(commandId, buf));

    SUMOTraCIBufferV2 obuf(receiveTraCIMessage());
    uint8_t cmdLength; obuf >> cmdLength;
    uint8_t commandResp; obuf >> commandResp;
    ASSERT(commandResp == commandId);
    uint8_t result; obuf >> result;
    std::string description; obuf >> description;
    success = (result == RTYPE_OK);
    if (errorMsg) *errorMsg = description;
    return obuf;
}

void SUMOTraCIScenarioManagerV2::connect() {
    if (initsocketlibonce() != 0) error("Could not init socketlib");

    in_addr addr;
    struct hostent* host_ent;
    struct in_addr saddr;

    saddr.s_addr = inet_addr(host.c_str());
    if (saddr.s_addr != static_cast<unsigned int>(-1)) {
        addr = saddr;
    } else if ((host_ent = gethostbyname(host.c_str()))) {
        addr = *((struct in_addr*) host_ent->h_addr_list[0]);
    } else {
        error("Invalid TraCI server address: %s", host.c_str());
        return;
    }

    sockaddr_in address;
    memset((char*) &address, 0, sizeof(address));
    address.sin_family = AF_INET;
    address.sin_port = htons(port);
    address.sin_addr.s_addr = addr.s_addr;

    socketPtr = new SOCKET();
    MYSOCKET = ::socket(AF_INET, SOCK_STREAM, 0);
    if (MYSOCKET < 0) error("Could not create socket to connect to TraCI server");

    if (::connect(MYSOCKET, (sockaddr const*) &address, sizeof(address)) < 0) {
        error("Could not connect to TraCI server. Make sure it is running and not behind a firewall. Error message: %d: %s", sock_errno(), strerror(sock_errno()));
    }

    {
        int x = 1;
        ::setsockopt(MYSOCKET, IPPROTO_TCP, TCP_NODELAY, (const char*) &x, sizeof(x));
    }
}

void SUMOTraCIScenarioManagerV2::init_traci() {
    {
        std::pair<uint32_t, std::string> version = SUMOTraCIScenarioManagerV2::commandGetVersion();
        uint32_t apiVersion = version.first;
        std::string serverVersion = version.second;

        if ((apiVersion == 2) || (apiVersion == 3)) {
            MYDEBUG << "TraCI server \"" << serverVersion << "\" reports API version " << apiVersion << endl;
        }
        else {
            error("SUMOTraCIScenarioManagerV2::init_traci::TraCI server \"%s\" reports API version %d. This server is unsupported.", serverVersion.c_str(), apiVersion);
        }

    }
    {
        // query road network boundaries
        SUMOTraCIBufferV2 buf = queryTraCI(CMD_GET_SIM_VARIABLE, SUMOTraCIBufferV2() << static_cast<uint8_t>(VAR_NET_BOUNDING_BOX) << std::string("sim0"));
        uint8_t cmdLength_resp; buf >> cmdLength_resp;
        uint8_t commandId_resp; buf >> commandId_resp; ASSERT(commandId_resp == RESPONSE_GET_SIM_VARIABLE);
        uint8_t variableId_resp; buf >> variableId_resp; ASSERT(variableId_resp == VAR_NET_BOUNDING_BOX);
        std::string simId; buf >> simId;
        uint8_t typeId_resp; buf >> typeId_resp; ASSERT(typeId_resp == TYPE_BOUNDINGBOX);
        double x1; buf >> x1;
        double y1; buf >> y1;
        double x2; buf >> x2;
        double y2; buf >> y2;
        ASSERT(buf.eof());

        netbounds1 = TraCICoord(x1, y1);
        netbounds2 = TraCICoord(x2, y2);
        //MYDEBUG << "TraCI reports network boundaries (" << x1 << ", " << y1 << ")-(" << x2 << ", " << y2 << ")" << endl;
        //MYDEBUG << "WARNING: Playground size (" << world->getPgs()->x << ", " << world->getPgs()->y << ") might be too small for vehicle at network bounds (" << traci2omnet(netbounds2).x << ", " << traci2omnet(netbounds1).y << ")" << endl;

        if ((traci2omnet(netbounds2).x > world->getPgs()->x) || (traci2omnet(netbounds1).y > world->getPgs()->y))
            MYDEBUG << "WARNING: Playground size (" << world->getPgs()->x << ", " << world->getPgs()->y << ") might be too small for vehicle at network bounds (" << traci2omnet(netbounds2).x << ", " << traci2omnet(netbounds1).y << ")" << endl;
    }
    {
        // subscribe to list of vehicle ids
        uint32_t beginTime = 0;
        uint32_t endTime = 0x7FFFFFFF;
        std::string objectId = "";
        uint8_t variableNumber = 1;
        uint8_t variable1 = ID_LIST;
        SUMOTraCIBufferV2 buf = queryTraCI(CMD_SUBSCRIBE_VEHICLE_VARIABLE, SUMOTraCIBufferV2() << beginTime << endTime << objectId << variableNumber << variable1);
        struct timeval tStart, tEnd;
        gettimeofday(&tStart, NULL);
        processSubcriptionResult(buf);
        gettimeofday(&tEnd, NULL);
        double time_in_mili = timeval_substract(tEnd, tStart).tv_sec*1000 + timeval_substract(tEnd, tStart).tv_usec/1000 ;
        MYDEBUG<<"SUMOTraCIScenarioManagerV2::init_traci():: list of vehicle ids : time used: " <<time_in_mili<<endl;
        ASSERT(buf.eof());
    }
    {
        // subscribe to list of departed and arrived vehicles, as well as simulation time
        uint32_t beginTime = 0;
        uint32_t endTime = 0x7FFFFFFF;
        std::string objectId = "";
        uint8_t variableNumber = 3;
        uint8_t variable1 = VAR_DEPARTED_VEHICLES_IDS;
        uint8_t variable2 = VAR_ARRIVED_VEHICLES_IDS;
        uint8_t variable3 = VAR_TIME_STEP;
        SUMOTraCIBufferV2 buf = queryTraCI(CMD_SUBSCRIBE_SIM_VARIABLE, SUMOTraCIBufferV2() << beginTime << endTime << objectId << variableNumber << variable1 << variable2 << variable3);
        struct timeval tStart, tEnd;
        gettimeofday(&tStart, NULL);
        processSubcriptionResult(buf);
        gettimeofday(&tEnd, NULL);
        double time_in_mili = timeval_substract(tEnd, tStart).tv_sec*1000 + timeval_substract(tEnd, tStart).tv_usec/1000 ;
        MYDEBUG<<"SUMOTraCIScenarioManagerV2::init_traci():: list of departed and arrived vehicles : time used: " <<time_in_mili<<endl;
        ASSERT(buf.eof());
    }
    ObstacleControl* obstacles = ObstacleControlAccess().getIfExists();
    if (obstacles) {
        {
            // get list of polygons
            std::list<std::string> ids = commandGetPolygonIds();
            for (std::list<std::string>::iterator i = ids.begin(); i != ids.end(); ++i) {
                std::string id = *i;
                std::string typeId = commandGetPolygonTypeId(id);

                if (typeId == "building") {
                    std::list<Coord> coords = commandGetPolygonShape(id);
                    Obstacle obs(id, 50, 1); // building gets attenuation of 50 dB per wall, 1dB per meter
                    std::vector<Coord> shape;
                    std::copy(coords.begin(), coords.end(), std::back_inserter(shape));
                    obs.setShape(shape);
                    obstacles->add(obs);
                }
                /*
                 * 03/04/2012 LSP - try to check for lamp pole position
                 * typeId == "building_lamp" is hardcoded by Java OpenStreetMap Editor (JOSM)
                 * url : http://josm.openstreetmap.de/
                 */
                else if (typeId =="building_lamp"){
                    /*
                     * "building_lamp" is defined as a polygon in JOSM, thus more than one coordinate is loaded during run time.
                     * However, only one of the coordinates is used to defined the streetlight in OMNeT++.
                     */
                    std::list<Coord> coords = commandGetPolygonShape(id);
                    std::list<Coord>::iterator j;
                    Coord poleCoord;
                    for (j = coords.begin(); j != coords.end(); ++j) {
                        poleCoord = *j;
                        break;
                    }
                    addModulePole(id,poleModuleType,poleModuleName,poleModuleDisplayString, poleCoord);
                }
            }
        }
    }
}

void SUMOTraCIScenarioManagerV2::finish() {
    if (executeOneTimestepTrigger->isScheduled()) {
        cancelEvent(executeOneTimestepTrigger);
        delete executeOneTimestepTrigger;
        executeOneTimestepTrigger = 0;
    }

    if(msgTrafficModeDelayEnd->isScheduled())
    {
      cancelEvent(msgTrafficModeDelayEnd);
      delete(msgTrafficModeDelayEnd);
      msgTrafficModeDelayEnd = 0;
    }

    if (socketPtr) {
        closesocket(MYSOCKET);
        delete &MYSOCKET;
        socketPtr = 0;
    }

    while (hosts.begin() != hosts.end()) {
        deleteModule(hosts.begin()->first);
    }

    //LSP - 18/04/2012
    //release the memory of the poleHosts
    while(poleHosts.begin() != poleHosts.end()){
        deletePoleModule(poleHosts.begin()->first);
    }
    time_t rawtime;
       struct tm * timeinfo;

       time(&rawtime);
       timeinfo = localtime(&rawtime);

       recordScalar("totalMotorist",intTotalMotorist);
       recordScalar("totalCyclist",intTotalCyclist);
       recordScalar("totalPedestrian",intTotalPedestrian);

       simulation.getSystemModule()->unsubscribe(triggerTrafficModelSignal,this);

}

void SUMOTraCIScenarioManagerV2::handleMessage(cMessage *msg) {
    if (msg->isSelfMessage()) {
        handleSelfMsg(msg);
        return;
    }
    error("SUMOTraCIScenarioManagerV2 doesn't handle messages from other modules");
}

void SUMOTraCIScenarioManagerV2::handleSelfMsg(cMessage *msg) {
    if (msg == executeOneTimestepTrigger) {
        //09/08/2012 - LSP get time in milisecond
        struct timeval tStart, tEnd;

        //To time for the time required for execute the function "executeOneTimestep()"
        gettimeofday(&tStart, NULL);

        // For debugging purpose
        //To emit the total lamppost in the simulation for 10 simulation time.
        emit(totalLamppostSignal,(double)poleHosts.size());
        executeOneTimestep();
        /*
         * Finish the timing for "executeOneTimestep()"
         */
        gettimeofday(&tEnd, NULL);
        double time_in_mili = timeval_substract(tEnd, tStart).tv_sec*1000 + timeval_substract(tEnd, tStart).tv_usec/1000 ;
        /*
         * Print the total time used
         */
        //MYDEBUG<<" SUMOTraCIScenarioManagerV2::handleSelfMsg: Time used (ms):" << time_in_mili <<endl;
        return;
    }
    /*
     * The following condition is used when wireless sensor network (WSN) is used.
     * "msgTrafficModeDelayEnd" is used to allow WSN to initialize the necessary network setup
     */
    if (msg == msgTrafficModeDelayEnd)
    {
        boolTrafficModelDelayEnd = true;
        emit(triggerTrafficModelSignal,0);
        return;
    }

    error("SUMOTraCIScenarioManagerV2 received unknown self-message");
}

std::pair<uint32_t, std::string> SUMOTraCIScenarioManagerV2::commandGetVersion() {
    bool success = false;
    SUMOTraCIBufferV2 buf = queryTraCIOptional(CMD_GETVERSION, SUMOTraCIBufferV2(), success);

    if (!success) {
        ASSERT(buf.eof());
        return std::pair<uint32_t, std::string>(0, "(unknown)");
    }


    uint8_t cmdLength; buf >> cmdLength;
    uint8_t commandResp; buf >> commandResp;
    ASSERT(commandResp == CMD_GETVERSION);
    uint32_t apiVersion; buf >> apiVersion;
    std::string serverVersion; buf >> serverVersion;
    ASSERT(buf.eof());

    return std::pair<uint32_t, std::string>(apiVersion, serverVersion);
}

void SUMOTraCIScenarioManagerV2::commandSetSpeedMode(std::string nodeId, int32_t bitset) {
    uint8_t variableId = VAR_SPEEDSETMODE;
    uint8_t variableType = TYPE_INTEGER;
    SUMOTraCIBufferV2 buf = queryTraCI(CMD_SET_VEHICLE_VARIABLE, SUMOTraCIBufferV2() << variableId << nodeId << variableType << bitset);
    ASSERT(buf.eof());
}

void SUMOTraCIScenarioManagerV2::commandSetSpeed(std::string nodeId, double speed) {
    uint8_t variableId = VAR_SPEED;
    uint8_t variableType = TYPE_DOUBLE;
    SUMOTraCIBufferV2 buf = queryTraCI(CMD_SET_VEHICLE_VARIABLE, SUMOTraCIBufferV2() << variableId << nodeId << variableType << speed);
    ASSERT(buf.eof());
}

void SUMOTraCIScenarioManagerV2::commandChangeRoute(std::string nodeId, std::string roadId, double travelTime) {
    if (travelTime >= 0) {
        uint8_t variableId = VAR_EDGE_TRAVELTIME;
        uint8_t variableType = TYPE_COMPOUND;
        int32_t count = 2;
        uint8_t edgeIdT = TYPE_STRING;
        std::string edgeId = roadId;
        uint8_t newTimeT = TYPE_DOUBLE;
        double newTime = travelTime;
        SUMOTraCIBufferV2 buf = queryTraCI(CMD_SET_VEHICLE_VARIABLE, SUMOTraCIBufferV2() << variableId << nodeId << variableType << count << edgeIdT << edgeId << newTimeT << newTime);
        ASSERT(buf.eof());
    } else {
        uint8_t variableId = VAR_EDGE_TRAVELTIME;
        uint8_t variableType = TYPE_COMPOUND;
        int32_t count = 1;
        uint8_t edgeIdT = TYPE_STRING;
        std::string edgeId = roadId;
        SUMOTraCIBufferV2 buf = queryTraCI(CMD_SET_VEHICLE_VARIABLE, SUMOTraCIBufferV2() << variableId << nodeId << variableType << count << edgeIdT << edgeId);
        ASSERT(buf.eof());
    }
    {
        uint8_t variableId = CMD_REROUTE_TRAVELTIME;
        uint8_t variableType = TYPE_COMPOUND;
        int32_t count = 0;
        SUMOTraCIBufferV2 buf = queryTraCI(CMD_SET_VEHICLE_VARIABLE, SUMOTraCIBufferV2() << variableId << nodeId << variableType << count);
        ASSERT(buf.eof());
    }
}

double SUMOTraCIScenarioManagerV2::commandDistanceRequest(Coord position1, Coord position2, bool returnDrivingDistance) {
    TraCICoord p1 = omnet2traci(position1);
    TraCICoord p2 = omnet2traci(position2);
    SUMOTraCIBufferV2 buf = queryTraCI(CMD_DISTANCEREQUEST, SUMOTraCIBufferV2() << static_cast<uint8_t>(POSITION_2D) << double(p1.x) << double(p1.y) << static_cast<uint8_t>(POSITION_2D) << double(p2.x) << double(p2.y) << static_cast<uint8_t>(returnDrivingDistance ? REQUEST_DRIVINGDIST : REQUEST_AIRDIST));

    uint8_t cmdLength; buf >> cmdLength;
    uint8_t commandId; buf >> commandId;
    ASSERT(commandId == CMD_DISTANCEREQUEST);

    uint8_t flag; buf >> flag;
    ASSERT(flag == static_cast<uint8_t>(returnDrivingDistance ? REQUEST_DRIVINGDIST : REQUEST_AIRDIST));

    double distance; buf >> distance;

    ASSERT(buf.eof());

    return distance;
}

void SUMOTraCIScenarioManagerV2::commandStopNode(std::string nodeId, std::string roadId, double pos, uint8_t laneid, double radius, double waittime) {
    uint8_t variableId = CMD_STOP;
    uint8_t variableType = TYPE_COMPOUND;
    int32_t count = 4;
    uint8_t edgeIdT = TYPE_STRING;
    std::string edgeId = roadId;
    uint8_t stopPosT = TYPE_DOUBLE;
    double stopPos = pos;
    uint8_t stopLaneT = TYPE_BYTE;
    uint8_t stopLane = laneid;
    uint8_t durationT = TYPE_INTEGER;
    uint32_t duration = waittime * 1000;

    SUMOTraCIBufferV2 buf = queryTraCI(CMD_SET_VEHICLE_VARIABLE, SUMOTraCIBufferV2() << variableId << nodeId << variableType << count << edgeIdT << edgeId << stopPosT << stopPos << stopLaneT << stopLane << durationT << duration);
    ASSERT(buf.eof());
}

void SUMOTraCIScenarioManagerV2::commandSetTrafficLightProgram(std::string trafficLightId, std::string program) {
    SUMOTraCIBufferV2 buf = queryTraCI(CMD_SET_TL_VARIABLE, SUMOTraCIBufferV2() << static_cast<uint8_t>(TL_PROGRAM) << trafficLightId << static_cast<uint8_t>(TYPE_STRING) << program);
    ASSERT(buf.eof());
}

void SUMOTraCIScenarioManagerV2::commandSetTrafficLightPhaseIndex(std::string trafficLightId, int32_t index) {
    SUMOTraCIBufferV2 buf = queryTraCI(CMD_SET_TL_VARIABLE, SUMOTraCIBufferV2() << static_cast<uint8_t>(TL_PHASE_INDEX) << trafficLightId << static_cast<uint8_t>(TYPE_INTEGER) << index);
    ASSERT(buf.eof());
}

std::list<std::string> SUMOTraCIScenarioManagerV2::commandGetPolygonIds() {
    std::list<std::string> res;

    std::string objectId = "";
    SUMOTraCIBufferV2 buf = queryTraCI(CMD_GET_POLYGON_VARIABLE, SUMOTraCIBufferV2() << static_cast<uint8_t>(ID_LIST) << objectId);

    // read additional RESPONSE_GET_POLYGON_VARIABLE sent back in response
    uint8_t cmdLength; buf >> cmdLength;
    if (cmdLength == 0) {
        uint32_t cmdLengthX;
        buf >> cmdLengthX;
    }
    uint8_t commandId; buf >> commandId;
    ASSERT(commandId == RESPONSE_GET_POLYGON_VARIABLE);
    uint8_t varId; buf >> varId;
    ASSERT(varId == ID_LIST);
    std::string polyId_r; buf >> polyId_r;
    uint8_t resType_r; buf >> resType_r;
    ASSERT(resType_r == TYPE_STRINGLIST);
    uint32_t count; buf >> count;
    for (uint32_t i = 0; i < count; i++) {
        std::string id; buf >> id;
        res.push_back(id);
    }

    ASSERT(buf.eof());

    return res;
}

std::string SUMOTraCIScenarioManagerV2::commandGetPolygonTypeId(std::string polyId) {
    std::string res;

    SUMOTraCIBufferV2 buf = queryTraCI(CMD_GET_POLYGON_VARIABLE, SUMOTraCIBufferV2() << static_cast<uint8_t>(VAR_TYPE) << polyId);

    // read additional RESPONSE_GET_POLYGON_VARIABLE sent back in response
    uint8_t cmdLength; buf >> cmdLength;
    if (cmdLength == 0) {
        uint32_t cmdLengthX;
        buf >> cmdLengthX;
    }
    uint8_t commandId; buf >> commandId;
    ASSERT(commandId == RESPONSE_GET_POLYGON_VARIABLE);
    uint8_t varId; buf >> varId;
    ASSERT(varId == VAR_TYPE);
    std::string polyId_r; buf >> polyId_r;
    ASSERT(polyId_r == polyId);
    uint8_t resType_r; buf >> resType_r;
    ASSERT(resType_r == TYPE_STRING);
    buf >> res;

    ASSERT(buf.eof());

    return res;
}

std::list<Coord> SUMOTraCIScenarioManagerV2::commandGetPolygonShape(std::string polyId) {
    std::list<Coord> res;

    SUMOTraCIBufferV2 buf = queryTraCI(CMD_GET_POLYGON_VARIABLE, SUMOTraCIBufferV2() << static_cast<uint8_t>(VAR_SHAPE) << polyId);

    // read additional RESPONSE_GET_POLYGON_VARIABLE sent back in response
    uint8_t cmdLength; buf >> cmdLength;
    if (cmdLength == 0) {
        uint32_t cmdLengthX;
        buf >> cmdLengthX;
    }
    uint8_t commandId; buf >> commandId;
    ASSERT(commandId == RESPONSE_GET_POLYGON_VARIABLE);
    uint8_t varId; buf >> varId;
    ASSERT(varId == VAR_SHAPE);
    std::string polyId_r; buf >> polyId_r;
    ASSERT(polyId_r == polyId);
    uint8_t resType_r; buf >> resType_r;
    ASSERT(resType_r == TYPE_POLYGON);
    uint8_t count; buf >> count;
    for (uint8_t i = 0; i < count; i++) {
        double x; buf >> x;
        double y; buf >> y;
        Coord pos = traci2omnet(TraCICoord(x, y));
        res.push_back(pos);
    }

    ASSERT(buf.eof());

    return res;
}

void SUMOTraCIScenarioManagerV2::commandSetPolygonShape(std::string polyId, std::list<Coord> points) {
    SUMOTraCIBufferV2 buf;
    uint8_t count = static_cast<uint8_t>(points.size());
    buf << static_cast<uint8_t>(VAR_SHAPE) << polyId << static_cast<uint8_t>(TYPE_POLYGON) << count;
    for (std::list<Coord>::const_iterator i = points.begin(); i != points.end(); ++i) {
        TraCICoord pos = omnet2traci(*i);
        buf << static_cast<double>(pos.x) << static_cast<double>(pos.y);
    }
    SUMOTraCIBufferV2 obuf = queryTraCI(CMD_SET_POLYGON_VARIABLE, buf);
    ASSERT(obuf.eof());
}

bool SUMOTraCIScenarioManagerV2::commandAddVehicle(std::string vehicleId, std::string vehicleTypeId, std::string routeId, std::string laneId, float emitPosition, float emitSpeed) {
    bool success = false;

    uint8_t variableId = ADD;
    uint8_t variableType_Compound = TYPE_COMPOUND;
    uint8_t variableType_String = TYPE_STRING;
    uint8_t variableType_Int = TYPE_INTEGER;
    uint8_t variableType_DOUBLE = TYPE_DOUBLE;
    uint8_t variableType_Byte = TYPE_BYTE;
    int numberOfElement = 6;
    int departTime = 0;

    double departSpeed = emitSpeed;
    double departPosition = emitPosition;

    uint8_t departLane = 0;
    SUMOTraCIBufferV2 a = SUMOTraCIBufferV2();
    SUMOTraCIBufferV2 b = SUMOTraCIBufferV2();

    SUMOTraCIBufferV2 buf = queryTraCIOptional(CMD_SET_VEHICLE_VARIABLE, b<<variableId<<vehicleId<<variableType_Compound<<numberOfElement<<variableType_String<<vehicleTypeId<<variableType_String<<routeId<<variableType_Int<<departTime<<variableType_DOUBLE<<departPosition<<variableType_DOUBLE<<departSpeed<<variableType_Byte<<departLane,success);

    ASSERT(buf.eof());
    return success;
}

//03/04/2012 LSP start - add new function addModulePole to create pole in OMNet++
void SUMOTraCIScenarioManagerV2::addModulePole(std::string nodeId, std::string type, std::string name, std::string displayString, const Coord& position)
{

    int32_t poleVectorIndex = nextPoleVectorIndex++;

    //to check all required cModule are correct
    cModule* parentModule = getParentModule();
    if(!parentModule) error("Parent Module not found");
    cModuleType* poleModuleType = cModuleType::get(type.c_str());
    if(!poleModuleType) error ("Module Type \"s\" not found", type.c_str());

    //create the module type
    cModule* poleModule = poleModuleType->create(name.c_str(),parentModule,poleVectorIndex,poleVectorIndex);
    poleModule->finalizeParameters();

    //update the module display tag!
    MYDEBUG <<"getDisplayString" <<endl;
    poleModule->getDisplayString().parse(displayString.c_str());

    /*
     * The tag arg "r" is used for communication radius thus,
     * tag arg "b" is used for streetlight operation representation
     */
    poleModule->getDisplayString().setTagArg("r",2,"black");
    poleModule->getDisplayString().setTagArg("r",3,"1");
    poleModule->getDisplayString().setTagArg("is",0,"s");

    poleModule->getDisplayString().setTagArg("b", 0, "10");
    poleModule->getDisplayString().setTagArg("b", 1, "10");
    poleModule->getDisplayString().setTagArg("b", 2, "oval");
    poleModule->getDisplayString().setTagArg("b", 3, "black");
    poleModule->getDisplayString().setTagArg("b", 5, "0");

    poleModule->buildInside();
    poleModule->scheduleStart((simTime()));

    StreetlightMobilityV2* mm;

    for (cModule::SubmoduleIterator iter(poleModule); !iter.end(); iter++) {
            cModule* submod = iter();
            mm = dynamic_cast<StreetlightMobilityV2*>(submod);
            if (!mm) {
                continue;
            }
            mm->preInitializePosition(position);
        }

    poleModule->callInitialize(0);

    //consider to delete the poleHosts as it can be done at Pole cModule's ConstSpeedMobility
    /*
     * 27/06/2013 LSP - for debugging purpose
     * Add the nodeID at application layer
     */

    StreetlightApplLayer* ptrAppl;
    for (cModule::SubmoduleIterator iter(poleModule); !iter.end(); iter++)
    {
           cModule* submod = iter();
           ptrAppl = dynamic_cast<StreetlightApplLayer*>(submod);
           if (!ptrAppl) {
               continue;
           }
           ptrAppl->setApplNodeID(nodeId);
       }

    poleHosts[nodeId] = poleModule;

}

// name: host;Car;i=vehicle.gif
void SUMOTraCIScenarioManagerV2::addModule(std::string nodeId, std::string type, std::string strRoadUserType, std::string name, std::string displayString, const Coord& position, std::string road_id, double speed, double angle, std::string route_Id) {
    ev<<"SUMOTraCIScenarioManagerV2::addModule : called at " << simTime()<<endl;
    if (hosts.find(nodeId) != hosts.end()) error("tried adding duplicate module");

    int32_t nodeVectorIndex = nextNodeVectorIndex++ ;


    cModule* parentmod = getParentModule();
    if (!parentmod) error("Parent Module not found");
    cModuleType* nodeType = cModuleType::get(type.c_str());
    if (!nodeType) error("Module Type \"%s\" not found", type.c_str());

    //TODO: this trashes the vectsize member of the cModule, although nobody seems to use it
    cModule* mod = nodeType->create(name.c_str(), parentmod, nodeVectorIndex, nodeVectorIndex);
    mod->finalizeParameters();
    mod->getDisplayString().parse(displayString.c_str());
    mod->buildInside();
    mod->scheduleStart(simTime() + updateInterval);

    for (cModule::SubmoduleIterator iter(mod); !iter.end(); iter++) {
        cModule* submod = iter();
        SUMOTraCIMobilityV2* mm = dynamic_cast<SUMOTraCIMobilityV2*>(submod);
        if (!mm) continue;
        mm->preInitialize(nodeId, strRoadUserType, position, road_id, speed, angle, route_Id);
    }
    mod->callInitialize();
    hosts[nodeId] = mod;

    // post-initialize myTraCIMobility
    for (cModule::SubmoduleIterator iter(mod); !iter.end(); iter++) {
        cModule* submod = iter();
        SUMOTraCIMobilityV2* mm = dynamic_cast<SUMOTraCIMobilityV2*>(submod);
        if (!mm) continue;
        mm->changePosition();
    }
}

cModule* SUMOTraCIScenarioManagerV2::getManagedModule(std::string nodeId) {
    if (hosts.find(nodeId) == hosts.end()) return 0;
    return hosts[nodeId];
}

cModule* SUMOTraCIScenarioManagerV2::getManagedPoleModule(std::string nodeId) {
    if (poleHosts.find(nodeId) == poleHosts.end()) return 0;
    return poleHosts[nodeId];
}

void SUMOTraCIScenarioManagerV2::deletePoleModule(std::string nodeId) {
    cModule* mod = getManagedPoleModule(nodeId);
    if (!mod)
        error("no pole with Id \"%s\" found", nodeId.c_str());

    poleHosts.erase(nodeId);
    mod->callFinish();
    mod->deleteModule();
}

void SUMOTraCIScenarioManagerV2::deleteModule(std::string nodeId) {

    cModule* mod = getManagedModule(nodeId);

    if (!mod)
        error("no vehicle with Id \"%s\" found", nodeId.c_str());

    hosts.erase(nodeId);
    mod->callFinish();
    mod->deleteModule();
}

bool SUMOTraCIScenarioManagerV2::isInRegionOfInterest(const TraCICoord& position, std::string road_id, double speed, double angle) {
    if ((roiRoads.size() == 0) && (roiRects.size() == 0)) return true;
    if (roiRoads.size() > 0) {
        for (std::list<std::string>::const_iterator i = roiRoads.begin(); i != roiRoads.end(); ++i) {
            if (road_id == *i) return true;
        }
    }
    if (roiRects.size() > 0) {
        for (std::list<std::pair<TraCICoord, TraCICoord> >::const_iterator i = roiRects.begin(); i != roiRects.end(); ++i) {
            if ((position.x >= i->first.x) && (position.y >= i->first.y) && (position.x <= i->second.x) && (position.y <= i->second.y)) return true;
        }
    }
    return false;
}

uint32_t SUMOTraCIScenarioManagerV2::getCurrentTimeMs()
{
    uint32_t intCurrentTimeMs = round(simTime().dbl()*1000);
    return intCurrentTimeMs;
}

void SUMOTraCIScenarioManagerV2::generateTraffic()
{
        bool isCommandAddVehicleSuccess = false;
        std::map<std::string, cModule*>::const_iterator i;

        /*
         * To collect number of vehicle hourly instead of second
         */
        //ev<<"SUMOTraCIScenarioManagerV2::generateTraffic() : intCountNoTrafficInjection : " << intCountNoTrafficInjection<<endl;

        /*
         * 24/08/2013 - LSP
         * Add the following codes to check whether simulation starts
         * from beginning or specified hour.
         */
        int intCurTrafficProfileTimeStep;
        if (trafficFromHour < 0)
            intCurTrafficProfileTimeStep = (int)(simTime().dbl()-intNetwDiscoveryDuration)/ HOURTIME; //intCurTrafficProfileTimeStep = (int)(simTime().dbl()-intTrafficModeDelay)/ HOURTIME;
        else
            intCurTrafficProfileTimeStep = trafficFromHour + (int)(simTime().dbl()-intNetwDiscoveryDuration)/ HOURTIME; //intCurTrafficProfileTimeStep = trafficFromHour + (int)(simTime().dbl()-intTrafficModeDelay)/ HOURTIME;

        if(intCurTrafficProfileTimeStep > intPreCurTrafficProfileTimeStep)
        {
            emit(activeMobileNodeSignal, timeToAddVehicleCount);
            intPreCurTrafficProfileTimeStep = intCurTrafficProfileTimeStep;
            //LSP - 25/03/2014
            //timeToAddVehicleCount = (int)getManagedHosts().size();
            timeToAddVehicleCount = timeToAddVehicleCount + (int)getManagedHosts().size();
            isTimeToAddVehicle = false;

            /*
             * To reset intTotalRandomGenerateTraffic when steps into new time slot (reset every hour)
             */
            intTotalRandomGenerateTraffic = 0;
            intCountNoTrafficInjection = 0;
        }
        std::map<int,int>::iterator itTrafficProfile = mapTrafficProfile.find(intCurTrafficProfileTimeStep);

        /*
         * For verification only allow one vehicle to be injected into the simulation.
         *
         * Original statement is :
         * if((timeToAddVehicle > 1) &&  (timeToAddVehicleCount <  itTrafficProfile->second))
         *
         * Update by check whichTotalNumVehicleToBeUsed.
         * If whichTotalNumVehicleToBeUsed < 0 then volume per hour is used
         * else set by user
         *
         */
        int whichTotalNumVehicleToBeUsed;
        int intNumberOfTrafficToBeRandomGenerated =0;

        if(itTrafficProfile != mapTrafficProfile.end())
            whichTotalNumVehicleToBeUsed = itTrafficProfile->second;
        else
            whichTotalNumVehicleToBeUsed = 0;


        if(intWhichTestSetting <= 0)
            error("Error in SUMOTraCIScenarioManagerV2::generateTraffic()::intWhichTestSetting");
        //else
        //    MYDEBUG<<"intWhichTestSetting : " <<intWhichTestSetting<<endl;

        /*
         * For this setting, road user(s) is uniformly inserted.
         */
        if (intWhichTestSetting == 1)
        {
            if(intTrafficFlow < 0)
                opp_error("Error in SUMOTraCIScenarioManagerV2::generateTraffic::intWhichTestSetting = 1::intTrafficFlow");

            if((simTime().dbl() - previoustimeToAddVehicle) >= ((HOURTIME/(double)( whichTotalNumVehicleToBeUsed)) - updateInterval.dbl()))
            {
                isTimeToAddVehicle = true;
                previoustimeToAddVehicle = simTime().dbl();
                intNumberOfTrafficToBeRandomGenerated = 1;
            }
        }

        /*
         * This test setting is for generating road user randomly.
         * All the simulation results are based on this test setting.
         */
        if(intWhichTestSetting == 3)
        {
            double dblProbabilityToGenerateTraffic = 0;

            double dblTrafficVsTotalTime = (double) (whichTotalNumVehicleToBeUsed - intTotalRandomGenerateTraffic)/(double)(HOURTIME - intCountNoTrafficInjection);

            /*
             *LSP - For debugging purpose
             */

            /*
            ev<<"SUMOTraCIScenarioManagerV2::generateTraffic() : Setting 3 : Total Traffic to be inserted : " <<whichTotalNumVehicleToBeUsed
                    << " total inserted traffic : " << intTotalRandomGenerateTraffic << " : intCountNoTrafficInjection : "<< intCountNoTrafficInjection
                    << "HOURTIME : " << HOURTIME<< " dblTrafficVsTotalTime : " << dblTrafficVsTotalTime <<endl;

            ev<< " (itTrafficProfile->second - intTotalRandomGenerateTraffic) : " << (whichTotalNumVehicleToBeUsed - intTotalRandomGenerateTraffic)<<endl;
            ev<< " (HOURTIME - intCountNoTrafficInjection) : " << (HOURTIME - intCountNoTrafficInjection)
                <<" ratio : " << (double)(whichTotalNumVehicleToBeUsed - intTotalRandomGenerateTraffic)/(double)(HOURTIME - intCountNoTrafficInjection)
                <<endl;
             */

            while(true)
            {
                /*
                 * Only allow maximum 0 - 5 traffic at one time.
                 *
                 * This is to minimize the probability insert the road user at the same position
                 * during the simulation. This will happen especially when small simulation location is used.
                 */
                if(dblTrafficVsTotalTime >= 1)
                    intNumberOfTrafficToBeRandomGenerated = intrand(5)+1;
                else
                    intNumberOfTrafficToBeRandomGenerated = intrand(5);

                /* Only allow correct number of road user to be inserted according to traffic distribution by hour of day */
                if((intNumberOfTrafficToBeRandomGenerated + intTotalRandomGenerateTraffic) <= whichTotalNumVehicleToBeUsed)
                    break;
            }

            dblProbabilityToGenerateTraffic = dblTrafficVsTotalTime;

            /*
             * If dblTrafficVsTotalTime >= 1 then road user need to be inserted.
             * This is to allow specified road user to be inserted during the simulation
             */
            if (dblTrafficVsTotalTime >= 1) {
                dblProbabilityToGenerateTraffic = 1.0;
            }

            //random timing to allow StreetlightSim to insert the road users
            double dblSomeRandomNum = uniform(0, 1, 0); //= dblrand();
            if(dblSomeRandomNum < dblProbabilityToGenerateTraffic && intNumberOfTrafficToBeRandomGenerated > 0)
            {
                /*
                 * isTimeToAddVehicle is the control variable to allow StreetlightSim to insert the road user when
                 * conditions are met
                 */
                isTimeToAddVehicle = true;

                /*
                 * For debugging purpose only - start
                 */

                /*
                double dblCurrentTime = simTime().dbl();

                ev<<"SUMOTraCIScenarioManagerV2::generateTraffic() : Setting 3 : Total Traffic to be inserted : " <<whichTotalNumVehicleToBeUsed
                  << " total inserted traffic : " << intTotalRandomGenerateTraffic << " : intCountNoTrafficInjection : "<< intCountNoTrafficInjection
                  << "HOURTIME : " << HOURTIME<< " dblTrafficVsTotalTime : " << dblTrafficVsTotalTime <<endl;

                ev<< " (whichTotalNumVehicleToBeUsed - intTotalRandomGenerateTraffic) : " << (whichTotalNumVehicleToBeUsed - intTotalRandomGenerateTraffic)<<endl;
                ev<< " (HOURTIME - intCountNoTrafficInjection) : " << (HOURTIME - intCountNoTrafficInjection)
                  <<" ratio : " << (double)(whichTotalNumVehicleToBeUsed - intTotalRandomGenerateTraffic)/(double)(HOURTIME - intCountNoTrafficInjection)
                  <<endl;


                ev<<"At simulation time : "<< dblCurrentTime<< endl;
                ev<<"intNumberOfTrafficToBeRandomGenerated : "<<intNumberOfTrafficToBeRandomGenerated<< " : intCountNoTrafficInjection : "<<intCountNoTrafficInjection<<endl;
                ev<<" dblSomeRandomNum : " << dblSomeRandomNum << " : dblProbabilityToGenerateTraffic : "<<dblProbabilityToGenerateTraffic<< " : isTimeToAddVehicle : "<<isTimeToAddVehicle<<endl;
                */

                /*
                 * For debugging purpose only - end;
                 */
            }
            else
                isTimeToAddVehicle = false;

            intCountNoTrafficInjection++;  //count the time step t (sec) within a hour
        }

        /*
         * This test setting is for debugging purpose only, where road user(s) is timely inserted
         */
        if(intWhichTestSetting == 2)
        {
            if(intNFVehicleforVerification < 1)
                error("Error in SUMOTraCIScenarioManagerV2::generateTraffic::intWhichTestSetting = 2::intNFVehicleforVerification");

            whichTotalNumVehicleToBeUsed = intNFVehicleforVerification;

            intNumberOfTrafficToBeRandomGenerated = 1;

           if(dblTimeBtwCars < 1)
               error("Error in SUMOTraCIScenarioManagerV2::generateTraffic::intWhichTestSetting = 2::dblTimeBtwCars");

           if((simTime().dbl() - previoustimeToAddVehicle) >= dblTimeBtwCars)
           {
               isTimeToAddVehicle = true;
               previoustimeToAddVehicle = simTime().dbl();
           }
        }

        if((isTimeToAddVehicle == true) &&  (timeToAddVehicleCount <  whichTotalNumVehicleToBeUsed))
        {
            //ev<<" isTimeToAddVehicle : " <<isTimeToAddVehicle << " TIME TO ADD : " <<HOURTIME/((double)(whichTotalNumVehicleToBeUsed)) << " :: intCurTrafficProfileTimeStep : " << intCurTrafficProfileTimeStep <<endl;
            //opp_warning("timeToAddVehicleCount = %d, whichTotalNumVehicleToBeUsed = %d",timeToAddVehicleCount,whichTotalNumVehicleToBeUsed);
            isTimeToAddVehicle = false;
            int numberOfFail = 0;

            std::string strRoadUserType = "";
            for(int i = 0; i < intNumberOfTrafficToBeRandomGenerated; i++)
            {
                timeToAddVehicleCount++;
                isCommandAddVehicleSuccess = false;

                while(!isCommandAddVehicleSuccess)
                {
                    /*
                     * LSP 19/04/2013
                     * testing the pedestrian and motorist in same simulation scenario whereby
                     * both of they are travel with their own routes
                     */

                    strRoadUserType = "motorist";
                    if( intuniform(0, 100, 0) <= dblPedestrianPercentange)
                    {
                        double dblcurPedestrianRatio = 0;

                        if(trafficFromHour < 0)
                            dblcurPedestrianRatio =((double)(intTotalPedestrian + 1)/(double)(2*intTrafficFlow*dblTrafficRatioPerDay))*100;
                        else
                            dblcurPedestrianRatio =((double)(intTotalPedestrian + 1)/whichTotalNumVehicleToBeUsed)*100;

                        if(intTotalPedestrian <=0 || (dblcurPedestrianRatio <= dblPedestrianPercentange))
                        {
                            MYDEBUG<<"SUMOTraCIScenarioManagerV2::generateTraffic : intTotalPedestrian : "<<intTotalPedestrian
                                   <<" : intTrafficFlow : "<<intTrafficFlow
                                   <<" Ratio : "<<dblcurPedestrianRatio << endl;
//                                  opp_warning("SUMOTraCIScenarioManagerV2::generateTraffic : intTotalPedestrian : %d, tempTotalTraffic : %4.6f: intTrafficFlow : %d : dblcurPedestrianRatio :  %4.4f, whichTotalNumVehicleToBeUsed = %d", intTotalPedestrian ,tempTotalTraffic, intTrafficFlow, dblcurPedestrianRatio,whichTotalNumVehicleToBeUsed);
                            strRoadUserType = "pedestrian";
                        }
                    }

                    /*
                     * Not in use at the moment
                     * To insert a road user type of cyclist
                     */
                    if(strRoadUserType == "motorist")
                    {
                        if ( uniform(0, 1, 0)*100 <= dblCyclistPercentange)
                        {
                            strRoadUserType = "cyclist";
                        }
                    }

                    int intRondomRouteID;
                    std::string strRouteID;
                    std::map<std::string, std::string>::iterator itRouteType;

                    while(true)
                    {
                        intRondomRouteID = intrand(mapNetworkRouteType.size());
                        strRouteID = static_cast<std::ostringstream*>( &(std::ostringstream() << intRondomRouteID))->str();
                        itRouteType = mapNetworkRouteType.find(strRouteID) ;

                        if(((strcmp((itRouteType->second).c_str(),"highway") == 0) && (strcmp(strRoadUserType.c_str(), "motorist") == 0)))
                        {
                            break;
                        }
                        else if(((strcmp(itRouteType->second.c_str(), "pedestrian") ==0) && (strcmp(strRoadUserType.c_str(), "pedestrian")== 0)))
                        {
                            break;
                        }
                    }

                    /*
                     * For debugging purpose only
                     * The random selected route will be ignored if a particular route is predetermined in omnetpp.ini.
                     */
                    if(intTestRoute > 0)
                    {
                        intRondomRouteID = intTestRoute;
                    }

                    std::map<std::string, std::string>::iterator it = mapNetworkRoute.find(strRouteID);
                    if(it != mapNetworkRoute.end())
                    {
                        std::string strVehicleName = "addVehicle" + simTime().str() + "-" + static_cast<std::ostringstream*>( &(std::ostringstream() << i) )->str();
                        MYDEBUG<<"At simulation time "<<simTime() <<" strVehicleName : "<<strVehicleName <<" : route : "<< strRouteID << " :: value : " << it->second << " : Vehicle type : "<< strRoadUserType<<" : speed : "<< intVehicleConstantSpeed <<endl;

                        /*
                         * for verification
                         * original statement is:
                         * isCommandAddVehicle = commandAddVehicle(strVehicleName,strVTypeID, strRouteID,it->second, -2, -2);
                         *
                         * Following statement is used for debugging where road user is always injected at starting point of a route.
                         * isCommandAddVehicle = commandAddVehicle(strVehicleName,strVTypeID, strRouteID,it->second, 0, 0);
                         */
                       // MYDEBUG<<"SUMOTraCIScenarioManagerV2::generateTraffic: commandAddVehicle: strVTypeID : "<<strRoadUserType<<" : mapVtypeSize : "<<mapVType.size()<<endl;
                        if(RUInsertionMode== FIX_LOCATION)
                        {
                            isCommandAddVehicleSuccess = commandAddVehicle(strVehicleName,strRoadUserType, strRouteID,it->second, 0, 0);
                        }
                        else if(RUInsertionMode == RANDOM_LOCATION)
                        {
                            isCommandAddVehicleSuccess = commandAddVehicle(strVehicleName,strRoadUserType, strRouteID,it->second, -2, -2);
                        }


                        if(isCommandAddVehicleSuccess)
                        {
                            intTotalRandomGenerateTraffic++;

                            if(intVehicleConstantSpeed > 0)
                            {
                                /*
                                 * LSP - 22/04/2013
                                 * Only those road user type other than pedestrian will be assumed to be car
                                 */
                                commandSetSpeedMode(strVehicleName,0x00);
                                if(strRoadUserType == "pedestrian" || strRoadUserType == "cyclist")
                                {
                                  /*
                                   * LSP 23/08/2013
                                   * if the inserted road user's type is pedestrian ignore the speed change.
                                   */
                                    //MYDEBUG<<"SUMOTraCIScenarioManagerV2::generateTraffic():: strRoadUserType pedestrian / cyclist : "<< strRoadUserType << " : speed : "<<atof(((mapVType.find(strRoadUserType))->second).c_str()) << endl;
                                }
                                else if(strRoadUserType == "motorist" )
                                {
                                    commandSetSpeed(strVehicleName, intVehicleConstantSpeed);
                                    MYDEBUG<<"SUMOTraCIScenarioManagerV2::generateTraffic():: strRoadUserType : "<< strRoadUserType << " : speed : "<<intVehicleConstantSpeed << endl;
                                }
                            }

                            /*
                             * Collect the route ID in random selection of route
                             */
                            emit(whichRouteTakenSignal, intRondomRouteID);
                        }
                        else
                        {
                            /*
                             * Collect the ERROR route ID in random selection of route
                             */
                            emit(errorAddVehicleCountSignal,intRondomRouteID);
                        }

                        if(numberOfFail++ > 5)
                        {
                            opp_warning("generateTraffic : fail to insert");
                            break;
                        }
                    }
                    else
                    {
                        opp_warning("Route ID not found in the mapNetworkRoute");
                    }
                }
                if( strcmp(strRoadUserType.c_str(),"pedestrian") == 0 )
                {
                     intTotalPedestrian++;
                     intTotalPedestrianByTimeStep++;
                }
                if(strcmp(strRoadUserType.c_str(),"motorist") == 0)
                {
                    intTotalMotorist++;
                    intTotalMotoristByTimeStep++;
                }
                if(strcmp(strRoadUserType.c_str(),"cyclist") ==0)
                {
                    intTotalCyclist++;
                    intTotalCyclistByTimeStep++;
                }
            }
        }
        //if((((int)simTime().dbl())-intTrafficModeDelay) % intCollectTotalRoadUserByTimeStep == 0 && ((int)simTime().dbl()) > 0)
        if((((int)simTime().dbl())-intNetwDiscoveryDuration) % intCollectTotalRoadUserByTimeStep == 0 && ((int)simTime().dbl()) > 0)
        {
            //emit the record
            emit(totalRoadUserByTimeStepSignal,(intTotalPedestrianByTimeStep + intTotalMotoristByTimeStep + intTotalCyclistByTimeStep));
            emit(totalMotoristSignal, intTotalMotoristByTimeStep );
            emit(totalCyclistSignal, intTotalCyclistByTimeStep );
            emit(totalPedestrianSignal, intTotalPedestrianByTimeStep );
            intTotalPedestrianByTimeStep = intTotalMotoristByTimeStep = intTotalCyclistByTimeStep = 0;
        }
}

void SUMOTraCIScenarioManagerV2::executeOneTimestep()
{
    uint32_t targetTime = getCurrentTimeMs();
    if (targetTime > 0)
    {
        SUMOTraCIBufferV2 buf = queryTraCI(CMD_SIMSTEP2, SUMOTraCIBufferV2() << targetTime);

        uint32_t count; buf >> count;
        /*
         * For performance debugging only
         */
        //struct timeval tStart, tEnd;
        //gettimeofday(&tStart, NULL);

        for (uint32_t i = 0; i < count; ++i) {
            processSubcriptionResult(buf);
        }
        if(boolTrafficModelDelayEnd)
            generateTraffic();

        //gettimeofday(&tEnd, NULL);
        //double time_in_mili = timeval_substract(tEnd, tStart).tv_sec*1000 + timeval_substract(tEnd, tStart).tv_usec/1000 ;
        //MYDEBUG <<"SUMOTraCIScenarioManagerV2::executeOneTimestep(): time used : "<<time_in_mili<<endl;
    }
    if (!autoShutdownTriggered) scheduleAt(simTime()+updateInterval, executeOneTimestepTrigger);
}

Coord SUMOTraCIScenarioManagerV2::traci2omnet(TraCICoord coord) const {
    return Coord(coord.x - netbounds1.x + margin, (netbounds2.y - netbounds1.y) - (coord.y - netbounds1.y) + margin);
}

SUMOTraCIScenarioManagerV2::TraCICoord SUMOTraCIScenarioManagerV2::omnet2traci(Coord coord) const {
    return TraCICoord(coord.x + netbounds1.x - margin, (netbounds2.y - netbounds1.y) - (coord.y - netbounds1.y) + margin);
}

double SUMOTraCIScenarioManagerV2::traci2omnetAngle(double angle) const {

    // rotate angle so 0 is east (in TraCI's angle interpretation 0 is south)
    angle = angle - 90;

    // convert to rad
    angle = angle * M_PI / 180.0;

    // normalize angle to -M_PI <= angle < M_PI
    while (angle < -M_PI) angle += 2 * M_PI;
    while (angle >= M_PI) angle -= 2 * M_PI;

    return angle;
}

double SUMOTraCIScenarioManagerV2::omnet2traciAngle(double angle) const {

    // convert to degrees
    angle = angle * 180 / M_PI;

    // rotate angle so 0 is south (in OMNeT++'s angle interpretation 0 is east)
    angle = angle + 90;

    // normalize angle to -180 <= angle < 180
    while (angle < -180) angle += 360;
    while (angle >= 180) angle -= 360;

    return angle;
}

void SUMOTraCIScenarioManagerV2::subscribeToVehicleVariables(std::string vehicleId) {
    // subscribe to some attributes of the vehicle
    uint32_t beginTime = 0;
    uint32_t endTime = 0x7FFFFFFF;
    std::string objectId = vehicleId;
    uint8_t variableNumber = 5;
    uint8_t variable1 = VAR_POSITION;
    //uint8_t variable2 = VAR_ROAD_ID;
    uint8_t variable2 = VAR_ROUTE_ID;
    uint8_t variable3 = VAR_SPEED;
    uint8_t variable4 = VAR_ANGLE;
    /*
     * 15/03/2013 - LSP
     * Add to retrieve the road user type and update the variableNumber from 4 to 5
     */
    uint8_t variable5 = VAR_TYPE;
    /*
     * 16/09/2013 - LSP
     * Add to retrieve the road user type and update the variableNumber from 5 to 6
     */
    //uint8_t variable6 = VAR_ROUTE_ID;

    SUMOTraCIBufferV2 buf = queryTraCI(CMD_SUBSCRIBE_VEHICLE_VARIABLE, SUMOTraCIBufferV2() << beginTime << endTime << objectId << variableNumber << variable1 << variable2 << variable3 << variable4<< variable5);

    /* For performance debugging only */
    //struct timeval tStart, tEnd;
    //gettimeofday(&tStart, NULL);
    processSubcriptionResult(buf);

    //gettimeofday(&tEnd, NULL);
    //double time_in_mili = timeval_substract(tEnd, tStart).tv_sec*1000 + timeval_substract(tEnd, tStart).tv_usec/1000 ;
    //MYDEBUG<<"SUMOTraCIScenarioManagerV2::subscribeToVehicleVariables:: Time used : " << time_in_mili<<endl;

    ASSERT(buf.eof());
}

void SUMOTraCIScenarioManagerV2::unsubscribeFromVehicleVariables(std::string vehicleId) {
    // subscribe to some attributes of the vehicle
    uint32_t beginTime = 0;
    uint32_t endTime = 0x7FFFFFFF;
    std::string objectId = vehicleId;
    uint8_t variableNumber = 0;

    SUMOTraCIBufferV2 buf = queryTraCI(CMD_SUBSCRIBE_VEHICLE_VARIABLE, SUMOTraCIBufferV2() << beginTime << endTime << objectId << variableNumber);
    ASSERT(buf.eof());
}

void SUMOTraCIScenarioManagerV2::processSimSubscription(std::string objectId, SUMOTraCIBufferV2& buf) {
    uint8_t variableNumber_resp; buf >> variableNumber_resp;
    for (uint8_t j = 0; j < variableNumber_resp; ++j) {
        uint8_t variable1_resp; buf >> variable1_resp;
        uint8_t isokay; buf >> isokay;
        if (isokay != RTYPE_OK) {
            uint8_t varType; buf >> varType;
            ASSERT(varType == TYPE_STRING);
            std::string description; buf >> description;
            if (isokay == RTYPE_NOTIMPLEMENTED) error("TraCI server reported subscribing to variable 0x%2x not implemented (\"%s\"). Might need newer version.", variable1_resp, description.c_str());
            error("TraCI server reported error subscribing to variable 0x%2x (\"%s\").", variable1_resp, description.c_str());
        }

        if (variable1_resp == VAR_DEPARTED_VEHICLES_IDS) {
            uint8_t varType; buf >> varType;
            ASSERT(varType == TYPE_STRINGLIST);
            uint32_t count; buf >> count;
            MYDEBUG << "TraCI reports " << count << " departed vehicles." << endl;
            for (uint32_t i = 0; i < count; ++i) {
                std::string idstring; buf >> idstring;
                // adding modules is handled on the fly when entering/leaving the ROI
            }

            //activeVehicleCount += count;

        } else if (variable1_resp == VAR_ARRIVED_VEHICLES_IDS) {
            uint8_t varType; buf >> varType;
            ASSERT(varType == TYPE_STRINGLIST);
            uint32_t count; buf >> count;
            MYDEBUG << "TraCI reports " << count << " arrived vehicles." << endl;
            for (uint32_t i = 0; i < count; ++i) {
                std::string idstring; buf >> idstring;

                if (subscribedVehicles.find(idstring) != subscribedVehicles.end()) {
                    subscribedVehicles.erase(idstring);
                    unsubscribeFromVehicleVariables(idstring);
                }

                // check if this object has been deleted already (e.g. because it was outside the ROI)
                cModule* mod = getManagedModule(idstring);
                if (mod) deleteModule(idstring);

            }

        } else if (variable1_resp == VAR_TIME_STEP) {
            uint8_t varType; buf >> varType;
            ASSERT(varType == TYPE_INTEGER);
            uint32_t serverTimestep; buf >> serverTimestep;
            MYDEBUG << "TraCI reports current time step as " << serverTimestep << "s." << endl;
            uint32_t omnetTimestep = getCurrentTimeMs();
            ASSERT(omnetTimestep == serverTimestep);
        } else {
            error("Received unhandled sim subscription result");
        }
    }
}

void SUMOTraCIScenarioManagerV2::processVehicleSubscription(std::string objectId, SUMOTraCIBufferV2& buf) {
    bool isSubscribed = (subscribedVehicles.find(objectId) != subscribedVehicles.end());
    double px;
    double py;
    std::string edge;
    double speed;
    double angle_traci;
    int numRead = 0;
    /*
     * 15/03/2013 - LSP
     * add to collect the road user type 0 = driver , 1 = pedestrian
     */
    std::string strRoadUserType;
    std::string strRouteId;

    //03/04/2012 LSP
    //MYDEBUG << "LSP 03/04/2012 - processVehicleSubscription:  Vehicle #" << objectId <<endl;
    //end
    uint8_t variableNumber_resp; buf >> variableNumber_resp;

    MYDEBUG << "SUMOTraCIScenarioManagerV2::processVehicleSubscription : variableNumber_resp: "<<variableNumber_resp<< endl;

    for (uint8_t j = 0; j < variableNumber_resp; ++j) {
        uint8_t variable1_resp; buf >> variable1_resp;
        uint8_t isokay; buf >> isokay;
        if (isokay != RTYPE_OK) {
            uint8_t varType; buf >> varType;
            ASSERT(varType == TYPE_STRING);
            std::string errormsg; buf >> errormsg;
            if (isSubscribed) {
                if (isokay == RTYPE_NOTIMPLEMENTED) error("TraCI server reported subscribing to vehicle variable 0x%2x not implemented (\"%s\"). Might need newer version.", variable1_resp, errormsg.c_str());
                error("TraCI server reported error subscribing to vehicle variable 0x%2x (\"%s\").", variable1_resp, errormsg.c_str());
            }
        } else if (variable1_resp == ID_LIST) {
            uint8_t varType; buf >> varType;
            ASSERT(varType == TYPE_STRINGLIST);
            uint32_t count; buf >> count;
            MYDEBUG << "SUMOTraCIScenarioManagerV2::processVehicleSubscription: At simulation time: " << simTime() << " TraCI reports " << count << " active vehicles." << endl;
            intCurrentTotalActiveHost = (int) count;

            std::set<std::string> drivingVehicles;
            for (uint32_t i = 0; i < count; ++i) {
                std::string idstring; buf >> idstring;
                drivingVehicles.insert(idstring);
                MYDEBUG << "SUMOTraCIScenarioManagerV2::processVehicleSubscription: idstring :"<<idstring << endl;
            }

            // check for vehicles that need subscribing to
            std::set<std::string> needSubscribe;
            std::set_difference(drivingVehicles.begin(), drivingVehicles.end(), subscribedVehicles.begin(), subscribedVehicles.end(), std::inserter(needSubscribe, needSubscribe.begin()));
            for (std::set<std::string>::const_iterator i = needSubscribe.begin(); i != needSubscribe.end(); ++i) {
                MYDEBUG << "SUMOTraCIScenarioManagerV2::processVehicleSubscription: i :"<<*i << endl;
                subscribedVehicles.insert(*i);
                subscribeToVehicleVariables(*i);
            }
            // check for vehicles that need unsubscribing from
            std::set<std::string> needUnsubscribe;
            std::set_difference(subscribedVehicles.begin(), subscribedVehicles.end(), drivingVehicles.begin(), drivingVehicles.end(), std::inserter(needUnsubscribe, needUnsubscribe.begin()));
            for (std::set<std::string>::const_iterator i = needUnsubscribe.begin(); i != needUnsubscribe.end(); ++i) {
                subscribedVehicles.erase(*i);
                unsubscribeFromVehicleVariables(*i);
            }
        } else if (variable1_resp == VAR_POSITION) {
            uint8_t varType; buf >> varType;
            ASSERT(varType == POSITION_2D);
            buf >> px;
            buf >> py;
            numRead++;
        } else if (variable1_resp == VAR_ROAD_ID) {
            uint8_t varType; buf >> varType;
            ASSERT(varType == TYPE_STRING);
            buf >> edge;
            numRead++;
        } else if (variable1_resp == VAR_SPEED) {
            uint8_t varType; buf >> varType;
            ASSERT(varType == TYPE_DOUBLE);
            buf >> speed;
            numRead++;
        } else if (variable1_resp == VAR_ANGLE) {
            uint8_t varType; buf >> varType;
            ASSERT(varType == TYPE_DOUBLE);
            buf >> angle_traci;
            numRead++;
        }else if (variable1_resp == VAR_TYPE){
            uint8_t varType; buf >> varType;
            ASSERT(varType == TYPE_STRING);
            buf >> strRoadUserType;
            numRead++;
        }else if (variable1_resp == VAR_ROUTE_ID){
            uint8_t varType; buf >> varType;
            ASSERT(varType == TYPE_STRING);
            buf >> strRouteId;
            numRead++;
        }
        else {
            error("Received unhandled vehicle subscription result");
        }
    }

    // bail out if we didn't want to receive these subscription results
    if (!isSubscribed) return;

    // make sure we got updates for all 4 attributes
    if (numRead != 5) return;

    Coord p = traci2omnet(TraCICoord(px, py));
    if ((p.x < 0) || (p.y < 0)) error("received bad node position (%.2f, %.2f), translated to (%.2f, %.2f)", px, py, p.x, p.y);

    double angle = traci2omnetAngle(angle_traci);
    cModule* mod = getManagedModule(objectId);
    // is it in the ROI?
    bool inRoi = isInRegionOfInterest(TraCICoord(px, py), edge, speed, angle);
    if (!inRoi) {
        if (mod) {
            deleteModule(objectId);
            MYDEBUG << "Vehicle #" << objectId << " left region of interest" << endl;
        }
        return;
    }
    if (!mod) {
        // no such module - need to create
        /* 28/03/2012 LSP
         * need to update the addModule function as moduleType is not longer required
         */
        addModule(objectId, moduleType, strRoadUserType, moduleName,  moduleDisplayString, p, edge, speed, angle, strRouteId);
    } else {
        for (cModule::SubmoduleIterator iter(mod); !iter.end(); iter++) {
            cModule* submod = iter();
            SUMOTraCIMobilityV2* mm = dynamic_cast<SUMOTraCIMobilityV2*>(submod);
            if (!mm) continue;
            mm->nextPosition(p, edge, speed, angle);
        }
    }
}

void SUMOTraCIScenarioManagerV2::processSubcriptionResult(SUMOTraCIBufferV2& buf) {
    uint8_t cmdLength_resp; buf >> cmdLength_resp;
    uint32_t cmdLengthExt_resp; buf >> cmdLengthExt_resp;

    uint8_t commandId_resp; buf >> commandId_resp;
    std::string objectId_resp; buf >> objectId_resp;

    //LSP 19/04/2012
    if (commandId_resp == RESPONSE_SUBSCRIBE_VEHICLE_VARIABLE){
        processVehicleSubscription(objectId_resp, buf);
    }
    else if (commandId_resp == RESPONSE_SUBSCRIBE_SIM_VARIABLE) {
        processSimSubscription(objectId_resp, buf);
    }
    else {
        error("Received unhandled subscription result");
    }
}

template<> void SUMOTraCIScenarioManagerV2::SUMOTraCIBufferV2::write(std::string inv) {
    uint32_t length = inv.length();
    write<uint32_t> (length);
    for (size_t i = 0; i < length; ++i) write<char> (inv[i]);
}

template<> std::string SUMOTraCIScenarioManagerV2::SUMOTraCIBufferV2::read() {
    uint32_t length = read<uint32_t> ();
    if (length == 0) return std::string();
    char obuf[length + 1];

    for (size_t i = 0; i < length; ++i) read<char> (obuf[i]);
    obuf[length] = 0;

    return std::string(obuf, length);
}

