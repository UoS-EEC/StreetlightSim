//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#include "StreetlightMobilityV2.h"


#include <FWMath.h>
#include <time.h>


Define_Module(StreetlightMobilityV2);

//LSP - 17/04/2012 - add signal variable
/*
 * Moved to SteetlightApplLayer
 */
//const simsignalwrap_t StreetlightMobilityV2::mobilityStateChangedSignal = simsignalwrap_t(MIXIM_SIGNAL_MOBILITY_CHANGE_NAME);

void StreetlightMobilityV2::initialize(int stage)
{
    BaseMobility::initialize(stage);

    if (stage == 0) {
        move.setSpeed(par("speed").doubleValue());

        if(move.getSpeed() <= 0)
            move.setSpeed(0);

        numSteps = 0;
        step = -1;
        stepSize = Coord(0,0,0);

        stepTarget = targetPos;
        move.setStart(targetPos);

        //debugEV << "Initialize: move speed: " << move.getSpeed() << " (" << par("speed").doubleValue() << ")"
        //   << " pos: " << move.info() << endl;
        ev << "Initialize: move speed: " << move.getSpeed() << " (" << par("speed").doubleValue() << ")"
                   << " pos: " << move.info() << endl;


        poleStateChangedSignal = registerSignal("poleStateChanged");
        ev<<"Signal ID: poleStateChangedSignal: " << poleStateChangedSignal <<endl;

        /*
         * Moved to SteetlightApplLayer
         */
//        noMobileNodeSignal = registerSignal("noMobileNode");
//        ev<<"Signal ID: noMobileNodeSignal: " << noMobileNodeSignal <<endl;

        polePositionChangedSignal_X = registerSignal("polePositionXChanged");
        ev<<"Signal ID: polePositionChangedSignal_X: " << polePositionChangedSignal_X <<endl;

        polePositionChangedSignal_Y = registerSignal("polePositionYChanged");
        ev<<"Signal ID: polePositionChangedSignal_Y: " << polePositionChangedSignal_Y <<endl;

        recordActualMobileNodeCoodinateSignal= registerSignal("recordActualMobileNodeCoodinate");
        ev<<"Signal ID: recordActualMobileNodeCoodinateSignal: " << recordActualMobileNodeCoodinateSignal <<endl;

        //opp_warning("StreetlightMobilityV2::initialize::%d",noMobileNodeSignal);

        /*
         * Moved to SteetlightApplLayer
         */
//        simulation.getSystemModule()->subscribe(mobilityStateChangedSignal,this);
//        ev<<"Signal ID: mobilityStateChangedSignal: " << mobilityStateChangedSignal.operator int() <<endl;
//        simulation.getSystemModule()->subscribe(noMobileNodeSignal,this);

         //myGlobalTraci = FindModule<myTraCIScenarioManager*>::findGlobalModule();

        /*
         *15/08/2012 - LSP - Test optimization
         */
        //obstaclesCtr = ObstacleControlAccess().getIfExists();
        //tempObstacle = obstaclesCtr->getObtacleList();




    }
    else if( stage == 1 ){
        //lsp - 17/04/2012 replace
        //stepTarget = move.getStartPos();
        ev << "StreetlightMobilityV2::initialize: stage 2:: move speed: " << move.getSpeed() << " (" << par("speed").doubleValue() << ")"
                   << " pos: " << move.info() << endl;

        //LSP 17/04/2012 - subcribe to the signal of position change

    }
    lastUpdate = simTime();
    /*
     * Moved to SteetlightApplLayer
     */
//    minDistance = 1000;
//    minDistanceForPedestrianOrCyclist = 1000;
//    distanceBetweenCar = 0;
//    maxPoleVisualDistance = par("maxVisualDistance");
//
//    dblAverageLightSpan = par("dblAverageLightSpan").doubleValue();
//    isAdaptiveScheme = par("isAdaptiveScheme").boolValue();
//
//    carCount = 0;

    time_in_mili = 0;

    isMotoristInRange = false;
    isPedestrianInRange = false;
    isCyclistInRange = false;

}

void StreetlightMobilityV2::finish()
{
    //opp_warning("StreetlightMobilityV2::finish()");
//    simulation.getSystemModule()->unsubscribe(mobilityStateChangedSignal,this);
//    simulation.getSystemModule()->unsubscribe(noMobileNodeSignal,this);

}
//
//bool StreetlightMobilityV2::isPointInBoundingBox(Coord pointA, Coord pointB, Coord intersectPoint)
//{
//    double left, top, right, bottom; // Bounding Box For Line Segment
//    // For Bounding Box
//    if(pointA.x < pointB.x)
//    {
//        left = pointA.x;
//        right = pointB.x;
//    }
//    else
//    {
//        left = pointB.x;
//        right = pointA.x;
//    }
//    if(pointA.y < pointB.y)
//    {
//        top = pointA.y;
//        bottom = pointB.y;
//    }
//    else
//    {
//        top = pointB.y;
//        bottom = pointA.y;
//    }
//
//    if(intersectPoint.x >= left && intersectPoint.x <= right &&
//            intersectPoint.y >=top && intersectPoint.y <= bottom)
//        return true;
//    else
//        return false;
//
////    if( (px+0.01) >= left && (px-0.01) <= right &&
////            (py+0.01) >= top && (py-0.01) <= bottom )
////    {
////        return 1;
////    }
////    else
////        return 0;
//}

//bool StreetlightMobilityV2::isLineSegmentIntersected(Coord car, Coord pole,
//                            Coord wallPointA, Coord wallPointB)
//{
//    double dx, dy;
//    Coord intersectionPoint;
//
//    dx =  car.x - pole.x; // l1x2 - l1x1;
//    dy = car.y - pole.y ; //l1y2 - l1y1;
//
//    double m1 = dy / dx;
//    // y = mx + c
//    // intercept c = y - mx
//    double c1 = pole.y - m1*pole.x; //l1y1 - *m1 * l1x1; // which is same as y2 - slope * x2
//
//    dx = wallPointA.x - wallPointB.x; //l2x2 - l2x1;
//    dy = wallPointA.y - wallPointB.y; //l2y2 - l2y1;
//
//    double m2 = dy / dx;
//    // y = mx + c
//    // intercept c = y - mx
//    double c2 = wallPointB.y - m2*wallPointB.x; //l2y1 - *m2 * l2x1; // which is same as y2 - slope * x2
//
//    if( (m1 - m2) == 0)
//        return false;
//    else
//    {
//        intersectionPoint.x = (c2 - c1) / (m1 - m2);
//        intersectionPoint.y = m1 * intersectionPoint.x + c1;
//    }
//    if(isPointInBoundingBox(car, pole,intersectionPoint) &&
//        isPointInBoundingBox(wallPointA, wallPointB,intersectionPoint))
//    {
//        //return 1;
//        return true;
//    }
//    else
//    {
//        //return 0;
//        return false;
//    }
//}
//bool StreetlightMobilityV2::isLineSegmentIntersectedV2(Coord car, Coord pole,
//                            Coord wallPointA, Coord wallPointB)
//{
//
//
//    //Return false if either of the lines have zero lenght
//    if((car.x == pole.x && car.y == pole.y )|| (wallPointA.x == wallPointB.x && wallPointA.y == wallPointB.y))
//        return false;
//
//    double ax = pole.x - car.x;
//    double ay = pole.y - car.y;
//    double bx = wallPointA.x - wallPointB.x;
//    double by = wallPointA.y - wallPointB.y;
//    double cx = car.x - wallPointA.x;
//    double cy = car.y - wallPointA.y;
//
//   double alphaNumerator = by*cx - bx*cy;
//   double commonDenominator = ay*bx - ax*by;
//   if(commonDenominator >0)
//   {
//       if(alphaNumerator < 0 || alphaNumerator > commonDenominator )
//       {
//           return false;
//       }
//   }else if (commonDenominator < 0)
//   {
//           if(alphaNumerator > 0 || alphaNumerator < commonDenominator)
//           {
//                   return false;
//           }
//   }
//   double betaNumerator = ax*cy - ay*cx;
//   if(commonDenominator > 0)
//   {
//           if(betaNumerator < 0 || betaNumerator > commonDenominator)
//           {
//                   return false;
//           }
//   }else if (commonDenominator < 0)
//   {
//       if(betaNumerator > 0|| betaNumerator < commonDenominator)
//       {
//               return false;
//       }
//   }
//   if(commonDenominator == 0)
//   {
//          double y3LessY1 = wallPointA.y - car.y;
//          double collinearityTestForP3 = car.x*(pole.y - wallPointA.y) + pole.x*(y3LessY1) + wallPointA.x*(car.y -pole.y);
//
//          if(collinearityTestForP3 == 0)
//          {
//              if(((car.x >= wallPointA.x) && (car.x <= wallPointB.x)) || ((car.x <= wallPointA.x) && (car.x >= wallPointB.x)) ||
//                      ((pole.x >= wallPointA.x) && (pole.x <= wallPointB.x)) || ((pole.x <= wallPointA.x) && (pole.x >= wallPointB.x)) ||
//                     ((wallPointA.x >= car.x) && (wallPointA.x <= pole.x)) || ((wallPointA.x <= car.x) && (wallPointA.x >= pole.x)))
//              {
//                  if((car.y >= wallPointA.y && car.y <= wallPointB.y) || (car.y <= wallPointA.y && car.y >= wallPointB.y) ||
//                                       (pole.y >= wallPointA.y && pole.y <= wallPointB.y ) || (pole.y <= wallPointA.y && pole.y >= wallPointB.y) ||
//                                      ( wallPointA.y >= car.y && wallPointA.y <= pole.y) || (wallPointA.y <= car.y && wallPointA.y >= pole.y))
//                  {
//                      return true;
//                  }
//              }
//          }
//          return false;
//   }
//   return true;
//}
bool StreetlightMobilityV2::isLightSpanWithinViewField(std::list <Coord> viewFieldPolygon)
{

    return true;
}
//bool StreetlightMobilityV2::isObstacleBtwPoleAndCar(const cModule* car)
//{
//
//    //bool isCarBlockedByObstacle = false;
//    /*
//     * 15/08/2012 - LSP test for optimisation
//     * move the following declaration to StreetlightMobilityV2 header file
//     */
//    ObstacleControl* obstaclesCtr = ObstacleControlAccess().getIfExists();
//    std::vector<Obstacle> tempObstacle = obstaclesCtr->getObtacleList();
//
//    //const myTraCIMobility* globalMobility = FindModule<myTraCIMobility*>::findSubModule(const_cast<cModule*>(car));
//    const SUMOTraCIMobilityV2* globalMobility = FindModule<SUMOTraCIMobilityV2*>::findSubModule(const_cast<cModule*>(car));
//
//    //ev<<"StreetlightMobilityV2::receiveSignal::tempObstacle size is "<<tempObstacle.size()<<endl;
//    for(unsigned int i = 0; i < tempObstacle.size(); i++)
//    {
//        Obstacle tempOb = tempObstacle.at(i);
//        //ev<<"************************************ ID of tempObstacle "<<i<< " is "<< tempOb.getID()<< "*********************************************"<<endl;
//        Coords tempCoords= tempOb.getShape();
//        for(unsigned int j=0; j < tempCoords.size()-1; j++)
//        {
//
//            //ev<<"(" << tempCoords.at(j).x << ","<<tempCoords.at(j).y <<") to (" << tempCoords.at(j+1).x <<","<< tempCoords.at(j+1).y <<")" << endl;
//            //bool StreetlightMobilityV2::isLineSegmentIntersected(Coord car, Coord pole, Coord wallPointA, Coord wallPointB)
//            if(isLineSegmentIntersectedV2(globalMobility->getCurrentPosition(),move.getCurrentPosition(),tempCoords.at(j),tempCoords.at(j+1)) )
//            {
//
//          //      ev<<"@@@@@@@@@@@@@@@@@@@@@ pole can see the car @@@@@@@@@@@@@@@@@@@@@@@@"<<endl;
//                //isCarBlockedByObstacle = true;
//                return true;
//                break;
//            }
//        }
//    }
//    return false;
//
//}
void StreetlightMobilityV2::updatePoleStatus(double distanceBetweenCar)
{

//    Pole *tempPole = dynamic_cast<Pole *>(this->getParentModule());

//    if ( distanceBetweenCar > 75 && distanceBetweenCar <= 100 ){
//        getParentModule()->getDisplayString().setTagArg("r",1,"#89A001");
//
//        getParentModule()->getDisplayString().setTagArg("r",2,"#89A001");
//        //getParentModule()->getDisplayString().setTagArg("r",1,"blue");
//        //getParentModule()->getDisplayString().setTagArg("r",2,"blue");
//        //ev<<"++++++++++ distance between them blue:"<< distanceBetweenCar<<endl;
//
//    }
//    else if ( distanceBetweenCar > 50 && distanceBetweenCar <= 75 )
//    {
//        getParentModule()->getDisplayString().setTagArg("r",1,"#DFFF0A");
//        getParentModule()->getDisplayString().setTagArg("r",2,"#DFFF0A");
////        //                    getParentModule()->getDisplayString().setTagArg("r",1,"green");
////        //                    getParentModule()->getDisplayString().setTagArg("r",2,"green");
////        // ev<<"++++++++++ distance between them green:"<< distanceBetweenCar<<endl;
//    }
//    else if ( distanceBetweenCar > 30 && distanceBetweenCar <= 50 ){
//        getParentModule()->getDisplayString().setTagArg("r",1,"#F0FE8D");
//        getParentModule()->getDisplayString().setTagArg("r",2,"#F0FE8D");
//        //                    getParentModule()->getDisplayString().setTagArg("r",1,"red");
//        //                    getParentModule()->getDisplayString().setTagArg("r",2,"red");
//        //ev<<"++++++++++ distance between them red:"<< distanceBetweenCar<<endl;
//    }
//    else if ( distanceBetweenCar > 0 && distanceBetweenCar <= 30 ){
//        getParentModule()->getDisplayString().setTagArg("r",1,"#FFFFFF");
//        getParentModule()->getDisplayString().setTagArg("r",2,"#FFFFFF");
//    //  ev<<"++++++++++ distance between them white:"<< distanceBetweenCar<<endl;
//        }

    //LSP 24/04/2012 update the pole's status by suing pole own function

    emit(poleStateChangedSignal, distanceBetweenCar);
    ev<<"emit poleStateChangedSignal"<<endl;
}

//void StreetlightMobilityV2::handleNoCarinSimulation()
//{
//    //PowerUsage* ptrParentPowerUsage = FindModule<PowerUsage*>::findSubModule(const_cast<cModule*>(getParentModule()));
//    EnergyUsage* ptrParentEnergyUsage = FindModule<EnergyUsage*>::findSubModule(const_cast<cModule*>(getParentModule()));
//    //opp_warning("debug 1: StreetlightMobilityV2::handleNoCarinSimulation: at sim time %4.2f",simTime().dbl());
//    ptrParentEnergyUsage->updateEnergyUsage(false,minDistance);
//    //opp_warning("debug 2: StreetlightMobilityV2::handleNoCarinSimulation: at sim time %4.2f",simTime().dbl());
//    //ev<<"StreetlightMobilityV2::handleNoCarinSimulation" <<endl;
//    carCount =0;
//}
//
//void StreetlightMobilityV2::handleCarPossitionChangeSignal()
//{
//
//    struct timeval tStart, tEnd;
//    gettimeofday(&tStart, NULL);
//
//
//    myGlobalTraci = FindModule<SUMOTraCIScenarioManagerV2*>::findGlobalModule();
//    carHost = myGlobalTraci->getManagedHostsPointer();
//
//
//   std::map<std::string, cModule*> :: const_iterator itr;
//   bool gotAnyCarWithinVisualRange = false;
//
//   EnergyUsage* ptrParentEnergyUsage = FindModule<EnergyUsage*>::findSubModule(const_cast<cModule*>(getParentModule()));
//   StreetlightApplLayer* ptrStreetlightApplLayer = FindModule<StreetlightApplLayer*>::findSubModule(const_cast<cModule*>(getParentModule()));
//   /*
//    * 09/08/2012 - LSP - debugging
//    * to display necessary information on distance sensing mode
//    */
//   //ev << "Total mobile node in the simulation: " << carHost->size() <<endl ;
//
//   for(itr = carHost->begin() ; itr != carHost->end(); ++itr)
//   {
//      //ev << "Key: " << (*itr).first << " Value: " << (*itr).second <<endl;
//       const cModule* mod = (*itr).second;
//
//       const SUMOTraCIMobilityV2* globalMobility = FindModule<SUMOTraCIMobilityV2*>::findSubModule(const_cast<cModule*>(mod));
//
//       distanceBetweenCar = sqrt((double)(pow((globalMobility->getCurrentPosition().x-move.getCurrentPosition().x),2)+ pow((globalMobility->getCurrentPosition().y-move.getCurrentPosition().y),2)));
//
//       /*09/08/2012 - LSP For debugging
//        * to display necessary information on distance sensing mode
//        */
//       /*
//       ev << "Car: " << (*itr).first << " Position:(" <<  globalMobility->getCurrentPosition().x << ", "<< globalMobility->getCurrentPosition().y <<")" <<endl;
//       ev<<"Pole Position:("<<move.getCurrentPosition().x<<","<<move.getCurrentPosition().y<<")"<<endl;
//       ev<<"distance between them :"<< distanceBetweenCar<<endl;
//       */
//
//       getParentModule()->getDisplayString().setTagArg("b", 0, "20");
//       getParentModule()->getDisplayString().setTagArg("b", 1, "20");
//       getParentModule()->getDisplayString().setTagArg("b", 2, "oval");
//       getParentModule()->getDisplayString().setTagArg("b", 3, "black");
//       getParentModule()->getDisplayString().setTagArg("b", 5, "0");
//
//       if(distanceBetweenCar <= maxPoleVisualDistance )
//       {
//           if(!isObstacleBtwPoleAndCar(mod))
//           {
//               gotAnyCarWithinVisualRange = true;
//               if(isAdaptiveScheme) // only apply to my adaptive lighting scheme.
//               {
//                   if( distanceBetweenCar < minDistance && globalMobility->getRoadUserType() == MOTORIST)
//                   {
//                       minDistance = distanceBetweenCar ;
//                       ptrMotoristMobility = globalMobility;
//                       isMotoristInRange = true;
//                   }
//                   if( distanceBetweenCar < minDistanceForPedestrianOrCyclist && (globalMobility->getRoadUserType() == CYCLIST || globalMobility->getRoadUserType() == PEDESTRIAN))
//                   {
//                       minDistanceForPedestrianOrCyclist = distanceBetweenCar;
//                       ptrCyclistOrPedestrianMobility = globalMobility;
//                       globalMobility->getRoadUserType() == PEDESTRIAN ? isPedestrianInRange = true : isCyclistInRange = true;
//                   }
//               }
//               else //for other lighting schemes
//               {
//                   if( distanceBetweenCar < minDistance)
//                   {
//                       minDistance = distanceBetweenCar ;
//                   }
//               }
//           }
//           /*
//            * 07/02/2012 - LSP
//            * Processing the view field of a road user
//            * - only process the view field after all the update position signal are received
//            * - To recall, if there are 300 vehicles at any simulation step the total iteration will be
//            * total lamppost * total vehicle
//            */
//       }
//   }
//
//   carCount++;
//
//   gettimeofday(&tEnd, NULL);
//   time_in_mili += (timeval_substract(tEnd, tStart).tv_sec*1000 + timeval_substract(tEnd, tStart).tv_usec/1000);
//
//   if(carHost->size() == 0 )
//   {
//       //ev<<"MYDEBUG:: carHost->size() == 0" << endl;
//       //carCount = 0;
//       //opp_warning("MYDEBUG:: carHost->size() == 0");
//       /*
//        * 09/08/2012 - LSP reset the variable to zero
//        */
//       time_in_mili = 0;
//   }
///*
// * 07/03/2013 LSP
// * After collecting all the position change signals from all the road user, every single lamppost need to check
// * whether the lamppost is within the view field of a road user.
// *
// */
//   if(carCount == myGlobalTraci->getCurrentTotalActiveHost())
//   {
//       bool isPoleWithinViewField;
//       Coord lastCoords;
//       //double dblBrightnessLevel = ptrParentPowerUsage->updatePowerUsage(gotAnyCarWithinVisualRange,minDistance);
//       double dblBrightnessLevel;
//
//       SensorData *sensing = new SensorData();
//       sensing->isCyclistInRange = isCyclistInRange;
//       sensing->dblDistCyclist = minDistanceForPedestrianOrCyclist;
//       sensing->isPedestrianInRange = isPedestrianInRange;
//       sensing->dblDistPedestrian = minDistanceForPedestrianOrCyclist;
//       sensing->isMotoristInRange = isMotoristInRange;
//       sensing->dblDistMotorist = minDistance;
//       sensing->geoAddr = move.getCurrentPosition();
//
//       sensing->dataOriginateFrom = LAddress::L3Type( getParentModule()->getIndex() );
//
//    /*
//     * Channel the data to application layer
//     */
//
//
//       //Only transmit the sensing data if there is one
//       if(isCyclistInRange || isPedestrianInRange || isMotoristInRange)
//       {
//           //opp_warning("Lamp [%d] detect a obj within %4.8f",getParentModule()->getIndex(),minDistanceForPedestrianOrCyclist);
//           ptrStreetlightApplLayer->generateSensingData(sensing);
//       }
//
//
//       //opp_warning("StreetlightMobilityV2::handleCarPossitionChangeSignal ");
//       if(isAdaptiveScheme) // only apply to my adaptive lighting scheme.
//       {
//           ev<<"StreetlightMobilityV2::handleCarPossitionChangeSignal Lamp ["<<getParentModule()->getIndex() << "] : isPedestrianInRange : "<< isPedestrianInRange
//                         <<" : isCyclistInRange : " << isCyclistInRange << " isMotoristInRange : " << isMotoristInRange
//                         <<endl;
//           if((isPedestrianInRange || isCyclistInRange) && !isMotoristInRange) //only pedestrian or cyclist is in range
//           {
//               ev<<"StreetlightMobilityV2::handleCarPossitionChangeSignal : Pedestrian & Cyclist in range"<<endl;
//               dblBrightnessLevel = ptrParentEnergyUsage->updateEnergyUsage(gotAnyCarWithinVisualRange,minDistanceForPedestrianOrCyclist);
//           }
//           else if(isMotoristInRange && (isPedestrianInRange || isCyclistInRange)) //both motorist & pedestrian or cyclist is in range
//           {
//               ev<<"StreetlightMobilityV2::handleCarPossitionChangeSignal : Motorist & Pedestrian in range"<<endl;
//               //if stopping distrance required by motorist is within lamppost's beam pattern then turn on the streetlight
//               if((minDistance- ptrMotoristMobility->getSSD()) <= (dblAverageLightSpan/2))
//               {
//                   //value 0 for parameter distance is to trigger the streetlight to 100% brightness
//                   dblBrightnessLevel = ptrParentEnergyUsage->updateEnergyUsage(true,1);
//               }
//               else
//                   dblBrightnessLevel = ptrParentEnergyUsage->updateEnergyUsage(true,minDistanceForPedestrianOrCyclist);
//           }
//           else if (isMotoristInRange && !(isPedestrianInRange || isCyclistInRange))//only motorist in range
//           {
//               //value 0 for parameter distance is to trigger the streetlight to 100% brightness
//
//               ev<<"StreetlightMobilityV2::handleCarPossitionChangeSignal : Motorist in range : SSD : " << ptrMotoristMobility->getSSD() << " minDistance : "<<minDistance
//                                                        << " : minDistance - SSD : " << minDistance- ptrMotoristMobility->getSSD() << " : (dblAverageLightSpan/2) : "<<(dblAverageLightSpan/2)
//                                                        <<endl;
//               if((minDistance- ptrMotoristMobility->getSSD()) <= (dblAverageLightSpan/2))
//               {
//
//                   dblBrightnessLevel = ptrParentEnergyUsage->updateEnergyUsage(true,1); //Value 1 is used to trigger streetlight operation with 100 brightness level.
//               }
//               else
//                   dblBrightnessLevel = ptrParentEnergyUsage->updateEnergyUsage(false,200); //Value 200 is assumed to be out of range of streetlight operation distance.  Max distance is assumed to be 150 m
//           }
//           else //both motorist and pedestrian or cyclist are not in range
//               dblBrightnessLevel = ptrParentEnergyUsage->updateEnergyUsage(gotAnyCarWithinVisualRange,minDistance);
//       }
//       else
//           dblBrightnessLevel = ptrParentEnergyUsage->updateEnergyUsage(gotAnyCarWithinVisualRange,minDistance);
//
//       SUMOTraCIMobilityV2* globalMobility;
//
//
//
//       for(itr = carHost->begin() ; itr != carHost->end(); ++itr)
//       {
//          cModule* mod = (*itr).second;
//          globalMobility = FindModule<SUMOTraCIMobilityV2*>::findSubModule(dynamic_cast<cModule*>(mod));
//
//          distanceBetweenCar = sqrt((double)(pow((globalMobility->getCurrentPosition().x-move.getCurrentPosition().x),2)+ pow((globalMobility->getCurrentPosition().y-move.getCurrentPosition().y),2)));
//
//
//          /**
//           * reason of using " if(distanceBetweenCar <= maxPoleVisualDistance ) "
//           * is to minimise the unnecessary iteration for those Poles that are not within the view distance
//           */
//
//          maxViewDepth = 150 + dblAverageLightSpan;
//          //if(distanceBetweenCar <= maxPoleVisualDistance )
//          if(distanceBetweenCar <= maxViewDepth)
//          {
//              const std::list <Coord>  viewFieldPolygonFront = globalMobility->getVisualFieldFront();
//              const std::list <Coord>  viewFieldPolygonRear = globalMobility->getVisualFieldRear();
//              //ev<<"StreetlightMobilityV2::handleCarPossitionChangeSignal: Pole ID :" <<this->getParentModule()->getIndex() <<" viewFieldPolgyon size: "<<viewFieldPolygon.size() <<endl;
//
//
//              /*
//               * Determine weather this Pole is within the front and rear view field of a road user
//               * if YES, then its max light span is calculate and passes it to the road user for further
//               * processing at SUMOTraCIMobilityV2 module.
//               */
//
//              /*
//               * For front view field
//               */
//              lastCoords = *viewFieldPolygonFront.rbegin();
//              isPoleWithinViewField = false;
//
//              /*
//               * Check whether a streetlight is within the view field of a road user
//               */
//              for (std::list<Coord>::const_iterator i = viewFieldPolygonFront.begin(); i != viewFieldPolygonFront.end(); ++i)
//              {
//                  Coord c1 = *i;
//                  Coord c2 = lastCoords;
//                  lastCoords = c1;
//                  if( ((c1.y > move.getCurrentPosition().y) != (c2.y > move.getCurrentPosition().y)) &&
//                      (move.getCurrentPosition().x < (c2.x - c1.x) * (move.getCurrentPosition().y - c1.y)/ (c2.y - c1.y) + c1.x))
//                  {
//                      //if number of crossing is odd then the Pole is within the view field polygon, meaning True!
//                      isPoleWithinViewField = !isPoleWithinViewField;
//                  }
//
//              }
//              /*
//                   * Only consider lampposts with front view field and those not blocked by any obstacles
//                   */
//              if(isPoleWithinViewField && (!isObstacleBtwPoleAndCar(mod)))
//              {
//
//                      //opp_warning("debug 5: StreetlightMobilityV2::handleCarPossitionChangeSignal: at sim time %4.2f",simTime().dbl());
//                      globalMobility->calStreetLightUtilityOfRoadUser(distanceBetweenCar, dblBrightnessLevel, this->getParentModule()->getIndex(), dblAverageLightSpan);
//                      //opp_warning("debug 6: StreetlightMobilityV2::handleCarPossitionChangeSignal: at sim time %4.2f",simTime().dbl());
//              }
//              //else
//              //    globalMobility->setMaxLightViewDistanceFromRoadUser(0, 0, this->getParentModule()->getIndex(), dblAverageLightSpan);
//
//
//              /*
//               * for rear view field
//               */
//              lastCoords = *viewFieldPolygonRear.rbegin();
//              isPoleWithinViewField = false;
//              for (std::list<Coord>::const_iterator i = viewFieldPolygonRear.begin(); i != viewFieldPolygonRear.end(); ++i)
//              {
//                  Coord c1 = *i;
//                  Coord c2 = lastCoords;
//                  lastCoords = c1;
//                  if( ((c1.y > move.getCurrentPosition().y) != (c2.y > move.getCurrentPosition().y)) &&
//                          (move.getCurrentPosition().x < (c2.x - c1.x) * (move.getCurrentPosition().y - c1.y)/ (c2.y - c1.y) + c1.x))
//                  {
//                      //if number of crossing is odd then the Pole is within the view field polygon, meaning True!
//                      isPoleWithinViewField = !isPoleWithinViewField;
//                  }
//
//              }
//
//              /*
//               * Only consider lamppost with front view field and those not blocked by any obstacles
//               */
//              if(isPoleWithinViewField && (!isObstacleBtwPoleAndCar(mod)))
//              {
//                  /*
//                   * 08/03/2013 LSP
//                   * if distanceBetweenCar is in negative form then the lampposts behind the road user
//                   */
//                  //opp_warning("debug 7: StreetlightMobilityV2::handleCarPossitionChangeSignal: at sim time %4.2f",simTime().dbl());
//                  globalMobility->calStreetLightUtilityOfRoadUser((distanceBetweenCar*-1), dblBrightnessLevel, this->getParentModule()->getIndex(), dblAverageLightSpan);
//                  //opp_warning("debug 8: StreetlightMobilityV2::handleCarPossitionChangeSignal: at sim time %4.2f",simTime().dbl());
//              }
//              //else
//              //    globalMobility->setMaxLightViewDistanceFromRoadUser(0, 0, this->getParentModule()->getIndex(), dblAverageLightSpan);
//          }
//      }
//   /**
//    * try to call the setMaxLightViewDistanceFromRoadUser if none of the street light is within the virtual view field of a road user
//    * why ? - the utility of the streetlights is logged after call this function
//    *
//    */
//      /*
//       * 09/08/2012 - LSP reset the variable to zero
//       * - Finish collecting the time used, then reset to zero after emit the Power usage
//       */
//     // ev<< "StreetlightMobilityV2::handleCarPossitionChangeSignal::Street Lamp ID# "<<getParentModule()->getIndex()<<": Total time used: " << time_in_mili << " to process Total Vehicle: " << carCount<<endl;
//      time_in_mili = 0;
//
//      carCount = 0 ;
//      minDistance = maxPoleVisualDistance;
//      minDistanceForPedestrianOrCyclist = maxPoleVisualDistance;
//      isMotoristInRange = false; isPedestrianInRange = false; isCyclistInRange = false;
//      /*
//       * Testing only - LSP 15/07/2012
//       * To emit signal and receive by SUMOTraCIMobilityV2 module.
//       * Once receive signal SUMOTraCIMobilityV2 will record the all update
//       * coordinate after check by pole mobility
//       *
//       */
//      //emit(recordActualMobileNodeCoodinateSignal,0.0);
//
//      /*
//       * 15/07/2012 LSP
//       * To collect and verify the pole positions
//       * For verification of streetlight positions
//       */
//      //emit(polePositionChangedSignal_X,targetPos.x);
//      //emit(polePositionChangedSignal_Y,targetPos.y);
//  }
//}


//void StreetlightMobilityV2::receiveSignal(cComponent *source, simsignal_t signalID, cObject *obj) {
//
//
//
//    if (signalID == mobilityStateChangedSignal) {
//        //ev<<"###################### Pole ID start : "<<getParentModule()->getIndex()<<"########################"<<endl;
//        struct timeval tStart, tEnd;
//        gettimeofday(&tStart, NULL);
//        handleCarPossitionChangeSignal();
//        gettimeofday(&tEnd, NULL);
//        double time_in_mili = timeval_substract(tEnd, tStart).tv_sec*1000 + timeval_substract(tEnd, tStart).tv_usec/1000 ;
//        //ev<<"###################### StreetlightMobilityV2::receiveSignal:Pole ID: "<<getParentModule()->getIndex() <<" Time used for function : " <<time_in_mili << endl;
//        //ev<<"###################### Pole ID end : "<<getParentModule()->getIndex()<<"########################"<<endl;
//    }
////    else if(carHost->size() == 0)
////    {
////        ev<<" StreetlightMobilityV2::receiveSignal::activeMobileNodeSignal:cObject *obj"<<endl;
////        handleNoCarinSimulation();
////    }
//
//}
//
//void StreetlightMobilityV2::receiveSignal(cComponent *source, simsignal_t signalID, long l )
//{
//    //if(signalID ==noMobileNodeSignal && carHost->size() == 0)
//    if(signalID ==noMobileNodeSignal)
//       {
//           //ev<<" StreetlightMobilityV2::receiveSignal::noMobileNodeSignal:long l"<<endl;
//            handleNoCarinSimulation();
//       }
//}

void StreetlightMobilityV2::preInitializePosition(const Coord& position)
{
    targetPos = position;
    /*
     * For verification purpose
     * Check for the Pole positio
     */
    emit(polePositionChangedSignal_X,targetPos.x);
    emit(polePositionChangedSignal_Y,targetPos.y);
}

/**
 * Calculate a new random position and the number of steps the host
 * needs to reach this position
 */
void StreetlightMobilityV2::setTargetPosition()
{
    debugEV << "start setTargetPosistion: " << move.info() << endl;

    do{
    targetPos = getRandomPosition();

    double distance = move.getStartPos().distance(targetPos);
    simtime_t totalTime = distance / move.getSpeed();
    numSteps = FWMath::round(totalTime / updateInterval);

    debugEV << "new targetPos: " << targetPos.info() << " distance=" << distance
       << " totalTime=" << totalTime << " numSteps=" << numSteps << endl;
    }
    while( numSteps == 0 );

    stepSize = targetPos - move.getStartPos();

    stepSize = stepSize / numSteps;

    stepTarget = move.getStartPos() + stepSize;

    debugEV << "stepSize: " << stepSize.info() << " target: " << (stepSize*numSteps).info() << endl;

    step = 0;
    move.setDirectionByTarget(targetPos);

    debugEV << "end setTargetPosistion: " << move.info() << endl;
}


/**
 * Move the host if the destination is not reached yet. Otherwise
 * calculate a new random position
 */
void StreetlightMobilityV2::makeMove()
{
    // increment number of steps
    step++;

    if( step == numSteps ){
        // last step
        //stepSize.x =
        // step forward
        move.setStart(stepTarget, simTime());

        debugEV << "stepping forward. step #=" << step
           << " startPos: " << move.getStartPos().info() << endl;


        // get new target position
        debugEV << "destination reached.\n"
           << move.info() << endl;
        setTargetPosition();
    }
    else if( step < numSteps ){
        // step forward
        move.setStart(stepTarget, simTime());
        stepTarget += stepSize;

        debugEV << "stepping forward. step #=" << step
           << " startPos: " << move.getStartPos().info() << endl;

    }
    else{
    error("step cannot be bigger than numSteps");
    }

    //    fixIfHostGetsOutside();
}

/*
void StreetlightMobilityV2::fixIfHostGetsOutside()
{
    double dummy;

    handleIfOutside( PLACERANDOMLY, stepTarget, targetPos, stepSize, dummy );
}
*/
