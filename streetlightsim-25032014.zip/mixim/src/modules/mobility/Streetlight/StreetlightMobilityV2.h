//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#ifndef __MIXIM_STREETLIGHTMOBILITYV2_H_
#define __MIXIM_STREETLIGHTMOBILITYV2_H_

#include "MiXiMDefs.h"
#include "BaseMobility.h"
#include "Coord.h"
#include <list>

#include "SensorData.h"
/*
#include "mobility/myTraci/myTraCIScenarioManager.h"
#include "mobility/myTraci/myTraCIMobility.h"

*/

#include "SUMOTraCIScenarioManagerV2.h"
#include "SUMOTraCIMobilityV2.h"

#include "ObstacleControl.h"
//#include "power/PowerUsage.h"
#include "EnergyUsage.h"


//inline double PerpDot(const Coord& a,const Coord& b)                    { return (a.y*b.x) - (a.x*b.y); }

class StreetlightMobilityV2 : public BaseMobility
{

  protected:
    enum roadUserType { MOTORIST, CYCLIST, PEDESTRIAN };
    /** @name parameters to handle the movement of the host*/
    /*@{*/
    /** @brief Size of a step*/
    Coord stepSize;
    /** @brief Total number of steps */
    int numSteps;
    /** @brief Number of steps already moved*/
    int step;
    /*@}*/
    Coord targetPos;
    Coord stepTarget;

    //    double lastStep;
    //LSP 17/04/2012 add new signal variable
//    static const simsignalwrap_t mobilityStateChangedSignal;
//    simsignal_t noMobileNodeSignal;
    simsignal_t poleStateChangedSignal;
    simsignal_t polePositionChangedSignal_X;
    simsignal_t polePositionChangedSignal_Y;
    simsignal_t recordActualMobileNodeCoodinateSignal;

    simtime_t lastUpdate;
    /*
     * Moved to StreetlightApplLayer
     */
//    double distanceBetweenCar;
//    int carCount;
//    double minDistance;
//    double minDistanceForPedestrianOrCyclist;
//
//    double maxPoleVisualDistance;
//    double maxViewDepth;
//
//    double dblAverageLightSpan;
//    bool isAdaptiveScheme;
    const std::map<std::string, cModule*>* carHost;
    //myTraCIScenarioManager* myGlobalTraci;
    SUMOTraCIScenarioManagerV2* myGlobalTraci;
    const SUMOTraCIMobilityV2* ptrMotoristMobility;
    const SUMOTraCIMobilityV2* ptrCyclistOrPedestrianMobility;
    bool isMotoristInRange, isPedestrianInRange, isCyclistInRange;
    /*
     * 09/08/2012 - LSP for checking the time used by the function
     */
    double time_in_mili;


  public:
    //Module_Class_Members( ConstSpeedMobility, BaseMobility, 0 );
    typedef std::vector<Coord> Coords;

    /** @brief Initializes mobility model parameters.*/
    virtual void initialize(int);
    //LSP - 17/04/2012
    virtual void preInitializePosition(const Coord& position);
//    void receiveSignal(cComponent *source, simsignal_t signalID, cObject *obj);
//    void receiveSignal(cComponent *source, simsignal_t signalID, long l );
    virtual void finish();

    //LSP -end
  protected:
    /** @brief Calculate the target position to move to*/
    virtual void setTargetPosition();

    /** @brief Move the host*/
    virtual void makeMove();
    /* 13-04-2012 - LSP adding new preInitialise function */
    //void preInitialize(std::string external_id, const Coord& position);

    //    void fixIfHostGetsOutside();
    //LSP 24/04/2012

    //ObstacleControl* obstaclesCtr;
    //std::vector<Obstacle> tempObstacle;


    /*
     * Moved to StreetlightApplLayer
     */
//    bool isLineSegmentIntersected(Coord car, Coord pole, Coord wallPointA, Coord wallPointB);
//    bool isLineSegmentIntersectedV2(Coord car, Coord pole, Coord wallPointA, Coord wallPointB);
//    bool isPointInBoundingBox(Coord pointA, Coord pointB, Coord intersectPoint);
//    bool isObstacleBtwPoleAndCar(const cModule* mod);

    /*
     * 07/02/2013 - LSP
     * check whether streetlight's light beam is within the viewable distance. Viewable distance refer to view field polygon used to represent
     * a road user view field
     */
    bool isLightSpanWithinViewField(std::list <Coord> viewFieldPolygon);

    /*
     * Moved to StreetlightApplLayer
     */
//    void handleCarPossitionChangeSignal();
//    void handleNoCarinSimulation();
    void updatePoleStatus(double distanceBetweenCar);
};

#endif
